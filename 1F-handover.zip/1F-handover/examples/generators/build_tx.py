#!/usr/bin/env python3
"""Build the four Texas city pages (spec v3) into builds/2026-09-17-tx/."""
import html, json, os, re, sys

ROOT = "/workspace"
OUT = os.path.join(ROOT, "builds/2026-09-17-tx")
BASE = os.path.join(ROOT, "builds/Alabama Final/dothan-al-loans-NEW.html")

STATE, ST = "Texas", "TX"
DATE, DATE_ISO, CUTOFF = "September 17, 2026", "2026-09-17", "11:30 am"
DEBT = {2020: 46840, 2021: 49720, 2022: 54290, 2023: 56560, 2024: 57890}
STATE_MHI_2024 = 79723

FI393 = "https://tcss.legis.texas.gov/resources/FI/htm/FI.393.htm"
OCCCFORM = "https://occc.texas.gov/wp-content/uploads/2025/12/cab-disclosure-payday-single-rev2024.pdf"


def hrs(close):
    return f"Open today 8:00 AM &ndash; {close}" if close else "Opens 8:00 AM &middot; call ahead for closing"


def card_income(city, url, code):
    return (f'<div class="stat-card"><div class="num gold">Income-based cap</div><div class="lbl">Credit access businesses in {city} must keep a payday advance within a share of documented gross monthly income</div>'
            f'<div class="src">Source: <a href="{url}">{code}</a></div></div>')


def intro_ord(city):
    return (f"These are the payday rules for all of Texas, plus the city ordinance that applies to credit access businesses operating in {city}. "
            f"In plain terms: who makes the loan, what it can cost, and how far it can be renewed. Full statutory text is in "
            f'<a href="{FI393}">Finance Code Chapter 393</a>.')


ROWS_PRINCIPAL = """      <tr><td>Loan amount</td><td>No state cap, but the {city} ordinance limits businesses in the city to 20% of gross monthly income</td></tr>
      <tr><td>Renewals</td><td>State law sets no limit. In {city} a single-payment loan can be renewed three times, each paying down at least a quarter of the principal</td></tr>
      <tr><td>Installments</td><td>In {city} no more than four, each repaying at least a quarter of the principal</td></tr>"""

ROWS_AUSTIN = """      <tr><td>Loan amount</td><td>No state cap, but the Austin ordinance limits businesses in the city to 20% of gross monthly income</td></tr>
      <tr><td>Renewals</td><td>State law sets no limit. In Austin only a single-payment loan can be renewed, at most three times, each cutting the total owed, fees included, by a quarter</td></tr>
      <tr><td>Payments</td><td>In Austin four or fewer, each cutting the total owed, fees included, by at least a quarter</td></tr>"""

ROWS_DALLAS = """      <tr><td>Loan amount</td><td>No state cap on how much a payday loan can be</td></tr>
      <tr><td>Renewals</td><td>No state limit, and the business must post a notice that refinancing instead of paying in full adds charges</td></tr>
      <tr><td>Early payoff</td><td>The contract must state that there is no prepayment penalty</td></tr>"""

CITIES = [
 dict(city="Austin", county="Travis County", fips="453",
      mhi={2020: 82605, 2021: 84519, 2022: 95151, 2023: 97544, 2024: 97487},
      offices=[("2220 W Ben White Blvd", "78741", hrs("6:00 PM")), ("2110 W Slaughter Ln #180", "78748", hrs("5:00 PM")),
               ("3101 Bee Caves Rd", "78746", hrs("7:00 PM")), ("2905 San Gabriel St Ste 211", "78705", hrs("6:00 PM")),
               ("3909 N Interstate Hwy 35 Ste D-6", "78722", hrs("6:30 PM")), ("4410 E Riverside Dr Ste 100", "78741", hrs("6:30 PM")),
               ("8810 Business Park Dr #100", "78759", hrs("2:00 AM")), ("6630 S Congress Ave", "78745", hrs("6:00 PM")),
               ("1006 E Yager Ln", "78753", hrs("8:00 PM"))],
      card1=card_income("Austin", "https://library.municode.com/tx/austin/codes/code_of_ordinances?nodeId=TIT4BUREPERE_CH4-12RECRSEORCRACBU", "Austin City Code Chapter 4-12"),
      intro=intro_ord("Austin"), law_rows=ROWS_AUSTIN,
      p1="Yes. In Texas a licensed credit access business arranges the loan and sets its own fee, which the state does not cap, and the average payday APR on the state form is 415%. Austin limits the advance to 20% of gross monthly income.",
      p2="Travis County income climbed through 2023 and then slipped slightly in 2024, while staying well above the state median. Austin's cap follows your own gross income rather than the county's, and each payment must cut the total owed by a quarter, so check that four payments that size fit your budget before you sign.",
      lbl4="Median household income in Travis County in 2024, the latest year in the table below",
      growth="County income grew about eighteen percent in five years, behind about twenty-four for state debt per person.",
      housing="More than a third of households here",
      faq=[("Can I cancel after I sign with a credit access business?",
            "Yes. Texas requires the contract to say you may cancel at any time before midnight of the third day after the transaction, and it must come with a cancellation notice form. If you cancel, any payment you made under the contract must be returned within 10 days."),
           ("Does an Austin lender have to tell me about free money help?",
            "It does. Austin requires credit access businesses to give each customer a list of nonprofit agencies offering financial education, training or cash assistance, and to display a poster with information about consumer credit where every customer can see it."),
           ("How fast could the money reach my account?",
            "If a lender approves you and the application is finalized by 11:30 am local time on a weekday, funds can arrive the same day. Later applications, weekends and bank holidays move funding to the next business day, and same-day deposit is not available to every customer.")]),
 dict(city="Baytown", county="Harris County", fips="201",
      mhi={2020: 61906, 2021: 63539, 2022: 68748, 2023: 72348, 2024: 74682},
      offices=[("5165 Garth Rd #600", "77521", hrs("6:00 PM")), ("2309 N Alexander Dr", "77520", hrs("5:30 PM")),
               ("5623 Garth Rd #160", "77521", hrs("5:30 PM")), ("1502 W Cedar Bayou Lynchburg Rd", "77521", hrs("6:00 PM")),
               ("6612 Garth Rd", "77521", hrs("5:00 PM")), ("4810 I-10 B", "77521", hrs("5:30 PM"))],
      card1=card_income("Baytown", "https://library.municode.com/tx/baytown/codes/code_of_ordinances?nodeId=PTIICOOR_CH20BU_ARTIICRACBU", "Baytown Code of Ordinances, Chapter 20"),
      intro=intro_ord("Baytown"), law_rows=ROWS_PRINCIPAL.format(city="Baytown"),
      p1="Yes, through a credit access business licensed by the state. Its fee has no state cap, the state disclosure form puts the average payday APR at 415%, and Baytown's ordinance caps the cash at 20% of gross monthly income.",
      p2="Harris County income rose in every year shown below but finished 2024 some $5,041 under the state median. Because Baytown ties the advance to your documented gross monthly income, the legal limit moves with your own paycheck, so borrow against the pay stub you have today, not an expected raise.",
      lbl4="Median household income in Harris County in 2024, the most recent year of county data shown below",
      growth="County income grew about twenty-one percent in five years, a little behind state debt per person.",
      housing="Close to four in ten households here",
      faq=[("What if someone threatens criminal charges over my check?",
            "Your contract with a credit access business must state that no one may threaten or pursue criminal charges over a check or debit authorization you gave as security, unless there is forgery, fraud, theft or similar conduct. The business must also follow state and federal debt collection law."),
           ("If I pay off a loan and borrow again right away, is that a new loan?",
            "Not under Baytown's ordinance. A new loan made within seven days after you paid off the last one counts as a refinancing or renewal, so it uses up one of the renewals the city allows on a single-payment loan."),
           ("Does 1F Cash Advance lend the money?",
            "It does not. 1F Cash Advance is a loan connector: it passes one request to licensed lenders, and the lender that makes an offer sets the terms and funds the loan. Your agreement will name that lender, and that is the company the Texas rules on this page apply to.")]),
 dict(city="Dallas", county="Dallas County", fips="113",
      mhi={2020: 65770, 2021: 63549, 2022: 70871, 2023: 74352, 2024: 78910},
      offices=[("2726 Samuell Blvd Ste A", "75223", hrs("6:00 PM")), ("4516 Cole Ave #636", "75205", hrs("9:00 PM")),
               ("3817 Ross Ave", "75204", hrs("6:30 PM")), ("222 Jefferson Blvd B", "75203", hrs("6:30 PM")),
               ("2247 Buckner Blvd #122", "75227", hrs("6:30 PM")), ("3824 Cedar Springs Rd", "75219", hrs("9:00 PM")),
               ("3821 S Buckner Blvd", "75227", hrs("6:00 PM")), ("7016 Greenville Ave", "75249", hrs("6:00 PM")),
               ("3906 W Camp Wisdom Rd #101", "75237", hrs("6:00 PM")), ("4010 Ross Ave", "75204", hrs("6:00 PM")),
               ("13601 Preston Rd Ste W-521", "75240", hrs("6:00 PM"))],
      card1='<div class="stat-card"><div class="num gold">No state amount cap</div><div class="lbl">Texas law sets no maximum size for a payday loan arranged by a credit access business</div><div class="src">Source: <a href="https://tcss.legis.texas.gov/resources/FI/htm/FI.393.htm">Texas Finance Code Chapter 393</a></div></div>',
      intro=("These are the payday rules for all of Texas, including Dallas, which also regulates credit access businesses in its own city code. "
             "In plain terms: who makes the loan, what it can cost, and what the contract must tell you. Full statutory text is in "
             '<a href="https://tcss.legis.texas.gov/resources/FI/htm/FI.393.htm">Finance Code Chapter 393</a>.'),
      law_rows=ROWS_DALLAS,
      p1="Yes. A state-licensed credit access business arranges the loan with a separate lender and charges a fee Texas does not cap, and the state disclosure form puts the average payday APR at 415%. State law sets no maximum loan amount.",
      p2="Dallas County income dipped in 2021 and then rose three years running, ending 2024 just $813 under the state median. With no state cap on the loan size or the broker's fee, the limit that protects you is the one you set, so size the loan to what a lean year like 2021 would have left you.",
      lbl4="Median household income in Dallas County in 2024, the highest level in the table below",
      growth="County income rose about twenty percent over these five years, behind the rise in state debt per person.",
      housing="Nearly four in ten households here",
      faq=[("Will I pay a penalty for paying the loan off early?",
            "No penalty is allowed. Texas requires the contract with a credit access business to state that there is no prepayment penalty, so you can pay early and stop further renewal charges from building up."),
           ("How do I check that a credit access business is licensed?",
            "Search the business in the Office of Consumer Credit Commissioner license database before you sign. Texas requires a separate license for each location a credit access business operates, so check that the address you are dealing with is covered."),
           ("Can I apply from my phone?",
            "Yes. The request form works on a phone, stays open around the clock and takes about five minutes. Keep your pay stub and bank details handy, since the lender verifies your income and application details before deciding.")]),
 dict(city="San Antonio", county="Bexar County", fips="029",
      mhi={2020: 60477, 2021: 63014, 2022: 65839, 2023: 69755, 2024: 72578},
      offices=[("231 San Pedro Ave", "78205", hrs("7:00 PM")), ("2501 Bandera Rd Ste 101", "78238", hrs("7:00 PM")),
               ("6900 San Pedro Ave #107", "78216", hrs("7:00 PM")), ("8458 Fredericksburg Rd", "78229", hrs("7:00 PM")),
               ("7114 Military Dr W", "78227", hrs("7:00 PM")),
               ("11751 Blanco Rd", "78216", hrs("7:00 PM")), ("12803 Nacogdoches Rd", "78217", hrs("7:00 PM")),
               ("10555 Culebra Rd #106", "78251", hrs("6:00 PM"))],
      card1=card_income("San Antonio", "https://library.municode.com/tx/san_antonio/codes/code_of_ordinances?nodeId=PTIICO_CH16LIBURE_ARTXVICRACBU", "San Antonio City Code Chapter 16, Article XVI"),
      intro=intro_ord("San Antonio"), law_rows=ROWS_PRINCIPAL.format(city="San Antonio"),
      p1="Yes. San Antonio holds a payday advance to 20% of your gross monthly income, but Texas itself caps neither the broker's fee nor the loan size, and the state disclosure form reports an average payday APR of 415%.",
      p2="Bexar County income rose in every year shown below yet stayed $7,145 under the state median in 2024. San Antonio lets a single-payment loan be renewed up to three times, and each renewal still adds charges, so if one paycheck cannot clear it, choose repayment in installments at the start.",
      lbl4="Median household income in Bexar County in 2024, the latest figure in the table below",
      growth="County income grew about twenty percent in five years, against about twenty-four for state debt per person.",
      housing="More than a third of households here",
      faq=[("Where can I see what a credit access business charges?",
            "Texas requires the business to post a schedule of all its payday and title loan fees where customers can see it and on its website and social media pages, along with the address and helpline number of the Office of Consumer Credit Commissioner."),
           ("Can I get my loan agreement in Spanish in San Antonio?",
            "Yes. The city requires agreements in the consumer's language of preference and English and Spanish versions at every location. If you cannot read, the business must read the agreement and required notices to you in full before you sign."),
           ("What should I have ready before I apply?",
            "A photo ID, your Social Security number, a checking account with its routing number and a recent pay stub or other proof of income. You also need proof of a Texas address, a working phone and email, and to be at least 18.")]),
]


def slug(c):
    return c.lower().replace(" ", "-") + "-tx-loans"


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build(c):
    base = open(BASE, encoding="utf-8").read()
    head = base[:base.find("</head>")]
    city, county = c["city"], c["county"]
    h1 = f"Payday Loans in {city}, {STATE}"
    title = f"{h1} | 1F Cash Advance"
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)
    head = head.replace("</style>", """.rquote{position:relative;background:#f7f8fa;border-left:3px solid #123a5f;border-radius:0 8px 8px 0;padding:18px 24px 14px 30px;margin:22px 0}
.rquote p{font-style:italic;margin:0 0 10px}
.rquote footer{font-style:normal;font-size:14px;color:#6f685d}
.state-links{display:grid;grid-template-columns:repeat(4,1fr);gap:0 24px;margin-top:16px;font-size:15px}
.state-links p{margin:0 0 7px}
@media(max-width:900px){.state-links{grid-template-columns:repeat(2,1fr)}}
</style>""", 1)
    assert "<!-- skill-version: v2 -->" in head
    fred_c = f"https://fred.stlouisfed.org/series/MHITX48{c['fips']}A052NCEN"
    fred_s = "https://fred.stlouisfed.org/series/MHITX48000A052NCEN"
    dp04 = f"https://fred.stlouisfed.org/series/DP04ACS048{c['fips']}"
    m24 = c["mhi"][2024]
    gap = STATE_MHI_2024 - m24
    gap_txt = f"{money(abs(gap))} {'below' if gap > 0 else 'above'}"
    gap_lbl = f"How far {county} sat {'under' if gap > 0 else 'above'} the {STATE} median in 2024"

    # Hero (global, fixed) — copied from base, city/state swapped
    hs = base.find('<div class="topbar">'); he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he]
    hero = hero.replace("Payday Loans in Dothan, Alabama", h1).replace("licensed Alabama lender", f"licensed {STATE} lender")
    hero = hero.replace("Updated: September 3, 2026", f"Updated: {DATE}")
    assert "Dothan" not in hero and "Alabama" not in hero

    quote1 = quote2 = quote3 = ""
    if city == "Dallas":
        quote1 = """<blockquote class="rquote"><p>&ldquo;I got caught in the payday loan doom loop&hellip; By the end, my entire paycheck was going to the loan as soon as it was deposited.&rdquo;</p><footer>said the Reddit user <a href="https://www.reddit.com/user/CaseyAnthonysMouth/" rel="nofollow noopener noreferrer" target="_blank">CaseyAnthonysMouth</a>, August 2025</footer></blockquote>"""
        quote2 = """<blockquote class="rquote"><p>&ldquo;I had the same problem. Finally had to pay it all off after it showed up on my credit report for almost 3x the original amount.&rdquo;</p><footer>said the Reddit user <a href="https://www.reddit.com/user/Sanmartian41/" rel="nofollow noopener noreferrer" target="_blank">Sanmartian41</a>, August 2025</footer></blockquote>"""
        quote3 = """<blockquote class="rquote"><p>&ldquo;My credit union is the best bank I&rsquo;ve worked with, highly recommend looking into your options.&rdquo;</p><footer>said the Reddit user <a href="https://www.reddit.com/user/wantondavis/" rel="nofollow noopener noreferrer" target="_blank">wantondavis</a>, February 2024</footer></blockquote>"""
    cta_block = """<section class="section">
  <div class="wrap" style="max-width:860px;text-align:center">
    <h2>Ready to Apply from {city}?</h2>
    <p class="small" style="margin:14px 0 18px">I have read and agree to the <a href="https://1firstcashadvance.org/terms/">Terms</a>, <a href="https://1firstcashadvance.org/rates/">Rates</a>, <a href="https://1firstcashadvance.org/privacy-policy/">Privacy Policy</a> and <a href="https://1firstcashadvance.org/legal-disclaimer/">Disclaimer</a> before submitting a loan request.</p>
    <a class="btn" href="https://1firstcashadvance.org/apply/">Apply Now</a>
  </div>
</section>
""" if city == "Dallas" else ""
    states_block = """<section class="section">
  <div class="wrap">
    <p class="eyebrow">Every state we cover</p>
    <h2>See All States</h2>
    <div class="state-links"><div class="st-col"><p><a href="https://1firstcashadvance.org/loans-by-state/alabama/">Alabama</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-california/">California</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-florida/">Florida</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/illinois-loans/">Illinois</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-kentucky/">Kentucky</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-in-massachusetts/">Massachusetts</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/missouri/">Missouri</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/new-hampshire/">New Hampshire</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-in-north-dakota/">North Dakota</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/loans-in-pennsylvania/">Pennsylvania</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-tennessee/">Tennessee</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/virginia/">Virginia</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-in-wyoming/">Wyoming</a></p></div><div class="st-col"><p><a href="https://1firstcashadvance.org/loans-by-state/alaska/">Alaska</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-colorado/">Colorado</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/georgia-loans/">Georgia</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/in/">Indiana</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/la/">Louisiana</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/loans-in-michigan-online/">Michigan</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/montana/">Montana</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-new-jersey/">New Jersey</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/ohio/">Ohio</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/rhode-island/">Rhode Island</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-texas/">Texas</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-washington/">Washington</a></p></div><div class="st-col"><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-in-arizona/">Arizona</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/connecticut/">Connecticut</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/hawaii/">Hawaii</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-in-iowa/">Iowa</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/maine/">Maine</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-in-minnesota/">Minnesota</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/nebraska/">Nebraska</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/nm/">New Mexico</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/oklahoma-loans/">Oklahoma</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/south-carolina/">South Carolina</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-in-utah/">Utah</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/west-virginia/">West Virginia</a></p></div><div class="st-col"><p><a href="https://1firstcashadvance.org/loans-by-state/arkansas/">Arkansas</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-delaware/">Delaware</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-in-idaho/">Idaho</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-kansas/">Kansas</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-maryland/">Maryland</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-mississippi/">Mississippi</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-nevada/">Nevada</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-in-north-carolina/">North Carolina</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/payday-loans-oregon/">Oregon</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/south-dakota/">South Dakota</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/vermont/">Vermont</a></p><p><a href="https://1firstcashadvance.org/loans-by-state/wisconsin/">Wisconsin</a></p></div></div>
  </div>
</section>
""" if city == "Dallas" else ""
    offices = "".join(
        f'<div class="office-card">\n<p class="office-addr">{html.escape(st)}<br>{city}, {ST} {z}</p>\n'
        f'<p class="office-hours">{hours}</p>\n</div>'
        for st, z, hours in c["offices"])

    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(c['mhi'][y])}</td><td>{money(DEBT[y])}</td><td>{money(round(c['mhi'][y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))

    others = [x["city"] for x in CITIES if x["city"] != city]
    links = " &middot; ".join(f'<a href="https://1firstcashadvance.org/{slug(o)}/">{o}</a>' for o in others)

    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in c["faq"])

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {city} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {city}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A small loan against your next paycheck, arranged by a licensed credit access business and funded by a separate lender. You repay it on payday or in a few set payments. The business charges its own fee on top of the interest.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in scheduled payments, not all at once. It is usually unsecured and has a set end date. If you need a bigger amount or more time, this usually costs less than renewing a payday loan again and again.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>Where to get payday loan {city}</h2>
    <div class="office-grid">
{offices}
</div>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {city}?</h2>
    <p>{c['p1']}</p>
    <p style="margin-top:14px">{c['p2']}</p>
{quote1}
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {city}: What the Numbers Show</h2>
<div class="stat-grid">
{c['card1']}
<div class="stat-card"><div class="num navy">No fee cap</div><div class="lbl">Texas lets the business set its fee by agreement, and the state regulator has no power to cap it</div><div class="src">Source: <a href="{FI393}">Texas Finance Code Chapter 393</a></div></div>
<div class="stat-card"><div class="num navy">Triple-digit</div><div class="lbl">The average APR on a Texas payday loan, as published by the state consumer credit regulator</div><div class="src">Source: <a href="{OCCCFORM}">OCCC payday loan disclosure form</a></div></div>
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">{c['lbl4']}</div><div class="src">Source: <a href="{fred_c}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{gap_txt}</div><div class="lbl">{gap_lbl}</div><div class="src">Source: <a href="{fred_s}">Census SAIPE for Texas via FRED</a></div></div>
<div class="stat-card"><div class="num navy">No criminal threats</div><div class="lbl">The contract must state no one may threaten or pursue criminal charges over your check absent fraud, forgery or theft</div><div class="src">Source: <a href="{FI393}">Texas Finance Code Chapter 393</a></div></div></div>
<p class="tbl-cap">{county} median household income and {STATE} household debt, 2020 to 2024</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{STATE} debt per person</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">County income comes from <a href="{fred_c}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column comes from the <a href="https://www.newyorkfed.org/microeconomics/databank.html">New York Fed Consumer Credit Panel</a>. {c['growth']} <a href="{dp04}">{c['housing']}</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. {STATE} sets a flat ceiling instead of an income test, so the amount does not change with local earnings. The last column is a calculation, not a published figure: monthly county income after the standard housing share. It describes a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>{c['intro']}</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
      <tr><td>Governing law</td><td>Finance Code Chapter 393: a credit access business licensed by the OCCC arranges the loan from a third-party lender</td></tr>
      <tr><td>Lender interest</td><td>Generally limited to 10% a year under §302.001</td></tr>
      <tr><td>Broker fee</td><td>Set by agreement with you, with no state cap</td></tr>
      <tr><td>Rate</td><td>415% average APR on a payday loan, per the state disclosure form (2022 data)</td></tr>
{c['law_rows']}
      <tr><td>Cost disclosure</td><td>Before the deal, the business must give you the state form comparing its cost with other credit, under §393.223</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example: the state disclosure form puts average fees and interest on a payday loan at $34.14 per $100 borrowed over one month, based on 2022 reports. It is a statewide average, and your own quote can differ. To check a license or file a complaint, contact the <a href="https://occc.texas.gov/consumers/file-a-complaint/">Office of Consumer Credit Commissioner</a>.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {city}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {city} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below payday.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call a {county} community action agency. Ask about energy bill assistance and a payment arrangement. That is assistance, not a loan. Call before a disconnection.</p></div>
    </div>
{quote3}
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Qualifying for more is not a reason to take more, and every extra dollar raises what you owe back.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you cannot pay on time, talk to the lender before the due date rather than taking another loan.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
{quote2}
      <p style="margin-bottom:0">To verify a credit access business license, use the <a href="https://alecs.occc.texas.gov/Generic/AdvanceSearch">OCCC license search</a> or call the OCCC consumer helpline; you can also contact the federal CFPB.</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{city} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
{cta_block}<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>1F Cash Advance in Other {STATE} Cities</h2>
    <p style="max-width:760px">The same {STATE} rules apply statewide. See how they play out where you live:</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
{states_block}"""
    # Authors (global) — copied from base, county swapped
    a_s = base.rfind("<section", 0, base.find("Who wrote this")); a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e].replace("Houston County", county)
    if city == "Dallas":
        authors = """<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Who wrote this</p>
    <h2>About the Authors</h2>
    <div class="authors">
      <div class="author-card">
        <div class="role">Written by &middot; Financial writer and editor</div>
        <div class="name">Tara Wellema</div>
        <p>Longtime Bloomberg financial journalist and columnist. She now writes and edits thought-leadership and investor-communications material for a financial-services firm, and works as a ghostwriter.</p>
        <div class="creds">Northwestern University &middot; Former Bloomberg columnist &middot; Harding Loevner LP</div>
        <div class="verify" style="margin-top:8px;font-size:13px"><a href="https://www.linkedin.com/in/taralachapellewellema/">Profile and published work</a></div>
      </div>
      <div class="author-card">
        <div class="role">Edited by &middot; Financial editor</div>
        <div class="name">Rebecca McClay</div>
        <p>Financial editor who provides stocks and market-related coverage for numerous publications. Freelance business writer, editor and media consultant since 2012.</p>
        <div class="creds">University of Maryland, College Park</div>
        <div class="verify" style="margin-top:8px;font-size:13px"><a href="https://www.linkedin.com/in/rebeccamcclay/">Profile and published work</a></div>
      </div>
      <div class="author-card">
        <div class="role">Reviewed by &middot; Financial adviser</div>
        <div class="name">Colin Scott</div>
        <p>Financial adviser at Payday Loans Dallas with a graduate-level background in finance. He checked the Texas figures and the Dallas County income series on this page.</p>
        <div class="creds">University of Dallas</div>
        <div class="verify" style="margin-top:8px;font-size:13px"><a href="https://www.linkedin.com/in/paydayloansdallas/">Profile and published work</a></div>
      </div>
    </div>
  </div>
</section>"""
        hero = re.sub(r"Written by <a.*?Michael Lefler</a>", """Written by <a href="https://www.linkedin.com/in/taralachapellewellema/">Tara Wellema</a> | Edited by <a href="https://www.linkedin.com/in/rebeccamcclay/">Rebecca McClay</a> | Reviewed by <a href="https://www.linkedin.com/in/paydayloansdallas/">Colin Scott</a>""", hero, flags=re.S)
    assert "Dothan" not in authors and "Alabama" not in authors

    citations = []
    if city == "Dallas":
        citations = [
            {"@type": "Quotation",
             "text": "I got caught in the payday loan doom loop... By the end, my entire paycheck was going to the loan as soon as it was deposited.",
             "creator": {"@type": "Person", "name": "CaseyAnthonysMouth", "url": "https://www.reddit.com/user/CaseyAnthonysMouth/"},
             "datePublished": "2025-08"},
            {"@type": "Quotation",
             "text": "I had the same problem. Finally had to pay it all off after it showed up on my credit report for almost 3x the original amount.",
             "creator": {"@type": "Person", "name": "Sanmartian41", "url": "https://www.reddit.com/user/Sanmartian41/"},
             "datePublished": "2025-08"},
            {"@type": "Quotation",
             "text": "My credit union is the best bank I've worked with, highly recommend looking into your options.",
             "creator": {"@type": "Person", "name": "wantondavis", "url": "https://www.reddit.com/user/wantondavis/"},
             "datePublished": "2024-02"},
        ]
    people = {"author": {"@type": "Person", "name": "Latoria Williams"},
              "editor": {"@type": "Person", "name": "Marsha Welch"},
              "reviewer": {"@type": "Person", "name": "Michael Lefler"}}
    if city == "Dallas":
        people = {
            "author": {"@type": "Person", "name": "Tara Wellema", "jobTitle": "Financial writer and editor",
                       "sameAs": ["https://www.linkedin.com/in/taralachapellewellema/"]},
            "editor": {"@type": "Person", "name": "Rebecca McClay", "jobTitle": "Financial editor",
                       "sameAs": ["https://www.linkedin.com/in/rebeccamcclay/"]},
            "reviewer": {"@type": "Person", "name": "Colin Scott", "jobTitle": "Financial adviser",
                         "sameAs": ["https://www.linkedin.com/in/paydayloansdallas/"]}}
    url = f"https://1firstcashadvance.org/{slug(city)}/"
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": url, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": "https://1firstcashadvance.org/loans-by-state/payday-loans-texas/"}, {"@type": "ListItem", "position": 4, "name": city}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": people["author"], "editor": people["editor"], "reviewedBy": people["reviewer"], "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}, **({"citation": citations} if citations else {})},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Payday loan matching in {city}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{city}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    for c in CITIES:
        if only and c["city"] not in only:
            continue
        p = os.path.join(OUT, slug(c["city"]) + "-NEW.html")
        open(p, "w", encoding="utf-8").write(build(c))
        print("wrote", p)


if __name__ == "__main__":
    main()
