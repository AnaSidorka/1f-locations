#!/usr/bin/env python3
"""Extract a build spec (JSON) from a finished v5 page.

Usage: python3 scripts/extract_spec.py <page.html> > specs/<slug>.json

The spec keeps every content section as a raw HTML body (exact bytes
between the <section> tag and </section>) plus structured fields for the
parts the builder regenerates: hero, JSON-LD, and the three <script>
blocks. scripts/build_page.py stitches them back with zebra classes.
"""
import json
import re
import sys

SECTION_MARKERS = [
    ("apply", "Three steps"),
    ("products", "What we offer"),
    ("qualify", "Before you start"),
    ("how", "How it works"),
    ("canyouget", "The short version"),
    ("offices", "Visit us"),
    ("calc", "Run the numbers"),
    ("stats", "Local data"),
    ("law", "The legal picture, in brief"),
    ("otherways", "Compare first"),
    ("carefully", 'class="resp"'),
    ("faq", "Still have questions?"),
    ("reviews", "What customers say"),
    ("cities", "Across the state"),
    ("authors", "Who wrote this"),
    ("links", "Keep exploring"),
]

SECTION_IDS = {"calc": "calc-sec", "links": "links-sec"}


def fail(msg):
    raise SystemExit(f"EXTRACT FAIL: {msg}")


def grab(pat, text, flags=re.S, group=1):
    m = re.search(pat, text, flags)
    if not m:
        fail(f"{pat[:90]!r} not found")
    return m.group(group)


def parse_jsonld(text, type_name, want_raw=False):
    for m in re.finditer(
            r'<script type="application/ld\+json">(.*?)</script>', text, re.S):
        try:
            obj = json.loads(m.group(1))
        except json.JSONDecodeError:
            continue
        if obj.get("@type") == type_name:
            return (obj, m.group(1)) if want_raw else obj
    fail(f"JSON-LD {type_name} not found")


def main(path):
    t = open(path, encoding="utf-8").read()
    spec = {}

    title_tag = grab(r"<title>(.*?)</title>", t)
    if not title_tag.endswith(" | 1F Cash Advance"):
        fail("unexpected <title> suffix")
    spec["title"] = title_tag[: -len(" | 1F Cash Advance")]

    hero = grab(r'<section class="hero">(.*?)</section>', t)
    spec["h1"] = grab(r"<h1>(.*?)</h1>", hero)
    spec["hero_state"] = grab(r"See what a licensed ([A-Za-z ]+?) lender", hero)
    spec["date"] = grab(r"Updated:\s*(.*?)\s*&middot;\s*Written by", hero)

    webpage = parse_jsonld(t, "WebPage")
    m = re.fullmatch(
        r"https://1firstcashadvance\.org/loans-by-state/([^/]+)/([^/]+)/",
        webpage["url"])
    if not m:
        fail("unexpected WebPage url")
    spec["state_slug"], spec["city_slug"] = m.group(1), m.group(2)
    if webpage["name"] != title_tag:
        fail("WebPage name != <title>")

    crumbs = parse_jsonld(t, "BreadcrumbList")["itemListElement"]
    spec["state"] = crumbs[2]["name"]
    spec["city"] = crumbs[3]["name"]

    service = parse_jsonld(t, "Service")
    spec["service_name"] = service["name"]
    m = re.fullmatch(r"[A-Za-z ]*loan matching in .+, ([A-Z]{2})",
                     service["name"])
    if not m:
        fail("unexpected Service name")
    spec["st"] = m.group(1)
    if service["areaServed"]["name"] != f"{spec['city']}, {spec['state']}":
        fail("Service areaServed mismatch")

    article = parse_jsonld(t, "Article")
    spec["published"] = article["datePublished"]
    spec["modified"] = article["dateModified"]
    if article["headline"] != spec["h1"]:
        fail("Article headline != h1")

    faq_ld_obj, faq_ld_raw = parse_jsonld(t, "FAQPage", want_raw=True)
    faq_ld = faq_ld_obj["mainEntity"]
    # two page generations wrap this block differently: Irvine has the
    # pretty-printed JSON on its own lines, later pages hug the tags
    spec["faq_ld_newlines"] = faq_ld_raw.startswith("\n")

    # --- sections, raw bodies + the exact separator before each ---
    matches = list(re.finditer(r'<section\b([^>]*)>(.*?)</section>', t, re.S))
    if not matches or 'class="hero"' not in matches[0].group(1):
        fail("hero section not first")
    sections = []
    seps = {}
    prev_end = matches[0].end()
    for m in matches[1:]:
        sections.append((m.group(1), m.group(2), t[prev_end:m.start()]))
        prev_end = m.end()

    bodies = {}
    zebra = {}
    for attrs, body, sep in sections:
        name = None
        for key, marker in SECTION_MARKERS:
            if marker in body:
                name = key
                break
        if name is None:
            fail(f"unrecognized section: {attrs} {body[:80]!r}")
        if name in bodies:
            fail(f"duplicate section {name}")
        bodies[name] = body
        cls = grab(r'class="([^"]+)"', attrs)
        zebra[name] = cls
        sec_id = re.search(r'id="([^"]+)"', attrs)
        expected_id = SECTION_IDS.get(name)
        if (sec_id.group(1) if sec_id else None) != expected_id:
            fail(f"section {name}: id mismatch ({attrs})")
        seps[name] = sep
    spec["sections"] = bodies
    spec["seps"] = seps
    spec["zebra"] = zebra  # recorded for verification; builder recomputes

    # --- FAQ (structured, drives JSON-LD) ---
    faqs = []
    for q, a in re.findall(
            r'<details class="faq">\s*<summary>(.*?)</summary>\s*'
            r'<div class="a">(.*?)</div>\s*</details>',
            bodies["faq"], re.S):
        faqs.append({"q": q.strip(), "a_html": a.strip()})
    if len(faqs) != len(faq_ld):
        fail("visible FAQ count != FAQPage count")
    for item, entity in zip(faqs, faq_ld):
        plain = re.sub(r"<[^>]+>", "", item["a_html"])
        if entity["name"] != item["q"]:
            fail(f"FAQPage question mismatch: {entity['name']!r}")
        if entity["acceptedAnswer"]["text"] != plain:
            fail(f"FAQPage answer mismatch for {item['q']!r}")
        item["a_text"] = plain

    spec["faqs"] = faqs

    # --- <script> blocks, raw bodies in page order ---
    spec["scripts"] = re.findall(r"<script>\n(.*?)</script>", t, re.S)
    if not spec["scripts"]:
        fail("no plain <script> blocks found")
    spec["has_reviews"] = "reviews" in bodies

    json.dump(spec, sys.stdout, indent=1, ensure_ascii=False)
    print()


if __name__ == "__main__":
    main(sys.argv[1])
