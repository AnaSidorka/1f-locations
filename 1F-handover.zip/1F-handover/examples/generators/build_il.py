#!/usr/bin/env python3
"""Build the six Illinois city pages (spec v3) into builds/2026-09-16-il/."""
import html, json, os, re, sys

ROOT = "/workspace"
OUT = os.path.join(ROOT, "builds/2026-09-16-il")
BASE = os.path.join(ROOT, "builds/Alabama Final/dothan-al-loans-NEW.html")

STATE, ST = "Illinois", "IL"
DATE, DATE_ISO, CUTOFF = "September 16, 2026", "2026-09-16", "11:30 am"
DEBT = {2020: 47610, 2021: 49480, 2022: 52580, 2023: 52780, 2024: 53390}
STATE_MHI_2024 = 83327

INIT = "https://idfpr.illinois.gov/initiatives.html"
AGFACT = "https://illinoisattorneygeneral.gov/Page-Attachments/PredatoryLoans.pdf"
CCPAGE = "https://idfpr.illinois.gov/about/brochures/dfibrochures/consumer-credit.html"
PLPAREL = "https://www.illinois.gov/content/dam/soi/en/web/illinois/iisnewsattachments/23232-idfpr-releases-consumer-frequently-asked-questions-about-the-predatory-loan-prevention-act.pdf"
COMPLAINT = "https://idfpr.illinois.gov/admin/complaints.html"


def hrs(close):
    return f"Open today 8:00 AM &ndash; {close}" if close else "Opens 8:00 AM &middot; call ahead for closing"


CITIES = [
 dict(city="Belleville", county="St. Clair County", fips="163",
      mhi={2020: 61863, 2021: 66422, 2022: 67185, 2023: 66007, 2024: 78110},
      offices=[("2 Carlyle Plaza Dr", "62221", hrs("5:00 PM")), ("1911 Carlyle Ave", "62223", hrs("4:00 PM")),
               ("1 S Church St #401", "62220", hrs("6:00 PM")), ("1109 Hartman Ln", "62221", hrs("5:00 PM"))],
      p1="Not the high-cost kind. Illinois caps nearly every consumer loan at 36% APR, payday loans included, and the rate has to count fees. Licensed installment lenders can go up to $40,000 under that same ceiling.",
      p2="St. Clair County income slipped in 2023 and then jumped in 2024, the largest one-year gain in the table below. A jump that sharp can make a bigger loan feel safe, but the payments stay fixed after a raise levels off, so size them to pay you already receive, not to the latest increase.",
      lbl4="Median household income in St. Clair County in 2024, the latest year in the table below",
      growth="County income grew about twenty-six percent in five years, against about twelve for state debt per person.",
      housing="Nearly three in ten households here",
      faq=[("Does the rate cap apply to my bank or credit union?",
            "The Predatory Loan Prevention Act does not cover consumer loans made by banks, savings banks, savings and loan associations, credit unions or insurance companies. Those lenders answer to their own regulators, so ask for the APR and the total cost in dollars before you borrow from one."),
           ("What sales pitches should make me cautious about a loan?",
            "The Attorney General's office flags promises such as easy credit, approval for anybody, no payments for months, and guaranteed approval regardless of credit history. It also warns about fees you were not told about ahead of time, which can be rolled quietly into the amount you borrow."),
           ("How fast could the money reach my account?",
            "If a lender approves you and the application is finalized by 11:30 am local time on a weekday, funds can arrive the same day. Later applications, weekends and bank holidays move funding to the next business day, and same-day deposit is not available to every customer.")]),
 dict(city="Champaign", county="Champaign County", fips="019",
      mhi={2020: 64387, 2021: 58787, 2022: 61205, 2023: 62169, 2024: 64240},
      offices=[("510 W Park Ave", "61820", hrs("5:00 PM")), ("301 S Mattis Ave", "61821", hrs("5:00 PM")),
               ("2512 N Prospect Ave", "61822", hrs("5:00 PM")), ("41 E Main St", "61820", hrs("5:00 PM")),
               ("2001 Round Barn Rd Ste A", "61821", hrs("5:30 PM"))],
      p1="Not at triple-digit rates. Since March 2021 a covered lender in Illinois cannot charge more than 36% APR with fees included, and almost every high-cost payday lender has handed back its state license. Larger licensed installment loans reach $40,000.",
      p2="Champaign County income fell in 2021 and, after three years of gains, still ended 2024 slightly below its 2020 level. When earnings only win back what they lost, there is little new room for a monthly payment, so borrow the smallest amount that covers the gap and test the payment against this year's pay.",
      lbl4="Median household income in Champaign County in 2024, the most recent year of county data shown below",
      growth="County income ended these five years about where it started; state debt per person rose about twelve percent.",
      housing="About a third of households here",
      faq=[("Is an online loan covered by the same rate cap?",
            "Yes. The state regulator says the Predatory Loan Prevention Act covers consumer loans made in Illinois through any medium, including the internet and the telephone. An online lender charging an Illinois borrower more than the cap faces the same rules as a storefront."),
           ("What if the lender was not licensed in Illinois?",
            "The Department of Financial and Professional Regulation says that when a lender required to hold a license makes loans without one, borrowers may not have to repay those loans. Check the lender on the Department's license look-up before signing, and report an unlicensed lender to the Department."),
           ("Can I apply from my phone?",
            "Yes. The request form works on a phone, stays open around the clock and takes about five minutes. Keep your pay stub and bank details handy, since the lender verifies your income and application details before deciding.")]),
 dict(city="Decatur", county="Macon County", fips="115",
      mhi={2020: 57601, 2021: 48245, 2022: 60648, 2023: 61033, 2024: 62679},
      offices=[("4284 Prospect Dr", "62526", hrs("5:00 PM")), ("3170 N Water St", "62526", hrs("5:30 PM")),
               ("1550 E Eldorado St", "62521", hrs("6:00 PM"))],
      p1="Not in the form payday loans used to take. Illinois law now holds covered loans, from payday to installment, to 36% APR all-in, so what a licensed lender offers is a capped loan, with installment amounts up to $40,000.",
      p2="Macon County income dropped sharply in 2021 before climbing back over the next three years. A fall like that shows how quickly a steady budget can shrink, and an installment payment keeps coming due either way, so before signing, make sure you could still cover it in a year like 2021.",
      lbl4="Median household income in Macon County in 2024, the highest of the five years in the table below",
      growth="County income grew about nine percent in five years, behind about twelve for state debt per person.",
      housing="Fewer than one in four households here",
      faq=[("Can a title lender take my car if I miss a payment?",
            "It can if your loan agreement gives the lender a security interest in the vehicle. The Department of Financial and Professional Regulation says the lender may then be able to repossess when you default, so read that clause before you sign and call the lender before a payment is missed."),
           ("A lender keeps urging me to refinance. Should I?",
            "Be careful. The Attorney General's office warns about lenders that push repeated refinancing without a real benefit to you, a practice it calls loan flipping. Each new loan can add fees, so compare the total cost of the new loan with finishing the one you have."),
           ("What should I have ready before I apply?",
            "A photo ID, your Social Security number, a checking account with its routing number and a recent pay stub or other proof of income. You also need proof of an Illinois address, a working phone and email, and to be at least 18.")]),
 dict(city="Peoria", county="Peoria County", fips="143",
      mhi={2020: 53506, 2021: 56460, 2022: 65421, 2023: 62873, 2024: 68190},
      offices=[("230 SW Adams St", "61602", hrs(None)), ("7815 Knoxville Ave #7-A", "61614", hrs("5:30 PM")),
               ("810 W Chalon Pl", "61614", hrs(None))],
      p1="Not the way it worked before 2021. Every covered consumer loan in Illinois is now limited to 36% APR, fees counted, and a licensed installment lender can lend as much as $40,000 within that limit.",
      p2="Peoria County income jumped in 2022, slipped in 2023 and reached a new high in 2024, yet it still sat $15,137 under the state median. With earnings that uneven, a fixed monthly payment is safest when it fits the weaker years, so test it against pay from a lean month before you sign.",
      lbl4="Median household income in Peoria County in 2024, the latest figure in the table below",
      growth="County income grew about twenty-seven percent in five years, well ahead of state debt per person.",
      housing="More than a quarter of households here",
      faq=[("I took out a high-rate loan before 2021. Do I still have to repay it?",
            "Yes. The rate cap applies to covered loans made from March 23, 2021 onward, and the state regulator says loans taken out before that date with a higher APR still have to be repaid. If you are struggling with one, talk to the lender about a payment arrangement."),
           ("How can I check that a lender is licensed?",
            "Use the license look-up on the Department of Financial and Professional Regulation website, which covers payday and consumer installment lenders. The state advises borrowing only from lenders it licenses or from federally regulated institutions such as banks and credit unions."),
           ("Does 1F Cash Advance lend the money?",
            "It does not. 1F Cash Advance is a loan connector: it passes one request to licensed lenders, and the lender that makes an offer sets the terms and funds the loan. Your agreement will name that lender, and that is the company the Illinois rules on this page apply to.")]),
 dict(city="Rockford", county="Winnebago County", fips="201",
      mhi={2020: 54971, 2021: 57113, 2022: 62557, 2023: 65795, 2024: 67363},
      offices=[("1070 W Riverside Blvd", "61103", hrs("6:00 PM")), ("1004 1st Ave", "61104", hrs("7:00 PM")),
               ("4215 E State St #208", "61108", hrs("10:00 PM"))],
      p1="Not a high-rate one. Illinois set a 36% APR ceiling, fees included, on payday and installment loans alike, and most high-cost payday lenders dropped off the state's license rolls. Licensed installment loans run up to $40,000.",
      p2="Winnebago County income rose in every year shown below yet finished 2024 some $15,964 under the state median. Steady growth from a lower base leaves less room for a new monthly bill than the trend suggests, so fit the payment inside what is left after rent and fixed costs, not inside the raise.",
      lbl4="Median household income in Winnebago County in 2024, the most recent year shown below",
      growth="County income rose nearly twenty-three percent across these five years, against about twelve for state debt per person.",
      housing="Nearly three in ten households here",
      faq=[("What if a lender charged me more than the cap on a recent loan?",
            "A covered loan made after March 23, 2021 with an APR above the limit is void, and the lender may not collect principal, fees or interest on it. You can report it to the Department of Financial and Professional Regulation or the Attorney General, or talk to a legal aid organization."),
           ("Does a wage advance app count as a loan under the cap?",
            "The state regulator lists wage advance products among the consumer loans the Predatory Loan Prevention Act covers, alongside payday, title and installment loans. Before you use one, add up every fee it charges and ask how the provider calculates the APR."),
           ("Does it cost anything to apply through 1F Cash Advance?",
            "The request form is free to use, and prequalifying runs a soft check that does not affect your credit score. Any charges come from the lender whose offer you accept, so read the rate and total cost in that offer before you agree.")]),
 dict(city="Springfield", county="Sangamon County", fips="167",
      mhi={2020: 60541, 2021: 68476, 2022: 73684, 2023: 73004, 2024: 78931},
      offices=[("234/236 S Dirksen Pkwy", "62702", hrs("5:30 PM")), ("3417 Freedom Dr", "62704", hrs("5:00 PM")),
               ("2727 S 6th St", "62703", hrs("5:30 PM"))],
      p1="Not above the state's cap. Payday, title and installment loans in Illinois all have to stay at or under 36% APR, fees counted, and licensed installment lenders can lend up to $40,000 within that rule.",
      p2="Sangamon County income dipped slightly in 2023 and then rose to its highest level in 2024, within $4,396 of the state median. Even a small dip can strain a budget that already carries a monthly loan payment, so leave room in that payment for a year that slips back the way 2023 did.",
      lbl4="Median household income in Sangamon County in 2024, the latest year in the table below",
      growth="County income grew about thirty percent, more than twice the rise in state debt per person.",
      housing="About one in four households here",
      faq=[("Who can I call about a lender in Illinois?",
            "The Department of Financial and Professional Regulation's Consumer Credit Section takes calls at 312-814-5145 in Chicago and 217-785-4244 at its Springfield office. The Attorney General's Springfield consumer hotline is 1-800-243-0618, and complaints can also be filed online with either agency."),
           ("Which loans fall under the rate cap?",
            "The state regulator lists payday loans, installment loans, title loans, pawn loans, car loans, retail installment contracts, buy-here-pay-here agreements, wage advance products and income share agreements. The cap applies whether the loan is made in person, online or by phone."),
           ("Can a lender charge me for paying a loan off early?",
            "Check before you sign. The Attorney General's office lists prepayment penalties, along with balloon payments due at the end, among the loan features to watch for. Ask whether either one is in the contract, and walk away from an offer that will not answer plainly.")]),
]


def slug(c):
    return c.lower().replace(" ", "-") + "-il-loans"


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build(c):
    if not c["offices"]:
        raise SystemExit(f"no offices for {c['city']} — ask the user first (P1-1)")
    base = open(BASE, encoding="utf-8").read()
    head = base[:base.find("</head>")]
    city, county = c["city"], c["county"]
    h1 = f"Short-term loans in {city}, {STATE}"
    title = f"{h1} | 1F Cash Advance"
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)
    assert "<!-- skill-version: v2 -->" in head
    fred_c = f"https://fred.stlouisfed.org/series/MHIIL17{c['fips']}A052NCEN"
    fred_s = "https://fred.stlouisfed.org/series/MHIIL17000A052NCEN"
    dp04 = f"https://fred.stlouisfed.org/series/DP04ACS017{c['fips']}"
    m24 = c["mhi"][2024]
    gap = STATE_MHI_2024 - m24
    gap_txt = f"{money(abs(gap))} {'below' if gap > 0 else 'above'}"
    gap_lbl = f"How far {county} sat {'under' if gap > 0 else 'above'} the {STATE} median in 2024"

    hs = base.find('<div class="topbar">'); he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he]
    hero = hero.replace("Payday Loans in Dothan, Alabama", h1).replace("licensed Alabama lender", f"licensed {STATE} lender")
    hero = hero.replace("Updated: September 3, 2026", f"Updated: {DATE}")
    assert "Dothan" not in hero and "Alabama" not in hero

    offices = "".join(
        f'<div class="office-card">\n<p class="office-addr">{html.escape(st)}<br>{city}, {ST} {z}</p>\n'
        f'<p class="office-hours">{hours}</p>\n</div>'
        for st, z, hours in c["offices"])

    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(c['mhi'][y])}</td><td>{money(DEBT[y])}</td><td>{money(round(c['mhi'][y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))

    others = [x["city"] for x in CITIES if x["city"] != city]
    links = " &middot; ".join(f'<a href="https://1firstcashadvance.org/{slug(o)}/">{o}</a>' for o in others)

    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in c["faq"])

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {city} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {city}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Short-Term Loans</h3>
        <p>A smaller loan for a short gap, made by a lender licensed in {STATE}. The schedule is set when you sign, so ask for each payment date and the total cost in dollars before you agree.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Short-Term Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>For a bigger need, an installment loan spreads repayment over a longer schedule with fixed payments. Ask for the total cost of credit in dollars and compare that figure across offers.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>Where to get payday loan {city}</h2>
    <div class="office-grid">
{offices}
</div>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {city}?</h2>
    <p>{c['p1']}</p>
    <p style="margin-top:14px">{c['p2']}</p>
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {city}: What the Numbers Show</h2>
<div class="stat-grid">
<div class="stat-card"><div class="num gold">Licenses handed back</div><div class="lbl">Almost every high-cost payday and auto title lender has given up its Illinois license</div><div class="src">Source: <a href="{INIT}">Illinois Department of Financial and Professional Regulation, initiatives</a></div></div>
<div class="stat-card"><div class="num navy">Fees count</div><div class="lbl">The capped rate folds in fees and charges, using the broad federal military lending definition</div><div class="src">Source: <a href="{AGFACT}">Illinois Attorney General predatory lending fact sheet</a></div></div>
<div class="stat-card"><div class="num navy">Rate-capped</div><div class="lbl">Payday, title and installment loans have sat under one statewide price limit since 2021</div><div class="src">Source: <a href="{CCPAGE}">IDFPR Consumer Credit Section</a></div></div>
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">{c['lbl4']}</div><div class="src">Source: <a href="{fred_c}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{gap_txt}</div><div class="lbl">{gap_lbl}</div><div class="src">Source: <a href="{fred_s}">Census SAIPE for Illinois via FRED</a></div></div>
<div class="stat-card"><div class="num navy">Void above the cap</div><div class="lbl">A covered loan priced over the limit is void, and the lender cannot collect on it</div><div class="src">Source: <a href="{PLPAREL}">IDFPR release on the Predatory Loan Prevention Act</a></div></div></div>
<p class="tbl-cap">{county} median household income and {STATE} household debt, 2020 to 2024</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{STATE} debt per person</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">County income comes from <a href="{fred_c}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column comes from the <a href="https://www.newyorkfed.org/microeconomics/databank.html">New York Fed Consumer Credit Panel</a>. {c['growth']} <a href="{dp04}">{c['housing']}</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. {STATE} limits what a covered loan can cost, and the lender still decides how much to offer, so the rate cap alone does not tell you what fits your budget. The last column is a calculation, not a published figure: monthly county income after the standard housing share. It describes a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>These are the small-loan rules for all of {STATE}, including {city}. In plain terms: what a lender may charge, what happens if it charges more, and who to call. Full detail is on the <a href="{CCPAGE}">Department of Financial and Professional Regulation consumer credit page</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
      <tr><td>Rate cap</td><td>36% APR on most consumer loans, including payday, title and installment loans, since March 23, 2021</td></tr>
      <tr><td>What the rate includes</td><td>Fees and charges, measured under the broad Military Lending Act definition</td></tr>
      <tr><td>Loans above the cap</td><td>Void: the lender cannot collect principal, fees or interest on a covered loan made after March 23, 2021</td></tr>
      <tr><td>Loans made earlier</td><td>Loans taken out before March 23, 2021 still have to be repaid</td></tr>
      <tr><td>Payday lenders</td><td>Still licensed under the Payday Loan Reform Act, though almost every high-cost payday lender has surrendered its license</td></tr>
      <tr><td>Installment loans</td><td>Licensed consumer installment lenders make loans of up to $40,000</td></tr>
      <tr><td>Unlicensed lenders</td><td>Borrowers may not have to repay a lender that needed a license and did not hold one</td></tr>
      <tr><td>Where to report it</td><td>The Department of Financial and Professional Regulation or the Attorney General's consumer hotline</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">The cap is a ceiling, not a price: a licensed lender may charge less, so ask for the APR and the total cost in dollars before you sign.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {city}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {city} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history rather than a credit score alone.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call your {county} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Check the license before anything else.</strong> Ask which state license the lender holds and confirm it with the regulator before you share your bank details.</li>
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Interest runs on the balance, and qualifying for more is not a reason to take more.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the payment schedule in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any small loan.</li>
      </ul>
      <p style="margin-bottom:0">To check a license or file a complaint, contact the <a href="{COMPLAINT}">Illinois Department of Financial and Professional Regulation</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{city} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>1F Cash Advance in Other {STATE} Cities</h2>
    <p style="max-width:760px">The same {STATE} rules apply statewide. See how they play out where you live:</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
"""
    a_s = base.rfind("<section", 0, base.find("Who wrote this")); a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e].replace("Houston County", county)
    assert "Dothan" not in authors and "Alabama" not in authors

    url = f"https://1firstcashadvance.org/{slug(city)}/"
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": url, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": "https://1firstcashadvance.org/loans-by-state/illinois/"}, {"@type": "ListItem", "position": 4, "name": city}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": {"@type": "Person", "name": "Latoria Williams"}, "editor": {"@type": "Person", "name": "Marsha Welch"}, "reviewedBy": {"@type": "Person", "name": "Michael Lefler"}, "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Short-term loan matching in {city}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{city}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    for c in CITIES:
        if only and c["city"] not in only:
            continue
        p = os.path.join(OUT, slug(c["city"]) + "-NEW.html")
        open(p, "w", encoding="utf-8").write(build(c))
        print("wrote", p)


if __name__ == "__main__":
    main()
