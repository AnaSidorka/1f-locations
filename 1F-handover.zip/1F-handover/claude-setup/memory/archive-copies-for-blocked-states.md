---
name: archive-copies-for-blocked-states
description: "KY, RI, UT — ссылки на законы ставятся без захода, тексты читались через Internet Archive; страницу Utah надо пересверить"
metadata: 
  node_type: memory
  type: project
  originSessionId: 4619a715-c6eb-4568-bf07-a25c41b36c91
  modified: 2026-09-21T07:43:04.874Z
---

Для **Kentucky, Rhode Island и Utah** владелец 21 сентября 2026 разрешил **ставить ссылки
на официальные URL законов, не открывая их** — исключение только для этих трёх штатов, потому что
`apps.legislature.ky.gov`, `webserver.rilegislature.gov` и `le.utah.gov` не принимают соединения
из среды сборки, а `dbr.ri.gov` и `dfi.utah.gov` отдают 403.

Сами цифры закона взяты не из памяти, а из **архивных копий официальных страниц** (Internet Archive):
KY — снимок 6 июля 2025, RI — 18 июня 2025, UT — **7 декабря 2024**.

**Why:** ссылка и факт — разные требования P0-1. Исключение владельца снимает первое, но цифры всё равно
должны восходить к прочитанному тексту, иначе это выдуманный факт в YMYL-контенте.

**How to apply:** когда сайты откроются, **сверить страницу Salt Lake City заново** — снимок Юты старше
года, и судьба законопроекта **S.B. 329 (2025) «Deferred Deposit Lending Modifications»** не установлена
(P0-3). Детали и все проверенные нормы — в `references/utah.md`, `references/kentucky.md`,
`references/rhode-island.md`. Связано с [[zip-from-geocoder]].
