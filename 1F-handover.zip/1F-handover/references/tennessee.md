# Tennessee — verified figures and ready state blocks

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11): deferred presentment
разрешён и лицензируется TDFI. Заголовок офисов — `Where to get payday loan {{City}}`.
Отсечка шага 3 — **11:30 am** (полоса LA/TN/AL/IL/TX/MS в P2-12).

## Источники — открыты 17 сентября 2026

Текст Tenn. Code Ann. Title 45 Chapter 17 официально публикуется только на LexisNexis; LexisNexis
и Justia в сессии не открылись. Цифры — из документов регулятора, которые ссылаются на секции закона.

| Документ | URL | Что даёт |
|---|---|---|
| TDFI, Consumer Notice: Deferred Presentment Services Act (август 2012) | https://www.tn.gov/content/dam/tn/financialinstitutions/documents/consumer_alert_deferred_presentment_law_change-internet_revised.pdf | 15%, 31 день, $500, 2/3 чека, запрет продления, взыскание, worthless check law, пункты договора |
| TDFI, Deferred Presentment (лицензирование) | https://www.tn.gov/tdfi/mortgage-consumer-lending/deferred-presentment.html | лицензия обязательна, в т. ч. для интернета и телефона (§45-17-103(a)) |
| TDFI, Flexible Credit Lenders | https://www.tn.gov/tdfi/mortgage-consumer-lending/flexible-credit.html | flex loan: open-end, с залогом или без, без фиксированного срока, досрочно без штрафа |
| TDFI, Consumer Complaint | https://www.tn.gov/tdfi/tdfi-how-do-i/file-a-complaint.html | онлайн-форма, 1-800-778-4215, порядок рассмотрения |
| TDFI, Consumer Resources | https://www.tn.gov/tdfi/consumer-resources.html | чего Department не делает (юрист, суд, дела в процессе) |
| Rule 0180-28-.01 (зеркало Cornell LII) | https://www.law.cornell.edu/regulations/tennessee/Tenn-Comp-R-Regs-0180-28-.01 | форма раскрытия всех сборов до сделки |
| Реестр Public Acts, Secretary of State | https://tnsos.org/acts/PublicActs.114.php | проверка изменений закона |

### Актуальность уведомления 2012 года — проверено

Реестр Public Acts (tnsos.org), поиск «presentment» по аннотациям: в **107-м** созыве (2011–2012)
два акта — ch. 205 и ch. 679, это изменения, которые и описывает уведомление. В **108–114-м**
созывах (2013–2026) — **ни одного** акта о deferred presentment. Поиск «title pledge» и «flex loan»
в тех же созывах находит акты — значит, поиск работает и пустой результат не случаен.

## Verified figures (по уведомлению TDFI, со ссылками на секции)

| Item | Verified value | Секция |
|---|---|---|
| Лицензия | обязательна, включая интернет, телефон, факс; достаточно склонить к сделке потребителя, находящегося в TN | 45-17-103(a) |
| Комиссия | не больше **15% от номинала чека** | 45-17-112(b) |
| Срок | договор не длиннее **31 дня** | 45-17-112(d) |
| У одного кредитора | не больше **двух** чеков от одного клиента, суммарный номинал **$500** | 45-17-112(o) |
| У заёмщика всего | не больше **трёх** займов одновременно, суммарный номинал **$500** | 45-17-112(p) |
| Продление | запрещено, как и консолидация в новый заём; такая сделка **void и unenforceable** | 45-17-112(q) |
| Возврат чека | гражданский иск только на **номинал чека и фактические судебные издержки**; других сборов и attorney's fees нет | 45-17-112(i) |
| Уголовка | заёмщика **нельзя осудить** по закону о worthless checks (§39-14-121) | 45-17-112(i) |
| «Чек» | с 2012 года включает любое разрешение на электронный платёж | уведомление |
| Запрещённые пункты | право другого штата, согласие на юрисдикцию другого штата или страны, выбор места суда, отказ от норм Act — **void** | 45-17-112(s) |
| Раскрытие | до сделки — форма со всеми сборами и издержками, по отдельности и итогом | Rule 0180-28-.01 |
| Жалобы | онлайн-форма TDFI; 1-800-778-4215; tdfi.consumerresources@tn.gov; жалобу передают компании за ответом | complaint page |

### Расчётные величины — помечать как расчёт

- Номинал $500 включает комиссию: 15% × $500 = **$75**, наличными **$425**.
- APR на 14 дней: $75 / $425 × 365 / 14 = **≈460%**.

### Внутренний гид — ссылку не ставить

https://1firstcashadvance.org/loans-by-state/tennessee/ (обновлён August 20, 2026): «up to $425», «15% of the
check amount or $17.65 for every $100», но в таблице считает $17.60 на $100 и **458.86% APR**;
точный расчёт от лимитов — ≈460%. Расхождение небольшое, но на городских страницах цифры
расходились бы с гидом — ссылка ведёт на уведомление TDFI.

### NOT verified — do not publish

- Текст самих секций 45-17-112 — не открывался (LexisNexis/Justia).
- Период ожидания между займами, база данных займов — в уведомлении нет.
- Условия flex loans (ставки, лимиты) — на странице TDFI только определение.

## Tennessee city parameters

| City | County | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Clarksville | Montgomery County | MHITN47125A052NCEN | DP04ACS047125 | 11:30 am |
| Dyersburg | Dyer County | MHITN47045A052NCEN | DP04ACS047045 | 11:30 am |
| Murfreesboro | Rutherford County | MHITN47149A052NCEN | DP04ACS047149 | 11:30 am |
| Nashville | Davidson County | MHITN47037A052NCEN | DP04ACS047037 | 11:30 am |
| Paris | Henry County | MHITN47079A052NCEN | DP04ACS047079 | 11:30 am |

Медиана штата: `MHITN47000A052NCEN`. Долг на душу: NY Fed, лист `total`, строка `TN`.
Nashville в Census — «Nashville-Davidson metropolitan government (balance)», целиком Davidson County.
Не писать «metro county» в Can-You-Get (P3-9).

## Ready state blocks

Форма блоков — как у Миссисипи и Южной Каролины (payday, первая форма).

### Tennessee Law at a Glance — 8 rows из 8, одна метка `§`
```html
<tr><td>Governing law</td><td>Deferred Presentment Services Act, Tenn. Code Ann. §45-17-101 and following, overseen by the Department of Financial Institutions</td></tr>
<tr><td>Checks outstanding</td><td>No more than $500 in total face value, with no more than two checks at one lender or three in all</td></tr>
<tr><td>Fee</td><td>Up to 15% of the check's face amount</td></tr>
<tr><td>Term</td><td>Up to 31 days</td></tr>
<tr><td>Renewal</td><td>Not allowed; a renewed or consolidated loan is void and cannot be enforced</td></tr>
<tr><td>Returned check</td><td>The lender may sue only for the face amount and court costs, with no other fees or attorney's fees</td></tr>
<tr><td>Worthless check law</td><td>A borrower cannot be convicted under the state's criminal worthless check law</td></tr>
<tr><td>Online lenders</td><td>Need a Tennessee license to lend to you while you are in the state</td></tr>
```
Мелкий шрифт: `Representative example: a check written at the top of the state limit carries a fee of up to $75, leaving about $425 in cash, and over 14 days that works out to about 460% APR. These are illustrative figures at the current limits, not quoted offers.`

### Шесть стат-карточек — правовые (1–3, 6)
| # | `.num` | Источник |
|---|---|---|
| 1 | `Max check` | TDFI consumer notice |
| 2 | `Percent of the check` | TDFI consumer notice |
| 3 | `Triple-digit` | TDFI consumer notice (расчёт из потолка) |
| 6 | `No conviction` | TDFI consumer notice |

Borrow Carefully — ссылка на https://www.tn.gov/tdfi/tdfi-how-do-i/file-a-complaint.html
(«Tennessee Department of Financial Institutions»).

## Distinct local angles (из таблицы SAIPE)
- Clarksville / Montgomery — рост каждый год, самый большой скачок в 2023, выше медианы штата.
- Dyersburg / Dyer — рост каждый год, самый большой в 2024, ниже медианы штата.
- Murfreesboro / Rutherford — спад в 2022, потом два сильных года, выше медианы на $18,111.
- Nashville / Davidson — рост до 2023, в 2024 почти без изменений; жилищная нагрузка 36.8%.
- Paris / Henry — рост каждый год, самый большой разрыв со штатом.
