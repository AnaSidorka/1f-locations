---
name: ohio-state-file
description: Ohio became the second prepared state on 2026-09-10; two Ohio claims are blacklisted
metadata: 
  node_type: memory
  type: project
  originSessionId: 91965656-19f0-4bba-82bc-cd6397548bf0
  modified: 2026-09-10T10:03:10.845Z
---

`references/ohio.md` создан 2026-09-10 при переделке страницы Dayton — Огайо стал вторым
подготовленным штатом после Луизианы. CLAUDE.md и SKILL.md обновлены в тот же день.

Два утверждения по Огайо занесены в чёрный список и не должны вернуться на страницы:
общий потолок «60% от суммы займа» (не найден в тексте ORC, только у Pew и в пересказах)
и «средний APR до реформы ≈ 591%». Главная ловушка штата: 28% — это потолок процентной
ставки, а не всеобъемлющий APR; ежемесячная плата за обслуживание и комиссия за выдачу
идут сверх неё.

**Why:** без этого файла следующий город Огайо (Akron, Toledo) рискует вернуть выдуманные
цифры, которые уже один раз попали на страницу Dayton.

**How to apply:** перед любой страницей Огайо читай `references/ohio.md` целиком, включая
раздел «NOT verified — do not publish».

Связано: [[russian-communication]]
