# Missouri — verified figures and ready state blocks

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11). Payday легален:
«small, small loans» по §§408.500, 408.505, 408.506 RSMo. Заголовок офисов — форма по умолчанию.
Can-You-Get открывается словом **Yes**. Отсечка шага 3 — **11:30 am** (центральный пояс).

## Источники — открыты 19 сентября 2026

**Сайт свода законов `revisor.mo.gov` не отвечает** (соединение висит), поэтому текст §408.500
не читался и ссылок на него нет. Всё ниже — со страниц регулятора **Missouri Division of Finance**.

| Документ | URL |
|---|---|
| Division of Finance, Payday Lenders | https://finance.mo.gov/consumer-credit-licensing/payday-lenders |
| Consumer Credit Licensing (обзор) | https://finance.mo.gov/consumercredit |
| Payday Lender Surveys (биеннале по §408.506) | https://finance.mo.gov/publications-and-reports/payday-lender-surveys |

## Verified figures

| Item | Verified value | Cite |
|---|---|---|
| Что это | payday loan = «small, small loan» — заём **$500 или меньше** | DoF, Payday Lenders |
| Лицензия | обязательна, выдаёт Division of Finance | DoF |
| Потолок цены | **75%** — предел процентов и сборов на первоначальный заём **и на продления** | DoF |
| Продления | **не больше шести** | DoF |
| Срок | **14–31 день** | DoF |
| Проценты | считаются **ежедневно** | DoF |
| Раскрытие | ставки вывешиваются на видном месте | DoF |
| Досрочное погашение | заёмщик, погасивший заём **до конца следующего полного рабочего дня**, не платит ни процентов, ни сборов | DoF |
| Регламенты | 20 CSR 1140-11.030 – 20 CSR 1140-11.040 | DoF |
| Отраслевой отчёт | Division of Finance обязана публиковать обзор рынка раз в два года | DoF; §408.506 |

### NOT verified — do not publish
- Текст §§408.500–408.506 RSMo и любые детали, которых нет на странице регулятора.
- Цифры биеннального обзора (PDF 2025 года — скан без текстового слоя, прочитать не удалось):
  средний APR, число лицензиатов, средний размер займа. **APR на странице не печатается.**
- Правила title lenders и consumer installment lenders — отдельные разделы, не читались.

## Missouri city parameters

| City | County | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Joplin | Jasper County | MHIMO29097A052NCEN | DP04ACS029097 | 11:30 am |

Медиана штата: `MHIMO29000A052NCEN`. Долг на душу: NY Fed, лист `total`, строка `MO`.

**Джоплин лежит в двух округах.** Город разделён между **Jasper** и **Newton**; данные берутся
по Jasper County с дословной геометкой, офис на E 32nd St по геокодеру в Newton — отмечается в отчёте.

## Ready state blocks

Форма — как у Миссисипи (первая форма): Products = Payday Loans + Installment Loans.
Блок 14 — форма одиночного города: `1F Cash Advance Across Missouri` + ссылка на страницу штата.

### Шесть стат-карточек — правовые (1–3, 6)
| # | `.num` | Источник |
|---|---|---|
| 1 | `Small-loan ceiling` | DoF |
| 2 | `Capped at 75%` | DoF |
| 3 | `Daily interest` | DoF |
| 6 | `Next-day exit` | DoF |

## Distinct local angles
- Joplin / Jasper County — доход рос каждый год с 2020, скачок в 2024, но в 2024 всё ещё на $9,567
  ниже медианы штата; жилищная нагрузка 27.3%; рост за пять лет ~21% против ~16% у долга на душу.
