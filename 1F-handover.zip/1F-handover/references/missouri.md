# Missouri — verified figures and ready state blocks

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11). Payday легален:
«small, small loans» по §§408.500, 408.505, 408.506 RSMo. Заголовок офисов — форма по умолчанию.
Can-You-Get открывается словом **Yes**. Отсечка шага 3 — **11:30 am** (центральный пояс).

## Источники — открыты 19 сентября 2026

**Сайт свода законов `revisor.mo.gov` не отвечает** (соединение висит), поэтому текст §408.500
не читался и ссылок на него нет. Всё ниже — со страниц регулятора **Missouri Division of Finance**.

| Документ | URL |
|---|---|
| Division of Finance, Payday Lenders | https://finance.mo.gov/consumer-credit-licensing/payday-lenders |
| Consumer Credit Licensing (обзор) | https://finance.mo.gov/consumercredit |
| Payday Lender Surveys (биеннале по §408.506) | https://finance.mo.gov/publications-and-reports/payday-lender-surveys |

## Verified figures

| Item | Verified value | Cite |
|---|---|---|
| Что это | payday loan = «small, small loan» — заём **$500 или меньше** | DoF, Payday Lenders |
| Лицензия | обязательна, выдаёт Division of Finance | DoF |
| Потолок цены | **75%** — предел процентов и сборов на первоначальный заём **и на продления** | DoF |
| Продления | **не больше шести** | DoF |
| Срок | **14–31 день** | DoF |
| Проценты | считаются **ежедневно** | DoF |
| Раскрытие | ставки вывешиваются на видном месте | DoF |
| Досрочное погашение | заёмщик, погасивший заём **до конца следующего полного рабочего дня**, не платит ни процентов, ни сборов | DoF |
| Регламенты | 20 CSR 1140-11.030 – 20 CSR 1140-11.040 | DoF |
| Отраслевой отчёт | Division of Finance обязана публиковать обзор рынка раз в два года | DoF; §408.506 |

### NOT verified — do not publish
- Текст §§408.500–408.506 RSMo и любые детали, которых нет на странице регулятора.
- Цифры биеннального обзора (PDF 2025 года — скан без текстового слоя, прочитать не удалось):
  средний APR, число лицензиатов, средний размер займа. **APR на странице не печатается.**
- Правила title lenders и consumer installment lenders — отдельные разделы, не читались.

## Missouri city parameters

| City | County | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Joplin | Jasper County | MHIMO29097A052NCEN | DP04ACS029097 | 11:30 am |
| Kansas City | Jackson County | MHIMO29095A052NCEN | DP04ACS029095 | 11:30 am |

Медиана штата: `MHIMO29000A052NCEN`. Долг на душу: NY Fed, лист `total`, строка `MO`.

**Джоплин лежит в двух округах.** Город разделён между **Jasper** и **Newton**; данные берутся
по Jasper County с дословной геометкой, офис на E 32nd St по геокодеру в Newton — отмечается в отчёте.

**Канзас-Сити лежит в четырёх округах** (Jackson, Clay, Platte, Cass). Данные берутся по
Jackson County — ядру города — с дословной геометкой `in Jackson County`. Не путать
с Kansas City, KS по другую сторону реки: другой штат, другие правила.

## Ready state blocks (change only {{City}}/{{County}})

Форма — как у Миссисипи (первая форма): Products = Payday Loans + Installment Loans.
Блок 14 — в Миссури два города набора (Joplin, Kansas City): на странице Joplin ссылка
`Kansas City` → `/kansas-city-mo-loans/`, на странице Kansas City ссылка `Joplin` →
`/joplin-mo-loans/`. Состав сверяется с `cities-99.md` на каждой сборке (P2-15).
(живость ссылки проверять при сборке).

**Статистика — v5:** правовые факты карточками не дублируются; они живут в Can-You-Get ¶1
и таблице закона. Стат-карточки — только две числовые (доход округа, разрыв со штатом).

### Loan Products (MO) — exactly 2 cards, без цифр внутри
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>Missouri calls it a small loan: one advance against your next paycheck, repaid in a single payment within about a month. Interest adds up daily, and state law caps the combined interest and fees a lender can charge over the life of the loan.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan repaid on a schedule instead of in one lump sum, with a fixed end date. If you need more time or a bigger amount, this usually works out cheaper than renewing a payday loan again and again.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a></div>
    </div>
  </div>
</section>
```

### Missouri Law at a Glance — 8 rows, меток для счётчика гейта нет
`RSMo` для регулярки невидимо (как `NRS`/`ORC`), но лимит «≤2 метки» держи вручную:
в таблице — ни одной видимой метки, глава названа словами.
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>Missouri Law at a Glance</h2>
    <p>These are the payday rules for all of Missouri, including {{City}}. Full legal detail is on the <a href="https://finance.mo.gov/consumer-credit-licensing/payday-lenders">Division of Finance payday-lending page</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>Missouri position</th></tr>
      <tr><td>Governing law</td><td>Small loans under Chapter 408 of the Revised Statutes of Missouri, licensed and overseen by the Division of Finance</td></tr>
      <tr><td>Maximum loan</td><td>$500 or less</td></tr>
      <tr><td>Total cost cap</td><td>Interest and fees together may not exceed 75% of the original loan amount, on the first loan and on every renewal</td></tr>
      <tr><td>Renewals</td><td>No more than six</td></tr>
      <tr><td>Loan term</td><td>14 to 31 days</td></tr>
      <tr><td>How interest accrues</td><td>Daily, so the cost grows with every extra day you hold the loan</td></tr>
      <tr><td>Next-day payoff</td><td>Repay in full before the end of the next full business day and you owe no interest and no fees</td></tr>
      <tr><td>Rate posting</td><td>Lenders must display their rates in a conspicuous place</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">These are the legal limits, not quoted offers. Your own charge and due date come from the lender and appear in the loan agreement.</p>
  </div>
</section>
```
Бюджет цифр: `$500` и `75%` — по одному вхождению в таблице; второе разрешённое место
каждой — Can-You-Get ¶1. Больше нигде на странице не повторять.

### Other Ways to Cover an Emergency (MO)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below a payday loan.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call a {{County}} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
```

### Borrow Carefully (MO) — 4 universal bullets, no $ figure
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Interest adds up daily, so every extra dollar and every extra day raises what you repay.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. A renewal adds cost, while an early payoff by the next business day costs nothing.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="https://finance.mo.gov/consumer-credit-licensing/payday-lenders">Missouri Division of Finance</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```

## Distinct local angles
- Joplin / Jasper County — доход рос каждый год с 2020, скачок в 2024, но в 2024 всё ещё на $9,567
  ниже медианы штата; жилищная нагрузка 27.3%; рост за пять лет ~21% против ~16% у долга на душу.
- Kansas City / Jackson County — ракурс подобрать по свежему ряду FRED при сборке;
  не дублировать джоплиновский («рос каждый год, но ниже штата»).
