#!/usr/bin/env python3
"""Build the seven Mississippi city pages (spec v3) into builds/2026-09-16-ms/."""
import html, json, os, re, sys

ROOT = "/Users/bamer/Downloads/VS CODE/1F Locations"
OUT = os.path.join(ROOT, "builds/2026-09-16-ms")
BASE = os.path.join(ROOT, "builds/Alabama Final/dothan-al-loans-NEW.html")

STATE, ST = "Mississippi", "MS"
DATE, DATE_ISO, CUTOFF = "September 16, 2026", "2026-09-16", "11:30 am"
DEBT = {2020: 34060, 2021: 35800, 2022: 38130, 2023: 39510, 2024: 40310}
STATE_MHI_2024 = 59301

PAMPHLET = "https://dbcf.ms.gov/wp-content/uploads/2020/06/Check-Cashers-Consumer-Education-Pamphlet-PDF.pdf"
ACT = "https://dbcf.ms.gov/wp-content/uploads/2020/06/MS-Check-Cashers-Act-PDF.pdf"
REGS = "https://dbcf.ms.gov/wp-content/uploads/2020/06/Check-Casher-Regulations-Effective-12-1-12-PDF.pdf"

CITIES = [
 dict(city="Columbus", county="Lowndes County", fips="087",
      mhi={2020: 47860, 2021: 49086, 2022: 49344, 2023: 53883, 2024: 56293},
      offices=[("507-4 18th Ave N, Town Square", "39705", "6:00 PM"), ("709 Alabama St", "39702", "5:00 PM"),
               ("429 Wilkins-Wise Rd", "39701", "5:00 PM"), ("1114 Gardner Blvd", "39702", "5:30 PM"),
               ("2217 Hwy 45 N", "39705", "6:00 PM"), ("1920 Hwy 45 N", "39705", "5:30 PM"),
               ("919 Alabama St", "39702", "6:00 PM"), ("1930 Military Rd", "39701", "6:00 PM"),
               ("1914 Hwy 45 N", "39705", "6:00 PM")],
      p1="Yes. A licensed lender here can hold your personal check for up to 30 days, written for no more than $500 with the fee inside it. The fee tops out at $21.95 per $100 advanced, and the state's two-week example runs 521.43% APR.",
      p2="Lowndes County income has risen in every year since 2020, but a rising county median says nothing about the date your own check is cashed. With renewals barred in Mississippi, the full check comes due at once, so date it to a payday already on your calendar rather than to an expected raise.",
      lbl4="Median household income in Lowndes County in 2024, the latest year in the table below",
      growth="County income and state debt per person both grew about eighteen percent across these five years.",
      housing="Nearly three in ten households here",
      faq=[("Can the lender take the payment straight from my bank account?",
            "It can, if your agreement says so. The contract may let the lender withdraw the amount from your account on the due date instead of depositing your check. You can also redeem the check yourself on or before that date, which keeps the timing in your hands."),
           ("Will I owe a late fee if I pay after the due date?",
            "Mississippi does not allow late fees or collection fees on a payday loan. The lender can charge one returned-check fee, and only if the agreement lists it. If the matter goes to court and the lender wins, court costs and attorney's fees can be added."),
           ("How can I check that a lender is licensed?",
            "The Mississippi Department of Banking and Consumer Finance publishes a list of licensed check cashers on its website. Match the company name on your agreement against that list before you sign. If something does not add up, the Department accepts complaints through an online form.")]),
 dict(city="Corinth", county="Alcorn County", fips="003",
      mhi={2020: 46368, 2021: 46712, 2022: 49627, 2023: 48556, 2024: 54635},
      offices=[("1015 US-72", "38834", "5:30 PM"), ("1808 S Fulton Dr", "38834", "5:00 PM"),
               ("700 S Cass St", "38834", "5:30 PM"), ("106 US-72", "38834", "5:00 PM")],
      p1="Yes. Mississippi's Check Cashers Act allows it: your check can reach $500 including the fee, you repay within 30 days, the fee can climb to $21.95 per $100, and the Department's two-week example equals 521.43% APR.",
      p2="Alcorn County income slipped in 2023 before jumping in 2024, so a strong year here has recently followed a weak one. A payday check is repaid in one piece on one date, and a month like 2023 leaves no room to adjust; borrow against wages already earned, not against another year like 2024.",
      lbl4="Median household income in Alcorn County in 2024, the highest of the five years in the table below",
      growth="County income rose nearly eighteen percent in these five years, in line with state debt per person.",
      housing="About one in four households here",
      faq=[("Can I pay only the fee and move the due date back?",
            "That is not allowed here. Mississippi law bars renewing, extending or rolling over a payday loan, so the full check has to be paid before a new loan can start. A lender that offers a fee-only extension is worth reporting to the Department of Banking and Consumer Finance."),
           ("Does stopping payment on my check get me out of the loan?",
            "It does not. A check returned for any reason, including a stop payment, a closed account or insufficient funds, can bring a one-time processing fee if your agreement discloses it, and the balance is still owed. Talking to the lender before the due date is the better route."),
           ("Can my spouse and I each write a check on our joint account?",
            "Yes, within limits. Mississippi's rules let each person on a joint account write delayed deposit checks up to the individual limit, but every check needs its own separate agreement. Each person counts against their own limit, and the household still repays every check from the same account.")]),
 dict(city="Greenwood", county="Leflore County", fips="083",
      mhi={2020: 34818, 2021: 31091, 2022: 35520, 2023: 33945, 2024: 39033},
      offices=[("623 W Park Ave", "38930", "6:00 PM")],
      p1="Yes, though the most you walk out with is about $410, since the $500 check limit counts the fee. That fee can reach $21.95 per $100, the loan lasts up to 30 days, and a two-week advance in the state's example costs 521.43% APR.",
      p2="Leflore County income fell in two of the five years shown below and finished 2024 some $20,268 under the state median. When pay runs that low and that uneven, the size of the check matters more than the fee rate, so keep it to an amount one ordinary paycheck can clear in full on the due date.",
      lbl4="Median household income in Leflore County in 2024, its highest point in the table below",
      growth="County income grew about twelve percent across these five years, against eighteen for state debt per person.",
      housing="One in three households here",
      faq=[("Will the lender give me a payment plan if I fall behind?",
            "You can ask, and it is better to ask before the due date than after it. A Mississippi payday lender is not required to agree, though, so do not build a plan into your decision about how much to borrow."),
           ("Can I be arrested if I cannot repay?",
            "Not over the loan. Mississippi does not allow a payday lender to threaten or use criminal prosecution to collect. The lender can still file a civil case, and if it wins, court costs and attorney's fees can be added to what you owe."),
           ("Can I cancel a larger installment loan after signing?",
            "A credit availability loan, the state's longer-term option, can be cancelled within one business day. If you accept the money inside that window, the origination fee is not refunded, so if you are unsure, wait to take the funds until you have decided.")]),
 dict(city="Gulfport", county="Harrison County", fips="047",
      mhi={2020: 47505, 2021: 54090, 2022: 55916, 2023: 56692, 2024: 63362},
      offices=[("3409 Washington Ave", "39507", "6:00 PM"), ("909 Pass Rd", "39501", "6:00 PM"),
               ("3125 25th Ave", "39501", "6:00 PM"), ("8325 Tennessee Ave", "39501", "6:00 PM"),
               ("2210 Pass Rd A", "39501", "5:00 PM")],
      p1="Yes, under rules that are the same statewide: one check of up to $500 with the fee counted in, a fee of up to $21.95 per $100, no more than 30 days to repay, and 521.43% APR in the state's own two-week example.",
      p2="Harrison County income climbed each year from 2020 to 2024 and ended above the Mississippi median, but higher local pay does not lift the state check limit. If you need more than one check allows, price a credit availability loan, repaid over months, before taking a payday check that covers only part of the gap.",
      lbl4="Median household income in Harrison County in 2024, up from its 2023 level",
      growth="County income grew about thirty-three percent in five years, well ahead of state debt per person at eighteen.",
      housing="Nearly a third of households here",
      faq=[("Does paying with a debit card cost extra?",
            "It can. Since July 1, 2026, Mississippi lets check cashers pass a card processor's fee on to you, limited to what the processor actually charges. The lender must tell you the amount before you complete the payment, so ask about it and compare it with paying another way."),
           ("Can I take a new payday loan from the same lender to pay off the old one?",
            "Mississippi does not allow it. A payday check cannot be repaid with the proceeds of another check cashed by the same lender or its affiliate, and the lender cannot renew or extend the loan. Plan to clear the full amount from income, not from a second advance."),
           ("Can I apply from my phone?",
            "Yes. The request form works on a phone, stays open around the clock and takes about five minutes. Keep your pay stub and bank details handy, since the lender verifies your income and application details before deciding.")]),
 dict(city="Laurel", county="Jones County", fips="067",
      mhi={2020: 49115, 2021: 44670, 2022: 58000, 2023: 50310, 2024: 53046},
      offices=[("121 S 15th Ave", "39440", "6:00 PM"), ("930 N 16th Ave", "39440", "6:00 PM"),
               ("1314 W 5th St", "39440", "6:00 PM"), ("127 S 16th Ave", "39440", "6:00 PM")],
      p1="Yes. Payday loans are legal in Mississippi, with the fee capped at $21.95 per $100 advanced and the check, fee included, capped at $500. Repayment comes within 30 days, and the state's two-week example works out to 521.43% APR.",
      p2="Jones County income peaked in 2022 and has stayed below that mark in both years since. A payday check assumes the next paycheck will look like the last good one, and Mississippi allows no renewal if it does not, so size the check to your pay today rather than to what households earned at the 2022 high.",
      lbl4="Median household income in Jones County in 2024, up from its 2023 level",
      growth="County income ended these five years about eight percent higher; state debt per person rose about eighteen.",
      housing="Fewer than one in four households here",
      faq=[("What does a larger installment loan cost?",
            "It is priced by the month rather than by the check. A credit availability lender can charge a handling fee of up to 25% of the unpaid principal each month, plus an origination fee of 1% of the amount or $5, whichever is more. Paying down principal early shrinks what that monthly fee is charged on."),
           ("Who can I call if a lender breaks the rules?",
            "Start with the Mississippi Department of Banking and Consumer Finance, which licenses payday lenders, at 1-800-844-2499 or through its online complaint form. Keep your agreement and receipts, since they show what you were told and what you were charged."),
           ("Is 1F Cash Advance the lender?",
            "It is not. 1F Cash Advance is a loan connector: it passes one request to licensed lenders, and the lender that makes an offer sets the terms and funds the loan. Your agreement will name that lender, and that is the company the Mississippi rules on this page apply to.")]),
 dict(city="Meridian", county="Lauderdale County", fips="075",
      mhi={2020: 44821, 2021: 44492, 2022: 49351, 2023: 51437, 2024: 56828},
      offices=[("600 19th Ave", "39301", "5:00 PM"), ("1410 14th St", "39301", "5:00 PM"),
               ("93 S Frontage Rd A", "39301", "6:00 PM"), ("2514 Riverbirch Dr #122", "39307", "5:30 PM"),
               ("2104 8th St", "39301", "5:00 PM")],
      p1="Yes. Up to 30 days, a check of up to $500 that already includes the fee, and a fee of at most $21.95 per $100: those are the state limits here, and the Department's two-week example on a smaller check prices out at 521.43% APR.",
      p2="Lauderdale County income dipped in 2021 and then rose three years running, closing to within $2,473 of the state median in 2024. A county recovery reaches paychecks unevenly, and a Mississippi payday check is due in full on one date, so set that date by the pay stub you already hold, not by the county trend.",
      lbl4="Median household income in Lauderdale County in 2024, the highest level in the table below",
      growth="County income grew about twenty-seven percent in five years, ahead of eighteen for state debt per person.",
      housing="Almost a third of local households",
      faq=[("Can I pay off my payday loan before the due date?",
            "Yes. You can redeem your check on or before the date in your agreement by paying the amount it covers. Doing it yourself means the lender never has to deposit the check or draw from your account, which removes the risk of a returned-item fee."),
           ("Can a lender sell me something extra along with the loan?",
            "Not as part of the deal. Mississippi bars payday lenders from offering discount catalog sales or similar inducements with a delayed deposit loan. If a purchase or add-on is presented as part of getting the money, decline it and mention it to the Department of Banking and Consumer Finance."),
           ("Does the check have to come from an open account?",
            "Yes. A Mississippi lender cannot advance money on a personal check unless you confirm it is drawn on a legitimate, open and active account. Use the account your pay goes into, since that is where the lender will collect on the due date.")]),
 dict(city="Tupelo", county="Lee County", fips="081",
      mhi={2020: 57936, 2021: 57597, 2022: 58266, 2023: 64744, 2024: 61826},
      offices=[("2250 W Main St Ste C", "38801", "6:00 PM"), ("1223 W Main St B", "38801", "6:00 PM"),
               ("779 E Main St", "38804", "6:00 PM"), ("1811 W Main St", "38801", "6:00 PM")],
      p1="Yes. Write a check for up to $500, fee included, and the lender holds it for as long as 30 days. Fees stop at $21.95 per $100 advanced, and Mississippi's own two-week example puts the cost at 521.43% APR.",
      p2="Lee County income slipped in 2024 from its 2023 high while still sitting above the Mississippi median. A budget built on last year's better pay is the one most likely to come up short on a single due date, so plan the repayment around what this year's paychecks actually bring in.",
      lbl4="Median household income in Lee County in 2024, the second highest year in the table below",
      growth="County income ended about seven percent above 2020, while state debt per person climbed about eighteen.",
      housing="About a quarter of households here",
      faq=[("How long do I get to repay a larger installment loan?",
            "That depends on the size. A smaller credit availability loan is repaid in equal payments over four to six months, and a larger one over six to twelve. You can pay it off at any time, and paying early may lower the fees you owe."),
           ("How fast could the money reach my account?",
            "If a lender approves you and the application is finalized by 11:30 am local time on a weekday, funds can arrive the same day. Later applications, weekends and bank holidays move funding to the next business day, and same-day deposit is not available to every customer."),
           ("What should I have ready before I apply?",
            "A photo ID, your Social Security number, a checking account with its routing number and a recent pay stub or other proof of income. You also need proof of a Mississippi address, a working phone and email, and to be at least 18.")]),
]


def slug(c):
    return c.lower().replace(" ", "-") + "-ms-loans"


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build(c):
    base = open(BASE, encoding="utf-8").read()
    head = base[:base.find("</head>")]
    city, county = c["city"], c["county"]
    h1 = f"Payday Loans in {city}, {STATE}"
    title = f"{h1} | 1F Cash Advance"
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)
    assert "<!-- skill-version: v2 -->" in head
    fred_c = f"https://fred.stlouisfed.org/series/MHIMS28{c['fips']}A052NCEN"
    fred_s = "https://fred.stlouisfed.org/series/MHIMS28000A052NCEN"
    dp04 = f"https://fred.stlouisfed.org/series/DP04ACS028{c['fips']}"
    m24 = c["mhi"][2024]
    gap = STATE_MHI_2024 - m24
    gap_txt = f"{money(abs(gap))} {'below' if gap > 0 else 'above'}"
    gap_lbl = f"How far {county} sat {'under' if gap > 0 else 'above'} the {STATE} median in 2024"

    # Hero (global, fixed) — copied from base, city/state swapped
    hs = base.find('<div class="topbar">'); he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he]
    hero = hero.replace("Payday Loans in Dothan, Alabama", h1).replace("licensed Alabama lender", f"licensed {STATE} lender")
    hero = hero.replace("Updated: September 3, 2026", f"Updated: {DATE}")
    assert "Dothan" not in hero and "Alabama" not in hero

    offices = "".join(
        f'<div class="office-card">\n<p class="office-addr">{html.escape(st)}<br>{city}, {ST} {z}</p>\n'
        f'<p class="office-hours">Open today 8:00 AM &ndash; {close}</p>\n</div>'
        for st, z, close in c["offices"])

    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(c['mhi'][y])}</td><td>{money(DEBT[y])}</td><td>{money(round(c['mhi'][y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))

    others = [x["city"] for x in CITIES if x["city"] != city]
    links = " &middot; ".join(f'<a href="https://1firstcashadvance.org/{slug(o)}/">{o}</a>' for o in others)

    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in c["faq"])

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {city} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {city}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A small advance against a personal check you write today. The lender holds the check until the date in your agreement, and you repay the full amount in one payment. It is built for a short gap between paychecks.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in monthly payments, not all at once. It is usually unsecured and has a set end date. If you need a bigger amount or more time, this is often cheaper than a payday loan.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>Where to get payday loan {city}</h2>
    <div class="office-grid">
{offices}
</div>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {city}?</h2>
    <p>{c['p1']}</p>
    <p style="margin-top:14px">{c['p2']}</p>
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {city}: What the Numbers Show</h2>
<div class="stat-grid">
<div class="stat-card"><div class="num gold">Max check</div><div class="lbl">The check you leave with the lender is capped by statute, and the fee counts toward the cap</div><div class="src">Source: <a href="{PAMPHLET}">Mississippi Department of Banking and Consumer Finance payday pamphlet</a></div></div>
<div class="stat-card"><div class="num navy">Two fee tiers</div><div class="lbl">Smaller checks carry a lower fee for each hundred dollars advanced than larger checks do</div><div class="src">Source: <a href="{ACT}">Mississippi Check Cashers Act, Miss. Code Ann. 75-67-519</a></div></div>
<div class="stat-card"><div class="num navy">Triple-digit</div><div class="lbl">The APR in the state's own disclosure example for a two-week advance, whatever your income</div><div class="src">Source: <a href="{REGS}">Department of Banking and Consumer Finance check casher regulations</a></div></div>
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">{c['lbl4']}</div><div class="src">Source: <a href="{fred_c}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{gap_txt}</div><div class="lbl">{gap_lbl}</div><div class="src">Source: <a href="{fred_s}">Census SAIPE for Mississippi via FRED</a></div></div>
<div class="stat-card"><div class="num navy">No arrest</div><div class="lbl">A lender cannot threaten or use criminal prosecution to collect on a payday loan</div><div class="src">Source: <a href="{PAMPHLET}">Mississippi Department of Banking and Consumer Finance payday pamphlet</a></div></div></div>
<p class="tbl-cap">{county} median household income and {STATE} household debt, 2020 to 2024</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{STATE} debt per person</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">County income comes from <a href="{fred_c}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column comes from the <a href="https://www.newyorkfed.org/microeconomics/databank.html">New York Fed Consumer Credit Panel</a>. {c['growth']} <a href="{dp04}">{c['housing']}</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. {STATE} sets a flat ceiling instead of an income test, so the amount does not change with local earnings. The last column is a calculation, not a published figure: monthly county income after the standard housing share. It describes a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>These are the payday rules for all of {STATE}, including {city}. In plain terms: how much you can get, what it costs, and what happens if you cannot pay on time. Full legal detail is in the <a href="https://1firstcashadvance.org/loans-by-state/mississippi/">{STATE} state guide</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
      <tr><td>Governing law</td><td>Mississippi Check Cashers Act, Miss. Code Ann. §75-67-501 and following, overseen by the Department of Banking and Consumer Finance</td></tr>
      <tr><td>Largest check</td><td>$500 including the fee, for each customer at any one time</td></tr>
      <tr><td>Fee</td><td>Up to $20 per hundred dollars advanced on checks of $250 or less, and $21.95 per hundred above that</td></tr>
      <tr><td>Term</td><td>Up to 30 days; a check over $250 is held 28 to 30 days, as you choose</td></tr>
      <tr><td>Renewal</td><td>Not allowed: the loan is paid in full before a new one can start</td></tr>
      <tr><td>Returned check</td><td>One NSF fee of up to $30, and only if the agreement discloses it</td></tr>
      <tr><td>Trouble repaying</td><td>You can ask for a payment plan, but the lender does not have to grant one</td></tr>
      <tr><td>Larger amounts</td><td>A credit availability loan under §75-67-601 and following, up to $3,320 and repaid over 4 to 12 months</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example: the Department's disclosure rule prices a $100 advance due in 14 days at 521.43% APR, and a check at the top of the range leaves about $410 in hand after a fee near $90. These are illustrative figures at the current limits, not quoted offers.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {city}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {city} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below payday.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call your {county} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. The fee grows with the amount advanced, so every extra dollar raises the charge.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you see a problem coming, talk to the lender before the date, not after it.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="https://dbcf.ms.gov/complaint-form/">Mississippi Department of Banking and Consumer Finance</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{city} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>1F Cash Advance in Other {STATE} Cities</h2>
    <p style="max-width:760px">The same {STATE} rules apply statewide. See how they play out where you live:</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
"""
    # Authors (global) — copied from base, county swapped
    a_s = base.rfind("<section", 0, base.find("Who wrote this")); a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e].replace("Houston County", county)
    assert "Dothan" not in authors and "Alabama" not in authors

    url = f"https://1firstcashadvance.org/{slug(city)}/"
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": url, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": "https://1firstcashadvance.org/loans-by-state/mississippi/"}, {"@type": "ListItem", "position": 4, "name": city}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": {"@type": "Person", "name": "Latoria Williams"}, "editor": {"@type": "Person", "name": "Marsha Welch"}, "reviewedBy": {"@type": "Person", "name": "Michael Lefler"}, "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Payday loan matching in {city}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{city}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    for c in CITIES:
        if only and c["city"] not in only:
            continue
        p = os.path.join(OUT, slug(c["city"]) + "-NEW.html")
        open(p, "w", encoding="utf-8").write(build(c))
        print("wrote", p)


if __name__ == "__main__":
    main()
