---
name: design-from-web-archive
description: Дизайн сайтов про займы строится по референсу из web.archive.org + символы штата; спрашивать ссылку до CSS.
metadata:
  type: feedback
---

Дизайн новых сайтов (lending-site-builder) строится по ссылке пользователя на web.archive.org: берётся настоящая сетка и CSS сайта того времени, перекрашенные в символы штата (флаг, звезда, контур со звездой города). Ссылку спрашивать до начала CSS. Принятый пример — Fort Worth Loan по главной CNN от 16.02.2006 в цветах Техаса (5 октября 2026: «заебись»).

**Why:** придуманный «шаблон 2006» с градиентами читался как ИИ, а голая колонка текста — как «пустой лист». Сайт с реальной сеткой по референсу понравился сразу.
**How to apply:** правило зафиксировано в агенте `~/.claude/agents/lending-site-builder.md` и в скилле `lending-law-site-builder` (design.md «Start from a Web Archive reference», scripts/state_svg.py). Связано с [[fort-worth-loan-site]].
