#!/usr/bin/env python3
"""Build the three Arizona city pages (spec v3) into builds/2026-09-17-az/."""
import html, json, os, re, sys

ROOT = "/workspace"
OUT = os.path.join(ROOT, "builds/2026-09-17-az")
BASE = os.path.join(ROOT, "builds/Alabama Final/dothan-al-loans-NEW.html")

STATE, ST = "Arizona", "AZ"
DATE, DATE_ISO, CUTOFF = "September 17, 2026", "2026-09-17", "10:30 am"
DEBT = {2020: 56250, 2021: 60090, 2022: 65600, 2023: 67270, 2024: 67820}
STATE_MHI_2024 = 81404

ARS601 = "https://www.azleg.gov/ars/6/00601.htm"
ARS632 = "https://www.azleg.gov/ars/6/00632.htm"
ARS613 = "https://www.azleg.gov/ars/6/00613.htm"
COMPLAINT = "https://www.azag.gov/complaints/consumer"


def hrs(close):
    return f"Open today 8:00 AM &ndash; {close}" if close else "Opens 8:00 AM &middot; call ahead for closing"


CITIES = [
 dict(city="Mesa", county="Maricopa County", fips="013",
      mhi={2020: 71799, 2021: 76230, 2022: 83668, 2023: 86973, 2024: 90919},
      offices=[("1938 W Baseline Rd", "85202", hrs("10:00 PM")), ("6750 E Main St #103", "85205", hrs("6:00 PM")),
               ("760 N Country Club Dr", "85201", hrs("6:00 PM"))],
      p1="No. What Arizona licenses instead is a consumer loan of up to $10,000 from a licensed lender, with the rate capped at 36% a year on the first part of the balance and a lower cap above that.",
      p2="Maricopa County income rose in every year shown below and ended 2024 above the state median. A higher county figure can make a bigger consumer loan look manageable, but the top rate still applies to the first dollars of any loan, so a larger balance does not buy a cheaper start; borrow only what closes the gap.",
      lbl4="Median household income in Maricopa County in 2024, the latest year in the table below",
      growth="County income grew about twenty-seven percent in five years, ahead of about twenty-one for state debt per person.",
      housing="About a third of households here",
      faq=[("Can a lender charge an origination fee?",
            "Yes, within limits. The fee can be no more than a set share of the loan and never above $150, and a lender cannot charge it again when it refinances your loan within a year of the last origination fee."),
           ("Do I have to buy credit insurance to get the loan?",
            "No lender may refuse you a consumer loan because you decline optional insurance. Only coverage on property that secures the loan can be required, and any insurance you do buy can be canceled within 30 days for a full refund of the premium."),
           ("How fast could the money reach my account?",
            "If a lender approves you and the application is finalized by 10:30 am local time on a weekday, funds can arrive the same day. Later applications, weekends and bank holidays move funding to the next business day, and same-day deposit is not available to every customer.")]),
 dict(city="Phoenix", county="Maricopa County", fips="013",
      mhi={2020: 71799, 2021: 76230, 2022: 83668, 2023: 86973, 2024: 90919},
      offices=[("2835 N 16th St Unit 6", "85006", hrs("7:00 PM")), ("2716 W Indian School Rd", "85017", hrs("7:00 PM")),
               ("2550 W Union Hills Dr Ste 350", "85027", hrs("5:00 PM")), ("4246 W Northern Ave", "85051", hrs("9:00 PM")),
               ("5050 W McDowell Rd", "85035", hrs("9:00 PM")), ("1728 W Bell Rd", "85023", hrs("9:00 PM")),
               ("10000 N 31st Ave Ste. C100-124", "85051", hrs("6:00 PM"))],
      p1="No. Licensed lenders in Arizona make consumer loans of $10,000 or less instead, and state law holds the rate to 36% a year on the first $3,000 and 24% on anything beyond it.",
      p2="Maricopa County income kept rising in 2024, but by only about half the jump it made in 2022. When raises slow, a monthly loan payment takes a bigger share of each new paycheck, so size the payment to the pay you have today rather than to the gains of earlier years.",
      lbl4="Median household income in Maricopa County in 2024, the highest of the five years in the table below",
      growth="Across these five years county income rose faster than state debt per person, roughly twenty-seven percent against twenty-one.",
      housing="Nearly a third of local households",
      faq=[("What happens if a lender charges more than the law allows?",
            "On a consumer loan of $5,000 or less, the loan becomes voidable and the lender has no right to collect any principal, finance charges or fees. On a larger loan, the lender loses the right to collect finance charges. Honest mistakes the lender can show are an exception."),
           ("Does the Arizona law cover lenders based in other states?",
            "Yes. State law requires a consumer lender license whether the lender is located in Arizona or in another state, unless an exemption applies. A consumer loan from a lender that needed that license and did not have it is void and cannot be collected."),
           ("Does 1F Cash Advance lend the money?",
            "It does not. 1F Cash Advance is a loan connector: it passes one request to licensed lenders, and the lender that makes an offer sets the terms and funds the loan. Your agreement will name that lender, and that is the company the Arizona rules on this page apply to.")]),
 dict(city="Tucson", county="Pima County", fips="019",
      mhi={2020: 56551, 2021: 60604, 2022: 64007, 2023: 69553, 2024: 71993},
      offices=[("3802 N Oracle Rd", "85705", hrs("6:00 PM")), ("2414 S 6th Ave", "85713", hrs("6:00 PM")),
               ("2355 N Swan Rd", "85712", hrs("6:00 PM")), ("3720 W Ina Rd #128", "85741", hrs("6:00 PM")),
               ("2245 E Irvington Rd Ste 110", "85714", hrs("6:00 PM")), ("5504 E 22nd St", "85711", hrs("6:00 PM")),
               ("727 W Ajo Way", "85713", hrs("6:00 PM"))],
      p1="No. The legal route in Arizona is a consumer loan from a licensed lender: no more than $10,000, and never more than 36% a year on the first slice of principal, with the allowed rate stepping down above it.",
      p2="Pima County income rose in every year shown below but still finished 2024 some $9,411 under the state median. On a budget below the state's typical household, a late installment brings its own charge, so set each due date a few days after payday rather than on it.",
      lbl4="Median household income in Pima County in 2024, the most recent year of county data shown below",
      growth="County income grew about twenty-seven percent in five years, well ahead of state debt per person.",
      housing="About a third of households here",
      faq=[("Can I be charged court costs or attorney fees if I fall behind?",
            "Court costs can be added. Attorney fees can be charged only if they are reasonable and the loan is sent for collection to an attorney who is not a salaried employee of the lender. Any charge the statute does not allow cannot be added."),
           ("Do banks and credit unions follow this law?",
            "Not this one. Banks, savings banks, credit unions and similar institutions are exempt when their loans are regulated under their own state or federal laws. Ask any lender, bank or not, for the annual percentage rate and the total cost in dollars."),
           ("What should I have ready before I apply?",
            "A photo ID, your Social Security number, a checking account with its routing number and a recent pay stub or other proof of income. You also need proof of an Arizona address, a working phone and email, and to be at least 18.")]),
]


def slug(c):
    return c.lower().replace(" ", "-") + "-az-loans"


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build(c):
    if not c["offices"]:
        raise SystemExit(f"no offices for {c['city']} — ask the user first (P1-1)")
    base = open(BASE, encoding="utf-8").read()
    head = base[:base.find("</head>")]
    city, county = c["city"], c["county"]
    h1 = f"Payday loan alternatives in {city}, {STATE}"
    title = f"{h1} | 1F Cash Advance"
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)
    assert "<!-- skill-version: v2 -->" in head
    fred_c = f"https://fred.stlouisfed.org/series/MHIAZ04{c['fips']}A052NCEN"
    fred_s = "https://fred.stlouisfed.org/series/MHIAZ04000A052NCEN"
    dp04 = f"https://fred.stlouisfed.org/series/DP04ACS004{c['fips']}"
    m24 = c["mhi"][2024]
    gap = STATE_MHI_2024 - m24
    gap_txt = f"{money(abs(gap))} {'below' if gap > 0 else 'above'}"
    gap_lbl = f"How far {county} sat {'under' if gap > 0 else 'above'} the {STATE} median in 2024"

    hs = base.find('<div class="topbar">'); he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he]
    hero = hero.replace("Payday Loans in Dothan, Alabama", h1).replace("licensed Alabama lender", f"licensed {STATE} lender")
    hero = hero.replace("Updated: September 3, 2026", f"Updated: {DATE}")
    assert "Dothan" not in hero and "Alabama" not in hero

    offices = "".join(
        f'<div class="office-card">\n<p class="office-addr">{html.escape(st)}<br>{city}, {ST} {z}</p>\n'
        f'<p class="office-hours">{hours}</p>\n</div>'
        for st, z, hours in c["offices"])

    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(c['mhi'][y])}</td><td>{money(DEBT[y])}</td><td>{money(round(c['mhi'][y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))

    others = [x["city"] for x in CITIES if x["city"] != city]
    links = " &middot; ".join(f'<a href="https://1firstcashadvance.org/{slug(o)}/">{o}</a>' for o in others)

    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in c["faq"])

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {city} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {city}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>The legal route in {STATE}. You repay in scheduled payments rather than in one lump sum, and the lender has to hold a state license. Ask for the total cost of credit in dollars before you sign.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Personal Loans</h3>
        <p>For a larger or longer need, a personal loan spreads repayment further and is priced on your credit and income. Compare the total cost in dollars against an installment loan rather than comparing monthly payments alone.</p>
        <a href="https://1firstcashadvance.org/personal-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Personal Loans &rarr;</a></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>Where to get payday loan alternatives in {city}</h2>
    <div class="office-grid">
{offices}
</div>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {city}?</h2>
    <p>{c['p1']}</p>
    <p style="margin-top:14px">{c['p2']}</p>
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {city}: What the Numbers Show</h2>
<div class="stat-grid">
<div class="stat-card"><div class="num gold">Consumer loans</div><div class="lbl">Licensed lenders in Arizona make consumer loans and revolving credit under the state consumer lender law</div><div class="src">Source: <a href="{ARS601}">Arizona Revised Statutes 6-601</a></div></div>
<div class="stat-card"><div class="num navy">State ceiling</div><div class="lbl">A consumer loan under the state lender law has a dollar ceiling written into statute</div><div class="src">Source: <a href="{ARS601}">Arizona Revised Statutes 6-601</a></div></div>
<div class="stat-card"><div class="num navy">Capped by size</div><div class="lbl">The highest rate a licensed lender may charge steps down on the part of a loan above a set amount</div><div class="src">Source: <a href="{ARS632}">Arizona Revised Statutes 6-632</a></div></div>
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">{c['lbl4']}</div><div class="src">Source: <a href="{fred_c}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{gap_txt}</div><div class="lbl">{gap_lbl}</div><div class="src">Source: <a href="{fred_s}">Census SAIPE for Arizona via FRED</a></div></div>
<div class="stat-card"><div class="num navy">Void if unlicensed</div><div class="lbl">A consumer loan from a lender that needed a license and did not have one cannot be collected</div><div class="src">Source: <a href="{ARS613}">Arizona Revised Statutes 6-613</a></div></div></div>
<p class="tbl-cap">{county} median household income and {STATE} household debt, 2020 to 2024</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{STATE} debt per person</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">County income comes from <a href="{fred_c}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column comes from the <a href="https://www.newyorkfed.org/microeconomics/databank.html">New York Fed Consumer Credit Panel</a>. {c['growth']} <a href="{dp04}">{c['housing']}</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. {STATE} sets a flat ceiling instead of an income test, so the amount does not change with local earnings. The last column is a calculation, not a published figure: monthly county income after the standard housing share. It describes a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>These are the small-loan rules for all of {STATE}, including {city}. In plain terms: what licensed lenders make instead of payday loans, what they may charge, and what happens when a lender breaks the rules. Full statutory text is in <a href="{ARS632}">Arizona Revised Statutes Title 6, Chapter 5</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
      <tr><td>Payday loans</td><td>Not a type of loan the consumer lender law authorizes; licensed lenders make consumer loans and revolving loans</td></tr>
      <tr><td>License</td><td>Required for any consumer lender, whether located in Arizona or another state, under §6-603</td></tr>
      <tr><td>Loan size</td><td>Consumer loans of $10,000 or less</td></tr>
      <tr><td>Rate cap</td><td>36% a year on the first $3,000, and 24% on any amount above that</td></tr>
      <tr><td>Origination fee</td><td>Up to 5% of the loan and no more than $150, and not again on a refinance within a year</td></tr>
      <tr><td>Late charge</td><td>5% of an installment still unpaid seven days after its due date</td></tr>
      <tr><td>Overcharges</td><td>On a loan of $5,000 or less, the lender loses the right to collect any principal, charges or fees</td></tr>
      <tr><td>Unlicensed lenders</td><td>A loan from a lender that needed a license and lacked one is void under §6-613</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Insurance sold with a consumer loan is optional, except coverage on property that secures it, and can be canceled within 30 days for a full refund of the premium. Ask for the APR and the total cost in dollars before you sign.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {city}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {city} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history rather than a credit score alone.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call the utility and ask about a payment plan and LIHEAP energy assistance for {county} households. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Check the license before anything else.</strong> Ask which state license the lender holds and confirm it with the regulator before you share your bank details.</li>
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Interest runs on the balance, and qualifying for more is not a reason to take more.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the payment schedule in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any small loan.</li>
      </ul>
      <p style="margin-bottom:0">To check a license, contact the Arizona Department of Insurance and Financial Institutions; to report a lender, file a complaint with the <a href="{COMPLAINT}">Arizona Attorney General</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{city} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>1F Cash Advance in Other {STATE} Cities</h2>
    <p style="max-width:760px">The same {STATE} rules apply statewide. See how they play out where you live:</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
"""
    a_s = base.rfind("<section", 0, base.find("Who wrote this")); a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e].replace("Houston County", county)
    assert "Dothan" not in authors and "Alabama" not in authors

    url = f"https://1firstcashadvance.org/{slug(city)}/"
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": url, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": "https://1firstcashadvance.org/loans-by-state/arizona/"}, {"@type": "ListItem", "position": 4, "name": city}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": {"@type": "Person", "name": "Latoria Williams"}, "editor": {"@type": "Person", "name": "Marsha Welch"}, "reviewedBy": {"@type": "Person", "name": "Michael Lefler"}, "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Payday loan alternative matching in {city}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{city}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    for c in CITIES:
        if only and c["city"] not in only:
            continue
        p = os.path.join(OUT, slug(c["city"]) + "-NEW.html")
        open(p, "w", encoding="utf-8").write(build(c))
        print("wrote", p)


if __name__ == "__main__":
    main()
