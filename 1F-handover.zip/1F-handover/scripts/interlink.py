#!/usr/bin/env python3
"""Add internal links to a city page's links-sec from the site crawl.

Usage:
    python3 scripts/interlink.py <page.html> [--dry-run]
             [--amounts N] [--ways N] [--blog N]

Rules (owner decision 02.11.2026):
- every added URL must exist in references/internal-links.csv as
  200 + Indexable (the crawl is the P0-1 source for link targets);
- no URL that the page already links to is added again — the existing
  interlinking blocks (links-sec columns, cities block) and in-text
  links are all checked, EXCEPT amount pages: those may recur between
  column 1 and the law table (accepted precedent: $255 on Irvine);
- column 1 (amounts): only amounts up to the state cap, inserted in
  ascending order, and only while the gate's "$N <= 2 occurrences"
  budget allows the extra bare "$N" token;
- ban-state pages (H1 "Payday loan alternatives ...") skip
  payday-product landings and payday-titled articles;
- picks rotate by a city seed so sibling pages get different sets.

The script rewrites the page in place. Run the gate afterwards.
"""
import csv

import re
import sys
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CSV_PATH = ROOT / "references" / "internal-links.csv"
BASE = "https://1firstcashadvance.org"

# amount -> (landing, max state cap it fits); caps from references/<state>.md
AMOUNT_URLS = {
    100: "/all-loans/100-dollar-loan/", 150: "/all-loans/150-dollar-loan/",
    200: "/all-loans/200-loans/", 250: "/all-loans/250-loan/",
    255: "/all-loans/255-dollar-loan/", 300: "/all-loans/300-loans/",
    400: "/all-loans/400-dollar-loan/", 500: "/all-loans/500-dollar-loan/",
    600: "/all-loans/600-dollar-loan/", 700: "/all-loans/700-loan/",
    800: "/all-loans/800-dollar-loan/", 1000: "/all-loans/1000-personal-loan/",
    1500: "/all-loans/1500-dollar-loan/", 2000: "/all-loans/2000-dollar-loan/",
    2500: "/all-loans/2500-personal-loan/", 3000: "/all-loans/3000-dollar-loan/",
}
# payday max by state; NV has no fixed cap (25% of income) — the page's
# own column tops out at $1,000, so that is the working ceiling
STATE_MAX = {"CA": 300, "NV": 1000, "MO": 500, "IN": 550, "OK": 500}
# ban states link installment-context amounts instead (GA cap: $3,000)
BAN_MAX = {"GA": 3000}
BAN_MAX_DEFAULT = 3000

WAYS_POOL = [
    ("/all-loans/second-chance-loans/", "Second Chance Loans"),
    ("/all-loans/tribal-loans/", "Tribal Loans"),
    ("/all-loans/fast-cash/", "Fast Cash Loans"),
    ("/all-loans/24-7-loan/", "24/7 Loans"),
    ("/all-loans/direct-deposit-loans/", "Direct Deposit Loans"),
    ("/payday-loans/weekend/", "Weekend Payday Loans"),
    ("/payday-loans/no-teletrack/", "No Teletrack Payday Loans"),
    ("/payday-loans/direct-lenders/", "Direct Lender Payday Loans"),
    ("/payday-loans/guaranteed/", "Guaranteed Payday Loans"),
    ("/payday-loans/1-hour/", "1-Hour Payday Loans"),
    ("/payday-loans/no-fax/", "No Fax Payday Loans"),
    ("/all-loans/high-risk-loans-guaranteed-approval/", "High-Risk Loans"),
    ("/personal-loans/secured/", "Secured Personal Loans"),
    ("/personal-loans/unsecured/", "Unsecured Personal Loans"),
    ("/personal-loans/holiday/", "Holiday Loans"),
    ("/personal-loans/vacation-loans/", "Vacation Loans"),
    ("/personal-loans/dental-financing/", "Dental Financing"),
    ("/installment-loan/guaranteed-installment-loans-for-bad-credit/",
     "Guaranteed Installment Loans"),
]

BLOG_POOL = [
    ("/articles/payday-apr-by-state/", "Payday APR by State", True),
    ("/articles/payday-lenders-by-state/", "Where Payday Lenders Cluster", True),
    ("/articles/payday-loan-term-length-by-state/", "Payday Term Length by State", True),
    ("/articles/payday-lending-where-america-is-richest-and-where-it-is-poorest/",
     "Payday Lending, Richest and Poorest", True),
    ("/articles/how-many-americans-use-payday-loans-each-year/",
     "How Many Americans Use Payday Loans", True),
    ("/articles/loans-for-the-unemployed/", "Loans for the Unemployed", False),
    ("/articles/loans-for-ride-share-drivers/", "Loans for Rideshare Drivers", False),
    ("/articles/loans-for-400-credit-score/", "Loans with a 400 Credit Score", False),
    ("/articles/600-credit-score/", "Loans with a 600 Credit Score", False),
    ("/articles/loans-for-groceries/", "Loans for Groceries", False),
    ("/articles/personal-loans-vs-credit-cards/", "Personal Loans vs. Credit Cards", False),
    ("/articles/what-are-your-options-if-you-cant-pay-for-auto-repairs/",
     "How to Pay for Car Repairs", False),
    ("/articles/home-repair-loans/", "Home Repair Loans", False),
    ("/articles/emergency-cash-for-single-mothers/",
     "Emergency Cash for Single Mothers", False),
    ("/articles/loans-for-18-year-olds/", "Loans for 18-Year-Olds", False),
    ("/articles/small-business-loans/", "Small Business Loans", False),
    ("/articles/title-loans/", "What Are Title Loans", False),
    ("/articles/loans-with-car-as-collateral/", "Loans with a Car as Collateral", False),
    ("/articles/line-of-credit-vs-loan/", "Line of Credit vs. Loan", False),
    ("/articles/ways-to-make-extra-money/", "Ways to Make Extra Money", False),
    ("/articles/money-making-hobbies/", "Hobbies That Make Money", False),
    ("/articles/what-is-a-signature-loan/", "What Is a Signature Loan", False),
    ("/articles/crypto-loans-vs-short-term-loans/", "Crypto Loans vs. Short-Term Loans", False),
    ("/articles/how-to-ask-for-money-politely/", "How to Ask for Money Politely", False),
    ("/articles/engagement-ring-financing-bad-credit/", "Engagement Ring Financing", False),
    ("/articles/how-to-get-approved-for-a-cell-phone-with-bad-credit/",
     "Cell Phone Financing", False),
    ("/articles/computer-financing/", "Computer Financing", False),
    ("/articles/finance-washer-and-dryer/", "Washer and Dryer Financing", False),
    ("/articles/artist-loans/", "Artist Loans", False),
    ("/articles/can-i-get-a-payday-loan-in-another-state/",
     "Payday Loans in Another State", True),
    ("/articles/small-loan/", "Small Loan Options", False),
    ("/articles/how-to-fill-out-a-loan-application-form/",
     "How to Fill Out a Loan Application", False),
    ("/articles/emergency-loans-for-rent/", "Loans for Rent", False),
    ("/articles/i-need-money-now/", "Emergency Cash Options", False),
    ("/articles/500-credit-score/", "What a 500 Credit Score Means", False),
    ("/articles/unexpected-expenses/", "Common Unexpected Expenses", False),
    ("/articles/loans-for-gig-workers/", "Loans for Gig Workers", False),
    ("/articles/emergency-loans-for-medical-bills/", "Medical Bill Loans", False),
    ("/articles/get-a-payday-loan-without-a-bank-account/",
     "Loans Without a Bank Account", True),
    ("/articles/loans-for-people-on-disability/", "Loans for People on Disability", False),
    ("/articles/loan-apps/", "Top Loan Apps", False),
    ("/articles/short-term-loans/", "Short-Term Loan Options", False),
]


def fail(msg):
    raise SystemExit(f"INTERLINK FAIL: {msg}")


def load_live_urls():
    if not CSV_PATH.exists():
        fail(f"{CSV_PATH} missing — the crawl is the link source")
    live = set()
    with open(CSV_PATH, encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            if row["Status Code"] == "200" and row["Indexability"] == "Indexable":
                live.add(row["Address"][len(BASE):])
    return live


def page_text(html):
    t = re.sub(r"<script.*?</script>", "", html, flags=re.S)
    t = re.sub(r"<style.*?</style>", "", t, flags=re.S)
    return re.sub(r"<[^>]+>", "", t)


def bare_dollar_count(text, amount):
    token = f"${amount:,}"
    return len(re.findall(rf"\${amount:,}(?![\d,])", text))


def split_columns(section):
    """Return list of (h3, ul_html) for the three link-col columns."""
    cols = []
    for m in re.finditer(
            r'<div class="link-col">\s*<h3>([^<]+)</h3>\s*<ul>(.*?)</ul>',
            section, re.S):
        cols.append((m.group(1), m.group(2), m.span()))
    if len(cols) != 3:
        fail(f"expected 3 link-col columns, found {len(cols)}")
    return cols


def main():
    args = sys.argv[1:]
    if not args:
        fail("usage: interlink.py <page.html> [--dry-run] [--amounts N] "
             "[--ways N] [--blog N]")
    page_path = Path(args[0])
    dry = "--dry-run" in args

    def opt(name, default):
        if name in args:
            return int(args[args.index(name) + 1])
        return default

    want_amounts = opt("--amounts", 2)
    want_ways = opt("--ways", 2)
    want_blog = opt("--blog", 2)

    html = page_path.read_text(encoding="utf-8")
    live = load_live_urls()

    h1 = re.search(r"<h1>(.*?)</h1>", html)
    if not h1:
        fail("no <h1>")
    ban_mode = h1.group(1).startswith("Payday loan alternatives")

    svc = re.search(r'"@type": "Service", "name": "[A-Za-z ]*loan matching in '
                    r'.+, ([A-Z]{2})"', html)
    if not svc:
        fail("state not found in Service JSON-LD")
    st = svc.group(1)
    city = re.search(r'<span class="b-current">([^<]+)</span>', html)
    city_name = city.group(1) if city else page_path.stem

    sec_m = re.search(r'<section class="[^"]*" id="links-sec">.*?</section>',
                      html, re.S)
    if not sec_m:
        fail("links-sec not found")
    section = sec_m.group(0)
    cols = split_columns(section)

    linked = set(re.findall(rf'href="{re.escape(BASE)}([^"]*)"', html))
    linked = {u.split("#")[0] for u in linked}
    text = page_text(html)
    seed = zlib.crc32(city_name.encode())

    plan = {"amounts": [], "ways": [], "blog": []}

    # --- column 1: amounts, ascending, within state cap and $ budget ---
    cap = (BAN_MAX.get(st, BAN_MAX_DEFAULT) if ban_mode
           else STATE_MAX.get(st))
    if cap is None:
        fail(f"no amount cap for state {st} — extend STATE_MAX from "
             f"references/{st.lower()}.md")
    # page-spec §1 block 16: a figure that sits in the law table must not
    # join the amounts list (e.g. Irvine's $300 maximum-check row)
    law_figures = set()
    law_m = re.search(r'<table class="rate-table">.*?</table>', html, re.S)
    if law_m:
        law_figures = {int(x.replace(",", "").rstrip("."))
                       for x in re.findall(r"\$([\d,]+)", law_m.group(0))}

    col1_urls = set(re.findall(rf'href="{re.escape(BASE)}([^"]+)"', cols[0][1]))
    candidates = [n for n in sorted(AMOUNT_URLS)
                  if n <= cap
                  and (n != 255 or st == "CA")  # $255 is the CA $300-minus-fee product
                  and n not in law_figures
                  and AMOUNT_URLS[n] not in col1_urls
                  and AMOUNT_URLS[n] in live
                  and bare_dollar_count(text, n) <= 1]
    start = seed % max(len(candidates), 1)
    ordered = candidates[start:] + candidates[:start]
    plan["amounts"] = ordered[:want_amounts]

    # --- column 2: ways ---
    pool = [(u, a) for u, a in WAYS_POOL
            if u in live and u not in linked
            and not (ban_mode and u.startswith("/payday-loans/"))]
    start = seed % max(len(pool), 1)
    pool = pool[start:] + pool[:start]
    plan["ways"] = pool[:want_ways]

    # --- column 3: blog ---
    pool = [(u, a) for u, a, payday in BLOG_POOL
            if u in live and u not in linked
            and not (ban_mode and payday)]
    start = seed % max(len(pool), 1)
    pool = pool[start:] + pool[:start]
    plan["blog"] = pool[:want_blog]

    print(f"{city_name}, {st} (ban_mode={ban_mode}, cap=${cap:,})")
    print(f"  amounts: {['$' + format(n, ',') for n in plan['amounts']]}")
    for u, a in plan["ways"]:
        print(f"  way:  {a} -> {u}")
    for u, a in plan["blog"]:
        print(f"  blog: {a} -> {u}")
    if dry:
        print("  (dry run, file untouched)")
        return

    # --- apply: rebuild the links-sec section column by column ---
    new_section = section

    def li(url, anchor):
        return (f'          <li><a href="{BASE}{url}">'
                f"{anchor}</a></li>\n")

    def column_ul(sec, h3):
        m = re.search(r'(<h3>' + re.escape(h3) + r'</h3>\s*<ul>)(.*?)(</ul>)',
                      sec, re.S)
        if not m:
            fail(f"column {h3!r} not found")
        return m

    def rewrite_column(sec, h3, new_ul):
        m = column_ul(sec, h3)
        return sec[:m.start()] + m.group(1) + new_ul + m.group(3) \
            + sec[m.end():]

    # amounts: ascending insertion into column 1
    if plan["amounts"]:
        h3 = cols[0][0]
        ul = column_ul(new_section, h3).group(2)
        for n in plan["amounts"]:
            new_li = li(AMOUNT_URLS[n], f"${n:,} Loan")
            items = list(re.finditer(
                r'<li><a href="[^"]+">\$([\d,]+) Loan</a></li>', ul))
            insert_at = None
            for it in items:
                if int(it.group(1).replace(",", "")) > n:
                    insert_at = ul.rfind("\n", 0, it.start()) + 1
                    break
            if insert_at is None:
                more_m = re.search(r'          <li class="more">', ul)
                if not more_m:
                    fail("col1 more-row not found")
                insert_at = more_m.start()
            ul = ul[:insert_at] + new_li + ul[insert_at:]
        new_section = rewrite_column(new_section, h3, ul)

    # ways + blog: append before the more-row
    for col_idx, picks in ((1, plan["ways"]), (2, plan["blog"])):
        if not picks:
            continue
        h3 = cols[col_idx][0]
        ul = column_ul(new_section, h3).group(2)
        more_m = re.search(r'          <li class="more">', ul)
        if not more_m:
            fail(f"column {h3!r}: more-row not found")
        add = "".join(li(u, a) for u, a in picks)
        ul = ul[:more_m.start()] + add + ul[more_m.start():]
        new_section = rewrite_column(new_section, h3, ul)

    if new_section == section and any(plan.values()):
        fail("section rewrite produced no change — inspect the parser")
    html = html.replace(section, new_section)
    page_path.write_text(html, encoding="utf-8")
    print(f"  wrote {page_path}")


if __name__ == "__main__":
    main()
