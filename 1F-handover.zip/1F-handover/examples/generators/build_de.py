#!/usr/bin/env python3
"""Build the Milford, Delaware page (spec v3) into builds/2026-09-19-de/."""
import html, json, os, re, sys

ROOT = "/Users/bamer/Downloads/VS CODE/1F Locations"
OUT = os.path.join(ROOT, "builds/2026-09-19-de")
BASE = os.path.join(ROOT, "builds/Alabama Final/dothan-al-loans-NEW.html")

STATE, ST, SFIPS = "Delaware", "DE", "10"
DATE, DATE_ISO, CUTOFF = "September 19, 2026", "2026-09-19", "12:30 pm"
DEBT = {2020: 56430, 2021: 58280, 2022: 61490, 2023: 62870, 2024: 64010}
STATE_MHI_2024 = 87510
STATE_GUIDE = "https://1firstcashadvance.org/loans-by-state/delaware/"

C22 = "https://delcode.delaware.gov/title5/c022/index.html"
SC03 = "https://delcode.delaware.gov/title5/c022/sc03/index.html"
SC01 = "https://delcode.delaware.gov/title5/c022/sc01/index.html"

CARD1 = ('<div class="stat-card"><div class="num gold">Loan ceiling</div><div class="lbl">A short-term consumer loan is capped by statute, '
         'and the repayment period runs under two months</div><div class="src">Source: <a href="' + SC03 + '">5 Del. C. 2227, Delaware Code</a></div></div>')
CARD2 = ('<div class="stat-card"><div class="num navy">No rate cap</div><div class="lbl">The rate comes from the agreement you sign, because the chapter sets no ceiling on it</div>'
         '<div class="src">Source: <a href="' + SC03 + '">5 Del. C. 2229 and 2237, Delaware Code</a></div></div>')
CARD3 = ('<div class="stat-card"><div class="num navy">Five a year</div><div class="lbl">The number of these loans one borrower may take from all licensed lenders in twelve months</div>'
         '<div class="src">Source: <a href="' + SC03 + '">5 Del. C. 2235A, Delaware Code</a></div></div>')
CARD6 = ('<div class="stat-card"><div class="num navy">Void over the limit</div><div class="lbl">A loan past that yearly limit cannot be collected at all, principal included</div>'
         '<div class="src">Source: <a href="' + SC03 + '">5 Del. C. 2235A, Delaware Code</a></div></div>')

LAW_INTRO = ('The chapter is <a href="' + C22 + '">Title 5, Chapter 22 of the Delaware Code</a>, and the Office of the State Bank Commissioner licenses the lenders.')
LAW_ROWS = """      <tr><td>Governing law</td><td>Licensed Lenders, 5 Del. C. Chapter 22, with lenders licensed by the Office of the State Bank Commissioner</td></tr>
      <tr><td>Loan size</td><td>A short-term consumer loan is $1,000 or less, with a stated repayment period under 60 days</td></tr>
      <tr><td>Rate and fees</td><td>Set by the loan agreement: the chapter fixes no ceiling, and other state rate limits do not apply</td></tr>
      <tr><td>Loans a year</td><td>Five from all licensed lenders in any twelve months, counting rollovers and refinancings</td></tr>
      <tr><td>Past that limit</td><td>The loan is void, and the lender may not collect or keep principal, interest or fees</td></tr>
      <tr><td>Rollovers</td><td>Four at most on one loan, after which the lender may offer a workout agreement</td></tr>
      <tr><td>Workout agreement</td><td>Equal payments over at least 90 days, with no added fee or interest for the switch</td></tr>
      <tr><td>Cancelling</td><td>Return the full amount by the close of the next business day and owe nothing extra</td></tr>"""
LAW_FINE = ('Delaware does not publish a representative price for this loan, because it sets no ceiling on the rate. '
            'Every lender must post its own schedule of rates and fees at the door and on its website, next to the statement that a payday loan '
            'is not intended to meet long-term financial needs. Read that schedule before you sign.')
STATS_FINE = ('Delaware caps the size of this loan and the number you may take in a year, but not its price, so the cost comes from the agreement rather than from local earnings.')
BC_FIRST = ('<li><strong>Read the posted schedule first.</strong> With no ceiling in law, the lender\'s own schedule of rates and fees is the price. '
            'Ask for it in writing before you fill in an application.</li>')
REG_LINE = ('To verify a lender or file a complaint, contact the Delaware Office of the State Bank Commissioner or the federal CFPB.')
UTILITY_CARD = ('<div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or heating bill, call your {county} community action agency. '
                'Ask about energy bill assistance and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>')

H1_TMPL = "Payday Loans in {city}, {STATE}"
OFFICE_H2_TMPL = "Where to get payday loan {city}"
PRODUCTS = """      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A small advance against a personal check you write today. The lender holds the check until the date in your agreement, and you repay the full amount in one payment. It is built for a short gap between paychecks.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in monthly payments, not all at once. It is usually unsecured and has a set end date. If you need a bigger amount or more time, this is often cheaper than a payday loan.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>"""

CITIES = [
 dict(city="Milford", county="Kent County", fips="001",
      mhi={2020: 61538, 2021: 64670, 2022: 71866, 2023: 72498, 2024: 78240},
      offices=[("643 N Dupont Blvd", "19963", "5:00 PM"), ("1051 N Walnut St", "19963", "5:00 PM"),
               ("100 Credit Union Way", "19963", "5:00 PM"), ("20140 Cedar Beach Rd", "19963", "5:00 PM")],
      p1="Yes. Delaware licenses short-term loans of $1,000 or less with a stated repayment period under 60 days. The state sets no ceiling on the rate, so the price is whatever your agreement says, and five such loans a year is the limit.",
      p2="Kent County income rose in every year since 2020 and still ended 2024 below the state median. The price of this loan comes from the agreement rather than from law, so a household under the median has to do that arithmetic itself: ask for the cost in dollars, then measure it against one month of take-home pay.",
      lbl4="Median household income in Kent County in 2024, the latest year in the table below",
      growth="County income grew about twenty-seven percent across these five years, against thirteen for state debt per person.",
      housing="About three in ten households here",
      faq=[("Can the lender roll the loan over if I cannot pay?",
            "Up to four times on one loan, and every rollover counts against your five-loan limit for the year. After the fourth, the lender may offer a workout agreement instead: equal payments over at least 90 days, with no extra fee or interest for making the switch."),
           ("What if I change my mind the day after I borrow?",
            "Return the full amount by the close of the next business day and the loan costs you nothing. That right applies to every short-term loan in the state. Sundays and legal holidays do not count as business days, so money taken on Saturday can go back on Monday."),
           ("How fast could the money reach my account?",
            "If a lender approves you and the application is finalized by 12:30 pm local time on a weekday, funds can arrive the same day. Later applications, weekends and bank holidays move funding to the next business day, and same-day deposit is not available to every customer.")]),
]
def slug(c):
    return c.lower().replace(" ", "-") + f"-{ST.lower()}-loans"


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build(c):
    base = open(BASE, encoding="utf-8").read()
    head = base[:base.find("</head>")]
    city, county = c["city"], c["county"]
    h1 = H1_TMPL.format(city=city, STATE=STATE)
    title = f"{h1} | 1F Cash Advance"
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)
    assert "<!-- skill-version: v2 -->" in head
    fred_c = f"https://fred.stlouisfed.org/series/MHI{ST}{SFIPS}{c['fips']}A052NCEN"
    fred_s = f"https://fred.stlouisfed.org/series/MHI{ST}{SFIPS}000A052NCEN"
    dp04 = f"https://fred.stlouisfed.org/series/DP04ACS0{SFIPS}{c['fips']}"
    m24 = c["mhi"][2024]
    gap = STATE_MHI_2024 - m24
    gap_txt = f"{money(abs(gap))} {'below' if gap > 0 else 'above'}"
    gap_lbl = f"How far {county} sat {'under' if gap > 0 else 'above'} the {STATE} median in 2024"

    # Hero (global, fixed) — copied from base, city/state swapped
    hs = base.find('<div class="topbar">'); he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he]
    hero = hero.replace("Payday Loans in Dothan, Alabama", h1).replace("licensed Alabama lender", f"licensed {STATE} lender")
    hero = hero.replace("Updated: September 3, 2026", f"Updated: {DATE}")
    assert "Dothan" not in hero and "Alabama" not in hero

    offices = "".join(
        f'<div class="office-card">\n<p class="office-addr">{html.escape(st)}<br>{city}, {ST} {z}</p>\n'
        f'<p class="office-hours">' + ("Open 24 hours" if close == "24" else f"Open today 8:00 AM &ndash; {close}") + '</p>\n</div>'
        for st, z, close in c["offices"])

    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(c['mhi'][y])}</td><td>{money(DEBT[y])}</td><td>{money(round(c['mhi'][y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))

    others = [x["city"] for x in CITIES if x["city"] != city]
    links = " &middot; ".join(f'<a href="https://1firstcashadvance.org/{slug(o)}/">{o}</a>' for o in others)

    office_h2 = OFFICE_H2_TMPL.format(city=city)
    utility_card = UTILITY_CARD.format(county=county)
    src_lead = globals().get("SRC_LEAD", "County income")
    tbl_cap = globals().get("TBL_CAP", f"{county} median household income and {STATE} household debt, 2020 to 2024")
    debt_col = globals().get("DEBT_COL", f"{STATE} debt per person")
    if others:
        links_h2 = f"1F Cash Advance in Other {STATE} Cities"
        links_intro = f"The same {STATE} rules apply statewide. See how they play out where you live:"
    else:
        links_h2 = globals().get("LINKS_H2", f"1F Cash Advance Across {STATE}")
        links_intro = f"The same {STATE} rules apply statewide, in every town and county."
        links = f'<a href="{STATE_GUIDE}">{STATE} payday loan rules &rarr;</a>'

    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in c["faq"])

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {city} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {city}</h2>
    <div class="prod-grid">
{PRODUCTS}
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>{office_h2}</h2>
    <div class="office-grid">
{offices}
</div>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {city}?</h2>
    <p>{c['p1']}</p>
    <p style="margin-top:14px">{c['p2']}</p>
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {city}: What the Numbers Show</h2>
<div class="stat-grid">
{CARD1}
{CARD2}
{CARD3}
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">{c['lbl4']}</div><div class="src">Source: <a href="{fred_c}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{gap_txt}</div><div class="lbl">{gap_lbl}</div><div class="src">Source: <a href="{fred_s}">Census SAIPE for {STATE} via FRED</a></div></div>
{CARD6}</div>
<p class="tbl-cap">{tbl_cap}</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{debt_col}</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">{src_lead} comes from <a href="{fred_c}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column comes from the <a href="https://www.newyorkfed.org/microeconomics/databank.html">New York Fed Consumer Credit Panel</a>. {c['growth']} <a href="{dp04}">{c['housing']}</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. {STATS_FINE} The last column is a calculation, not a published figure: monthly county income after the standard housing share. It describes a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>These are the payday rules for all of {STATE}, including {city}. In plain terms: how much you can get, what it costs, and what happens if you cannot pay on time. {LAW_INTRO}</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
{LAW_ROWS}
    </table>
    <p class="fine" style="margin-top:12px">{LAW_FINE}</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {city}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {city} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below payday.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      {utility_card}
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        {BC_FIRST}
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you see a problem coming, talk to the lender before the date, not after it.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">{REG_LINE}</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{city} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>{links_h2}</h2>
    <p style="max-width:760px">{links_intro}</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
"""
    # Authors (global) — copied from base, county swapped
    a_s = base.rfind("<section", 0, base.find("Who wrote this")); a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e].replace("Houston County", county)
    assert "Dothan" not in authors and "Alabama" not in authors

    url = f"https://1firstcashadvance.org/{slug(city)}/"
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": url, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": STATE_GUIDE}, {"@type": "ListItem", "position": 4, "name": city}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": {"@type": "Person", "name": "Latoria Williams"}, "editor": {"@type": "Person", "name": "Marsha Welch"}, "reviewedBy": {"@type": "Person", "name": "Michael Lefler"}, "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Payday loan matching in {city}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{city}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    for c in CITIES:
        if only and c["city"] not in only:
            continue
        p = os.path.join(OUT, slug(c["city"]) + "-NEW.html")
        open(p, "w", encoding="utf-8").write(build(c))
        print("wrote", p)


if __name__ == "__main__":
    main()
