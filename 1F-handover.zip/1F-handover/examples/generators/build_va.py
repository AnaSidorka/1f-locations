#!/usr/bin/env python3
"""Build the two Virginia city pages (spec v3) into builds/2026-09-18-va/."""
import html, json, os, re, sys

ROOT = "/Users/bamer/Downloads/VS CODE/1F Locations"
OUT = os.path.join(ROOT, "builds/2026-09-18-va")
BASE = os.path.join(ROOT, "builds/Alabama Final/dothan-al-loans-NEW.html")

STATE, ST = "Virginia", "VA"
DATE, DATE_ISO, CUTOFF = "September 18, 2026", "2026-09-18", "12:30 pm"
DEBT = {2020: 66530, 2021: 69870, 2022: 74110, 2023: 75140, 2024: 75670}
STATE_MHI_2024 = 92116

CH18 = "https://law.lis.virginia.gov/vacode/title6.2/chapter18/"
S1816 = "https://law.lis.virginia.gov/vacode/title6.2/chapter18/section6.2-1816.1/"
S1817 = "https://law.lis.virginia.gov/vacode/title6.2/chapter18/section6.2-1817/"
S18183 = "https://law.lis.virginia.gov/vacode/title6.2/chapter18/section6.2-1818.3/"
PAMPHLET = "https://law.lis.virginia.gov/admincode/title10/agency5/chapter200/section80/"


def hrs(close):
    return f"Open today 8:00 AM &ndash; {close}" if close else "Opens 8:00 AM &middot; call ahead for closing"


CITIES = [
 dict(city="Richmond", county="Richmond City", fips="760",
      mhi={2020: 54815, 2021: 52011, 2022: 58719, 2023: 64903, 2024: 63865},
      offices=[("3608 Mechanicsville Tpke", "23223", hrs("6:00 PM")), ("7312 Staples Mill Rd", "23228", hrs("9:00 PM")),
               ("123 E Broad St", "23219", hrs("6:00 PM")), ("7101 Forest Hill Ave Ste T", "23225", hrs("5:30 PM"))],
      p1="Not the old two-week kind. Virginia's short-term loan runs four to 24 months, tops out at $2,500, and carries interest of no more than 36% a year plus a single monthly maintenance fee.",
      p2="Income in Richmond City fell in 2021, climbed for two years and then eased again in 2024, ending the run far under the state median. A loan here is repaid across months rather than on one payday, so test the monthly payment against a year like 2021 instead of the best year in the table below.",
      lbl4="Median household income in Richmond City in 2024, just under its 2023 level",
      growth="City income grew about seventeen percent in five years, ahead of about fourteen for state debt per person.",
      housing="Four in ten households here",
      faq=[("Can I cancel the loan after I sign?",
            "Yes. You may cancel until 5 p.m. on the third business day after the agreement by returning the money you received, in cash or another accepted form. The lender must then mark your agreement canceled, return it to you, and hand back any check you left as security."),
           ("Can a lender make this loan to someone on active duty?",
            "No lender may. Virginia bars short-term loans to members of the armed forces serving on active duty, and to their spouses and dependents. If that is your household, ask about credit union and bank options instead."),
           ("How fast could the money reach my account?",
            "If a lender approves you and the application is finalized by 12:30 pm local time on a weekday, funds can arrive the same day. Later applications, weekends and bank holidays move funding to the next business day, and same-day deposit is not available to every customer.")]),
 dict(city="Lynchburg", county="Lynchburg City", fips="680",
      mhi={2020: 56089, 2021: 52127, 2022: 50494, 2023: 58962, 2024: 57883},
      offices=[("2126 Wards Rd A", "24502", hrs("6:00 PM")), ("4012 Wards Rd Ste B", "24502", hrs("5:30 PM")),
               ("2134 Langhorne Rd", "24501", hrs("5:00 PM")), ("1210 Greenview Dr", "24502", hrs("5:00 PM")),
               ("2828 Candlers Mountain Rd", "24502", hrs("5:00 PM"))],
      p1="Not in the single-payment form. A licensed short-term loan in Virginia is capped at $2,500 and repaid in equal installments over four to 24 months, with interest held to 36% a year and one monthly fee on top.",
      p2="Income in Lynchburg City fell in 2021 and again in 2022, rebounded sharply in 2023 and slipped in 2024, finishing barely above where it stood in 2020. With that little net progress, a payment that only fits in a good month is a risk, so borrow small and use the right to pay the loan off early.",
      lbl4="Median household income in Lynchburg City in 2024, close to its 2020 level",
      growth="City income ended these five years up about three percent; state debt per person rose about fourteen.",
      housing="More than a third of households here",
      faq=[("What happens if I pay the loan off early?",
            "You may prepay in full at any time without a penalty, and the lender must refund a prorated share of the fees and charges you paid, apart from late charges and returned payment fees. The refund is due in cash or a business check within two business days."),
           ("Can the lender threaten me with criminal charges if a payment fails?",
            "It cannot. Virginia bars a short-term lender from threatening or starting criminal proceedings over a bounced check or an unpaid balance, and collection must follow the federal Fair Debt Collection Practices Act. A lender may sue only 60 days or more after a default."),
           ("Does an out-of-state online lender have to follow these rules?",
            "Yes. The chapter applies to anyone making short-term loans over the internet to people in Virginia, whether or not the lender has an office in the state, and a license is required either way.")]),
]


def slug(c):
    return c.lower().replace(" ", "-") + "-va-loans"


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build(c):
    if not c["offices"]:
        raise SystemExit(f"no offices for {c['city']} — ask the user first (P1-1)")
    base = open(BASE, encoding="utf-8").read()
    head = base[:base.find("</head>")]
    city, county = c["city"], c["county"]
    h1 = f"Short-term loans in {city}, {STATE}"
    title = f"{h1} | 1F Cash Advance"
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)
    assert "<!-- skill-version: v2 -->" in head
    fred_c = f"https://fred.stlouisfed.org/series/MHIVA51{c['fips']}A052NCEN"
    fred_s = "https://fred.stlouisfed.org/series/MHIVA51000A052NCEN"
    dp04 = f"https://fred.stlouisfed.org/series/DP04ACS051{c['fips']}"
    m24 = c["mhi"][2024]
    gap = STATE_MHI_2024 - m24
    gap_txt = f"{money(abs(gap))} {'below' if gap > 0 else 'above'}"
    gap_lbl = f"How far {county} sat {'under' if gap > 0 else 'above'} the {STATE} median in 2024"

    hs = base.find('<div class="topbar">'); he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he]
    hero = hero.replace("Payday Loans in Dothan, Alabama", h1).replace("licensed Alabama lender", f"licensed {STATE} lender")
    hero = hero.replace("Updated: September 3, 2026", f"Updated: {DATE}")
    assert "Dothan" not in hero and "Alabama" not in hero

    offices = "".join(
        f'<div class="office-card">\n<p class="office-addr">{html.escape(st)}<br>{city}, {ST} {z}</p>\n'
        f'<p class="office-hours">{hours}</p>\n</div>'
        for st, z, hours in c["offices"])

    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(c['mhi'][y])}</td><td>{money(DEBT[y])}</td><td>{money(round(c['mhi'][y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))

    others = [x["city"] for x in CITIES if x["city"] != city]
    links = " &middot; ".join(f'<a href="https://1firstcashadvance.org/{slug(o)}/">{o}</a>' for o in others)

    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in c["faq"])

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {city} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {city}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Short-Term Loans</h3>
        <p>Virginia's regulated small loan. It is repaid in equal monthly installments over months rather than on one payday, and only a licensed lender may offer it. Ask for each payment date and the total cost in dollars before you agree.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Short-Term Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>For a bigger need, an installment loan spreads repayment over a longer schedule with fixed payments. Ask for the total cost of credit in dollars and compare that figure across offers.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>Where to get payday loan {city}</h2>
    <div class="office-grid">
{offices}
</div>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {city}?</h2>
    <p>{c['p1']}</p>
    <p style="margin-top:14px">{c['p2']}</p>
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {city}: What the Numbers Show</h2>
<div class="stat-grid">
<div class="stat-card"><div class="num gold">One at a time</div><div class="lbl">A borrower may have only one short-term loan outstanding, and the law sets its dollar ceiling</div><div class="src">Source: <a href="{S1816}">Code of Virginia 6.2-1816.1</a></div></div>
<div class="stat-card"><div class="num navy">Interest plus one fee</div><div class="lbl">A lender may charge interest and a single monthly maintenance fee, and nothing else</div><div class="src">Source: <a href="{S1817}">Code of Virginia 6.2-1817</a></div></div>
<div class="stat-card"><div class="num navy">Capped total</div><div class="lbl">Fees and charges together cannot pass a set share of the amount first borrowed</div><div class="src">Source: <a href="{S18183}">Code of Virginia 6.2-1818.3</a></div></div>
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">{c['lbl4']}</div><div class="src">Source: <a href="{fred_c}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{gap_txt}</div><div class="lbl">{gap_lbl}</div><div class="src">Source: <a href="{fred_s}">Census SAIPE for Virginia via FRED</a></div></div>
<div class="stat-card"><div class="num navy">Three-day cancel</div><div class="lbl">You may cancel by 5 p.m. on the third business day by returning the money you received</div><div class="src">Source: <a href="{PAMPHLET}">Virginia short-term lending pamphlet, 10VAC5-200-80</a></div></div></div>
<p class="tbl-cap">{county} median household income and {STATE} household debt, 2020 to 2024</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{STATE} debt per person</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">County income comes from <a href="{fred_c}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column comes from the <a href="https://www.newyorkfed.org/microeconomics/databank.html">New York Fed Consumer Credit Panel</a>. {c['growth']} <a href="{dp04}">{c['housing']}</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. {STATE} limits what a covered loan can cost, and the lender still decides how much to offer, so the rate cap alone does not tell you what fits your budget. The last column is a calculation, not a published figure: monthly county income after the standard housing share. It describes a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>These are the short-term loan rules for all of {STATE}, including {city}. In plain terms: how much you can borrow, how long you have, what it can cost and what you can do if something goes wrong. Full statutory text is in <a href="{CH18}">Code of Virginia, Chapter 18</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
      <tr><td>Governing law</td><td>Short-Term Loans, Code of Virginia §6.2-1800 and following, supervised by the Bureau of Financial Institutions</td></tr>
      <tr><td>Loan size</td><td>Up to $2,500, and only one short-term loan at a time</td></tr>
      <tr><td>Term</td><td>Four to 24 months, and shorter only when the monthly payment stays inside a small share of verified income</td></tr>
      <tr><td>Interest</td><td>A simple annual rate of no more than 36%</td></tr>
      <tr><td>Monthly fee</td><td>A maintenance fee of the lesser of 8% of the original loan or $25, with no interest charged on it</td></tr>
      <tr><td>Total charges</td><td>No more than 50% of a loan of $1,500 or less, or 60% of a larger loan</td></tr>
      <tr><td>Late payment</td><td>A charge of up to 5% of the payment and never more than $20, only after seven days; a returned payment costs up to $25</td></tr>
      <tr><td>Where to report it</td><td>The Bureau of Financial Institutions, named in the complaint notice every licensee posts in its office and on its website</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example from the state's borrower pamphlet: a $500 loan repaid in five monthly installments carries $45.90 in interest and $125 in maintenance fees, $170.90 in all. These are the state's illustrative figures at the current limits, not quoted offers.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {city}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {city} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history rather than a credit score alone.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call a community action agency serving {city}. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Check the license before anything else.</strong> Ask which state license the lender holds and confirm it with the regulator before you share your bank details.</li>
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Interest runs on the balance, and qualifying for more is not a reason to take more.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the payment schedule in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any small loan.</li>
      </ul>
      <p style="margin-bottom:0">To ask about a lender or file a complaint, contact the Virginia Bureau of Financial Institutions at (800) 552-7945, or the federal CFPB.</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{city} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>1F Cash Advance in Other {STATE} Cities</h2>
    <p style="max-width:760px">The same {STATE} rules apply statewide. See how they play out where you live:</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
"""
    a_s = base.rfind("<section", 0, base.find("Who wrote this")); a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e].replace("Houston County", county)
    assert "Dothan" not in authors and "Alabama" not in authors

    url = f"https://1firstcashadvance.org/{slug(city)}/"
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": url, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": "https://1firstcashadvance.org/loans-by-state/virginia/"}, {"@type": "ListItem", "position": 4, "name": city}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": {"@type": "Person", "name": "Latoria Williams"}, "editor": {"@type": "Person", "name": "Marsha Welch"}, "reviewedBy": {"@type": "Person", "name": "Michael Lefler"}, "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Short-term loan matching in {city}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{city}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    for c in CITIES:
        if only and c["city"] not in only:
            continue
        p = os.path.join(OUT, slug(c["city"]) + "-NEW.html")
        open(p, "w", encoding="utf-8").write(build(c))
        print("wrote", p)


if __name__ == "__main__":
    main()
