#!/usr/bin/env python3
"""
1F page autofixer. Applies every MECHANICAL fix a page needs to move toward the
v2 spec, then prints what still needs human work (rewrites) or user input
(addresses, city Census data). Pairs with validate.py.

    python3 autofix.py path/to/page.html --city "Littleton" --state "Colorado" --st CO

What it fixes automatically (no judgment):
  - topbar "since 2019" -> NMLS line
  - Other Ways H2 "Shortfall" -> "Emergency"
  - Credit-union card heading -> "Credit union Payday Alternative Loans"
  - office heading "Our X Offices" -> "Where to get payload loan X"
  - remove office intro "Prefer to apply..."
  - remove store block ("There Is No 1F...", "Your 1F Cash Advance Store", "Visit Our ... Store")
  - Products: drop any 3rd card (PAL / Auto title / Title)
  - banned absolutes ("most expensive option", "the cheapest", "will beat ... every time")
  - Tier-1 "navigate" in author bio -> "help"
  - recompute zebra

What it CANNOT fix (prints a TODO list instead):
  - rewriting Can You Get / statistics / FAQ / Borrow Carefully / Law to the hard caps
  - inserting a missing How 1F Works block
  - office cards (needs addresses)
  - 6 JSON-LD (needs the page's final FAQ; rebuild with the skill's schema builder)
  - city-level Census figures

After running autofix, do the TODOs by hand to the spec, then run validate.py until PASS.
"""
import re, sys

def zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == "hero":
            continue
        want = "section alt" if i % 2 == 1 else "section"
        if cls != want:
            te = h.find(">", pos)
            idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f" {idm.group(0)}" if idm else "") + ">" + h[te + 1:]
    return h

def autofix(path, city, state, st):
    h = open(path, encoding="utf-8").read()
    fixed = []

    # topbar -> NMLS
    h2 = re.sub(r"<span>Serving [^<]*since 2019</span>",
                "<span>Licensed loan connector &middot; NMLS ID 1814281</span>", h)
    if h2 != h:
        h = h2; fixed.append("topbar -> NMLS")

    # Other Ways H2
    if "Cover a Shortfall" in h:
        h = h.replace("Cover a Shortfall", "Cover an Emergency"); fixed.append("Other Ways H2 -> Emergency")

    # CU heading
    h2 = re.sub(r"<h3>Credit union[^<]*</h3>", "<h3>Credit union Payday Alternative Loans</h3>", h)
    if h2 != h:
        h = h2; fixed.append("CU heading -> Payday Alternative Loans")

    # office heading
    for pat in [f"Our {city} Offices", f"Our {city} Office"]:
        if pat in h:
            h = h.replace(pat, f"Where to get payday loan {city}"); fixed.append("office heading -> Where to get payday loan")

    # office intro
    h2 = re.sub(r"<p[^>]*>Prefer to apply in person[^<]*</p>", "", h)
    if h2 != h:
        h = h2; fixed.append("removed office intro")

    # store block
    h2 = re.sub(r"<section[^>]*>(?:(?!</section>).)*?(?:There Is No 1F|1F Cash Advance Store|Visit Our [^<]*Store)(?:(?!</section>).)*?</section>",
                "", h, flags=re.S)
    if h2 != h:
        h = h2; fixed.append("removed store block")

    # Products: drop 3rd card (PAL/title)
    for tag in ["Credit Union PALs", "Auto title loans", "Title loans"]:
        pi = h.find(f"<h3>{tag}</h3>")
        if pi >= 0:
            cs = h.rfind('<div class="prod-card">', 0, pi)
            a = h.find("</a>", pi)
            ce = h.find("</div>", a) + 6 if 0 <= a < h.find("</div>", pi) + 300 else h.find("</div>", pi) + 6
            if cs >= 0:
                h = h[:cs] + h[ce:]; fixed.append(f"removed extra product card '{tag}'")

    # banned absolutes
    for o, n in [("the most expensive option", "a costly option"),
                 ("most expensive option", "a costly option"),
                 ("will beat a payday loan every time", "is usually cheaper than a payday loan"),
                 ("the cheapest small-dollar option available", "often a lower-cost option"),
                 ("the cheapest", "a lower-cost")]:
        if o in h:
            h = h.replace(o, n); fixed.append(f"softened '{o}'")

    # Tier-1 navigate in bio
    if "navigate loans" in h:
        h = h.replace("navigate loans safely", "understand loans safely").replace("navigate loans", "understand loans")
        fixed.append("removed 'navigate' from bio")

    # zebra
    h = zebra(h)
    fixed.append("recomputed zebra")

    open(path, "w", encoding="utf-8").write(h)
    return h, fixed

def todos(h, city):
    todo = []
    if "How 1F Cash Advance Works" not in h:
        todo.append("INSERT How 1F Works block (global, after Qualify).")
    cyg = ""
    i = h.find("Can You Get a Payday Loan")
    if i >= 0:
        cyg = h[h.rfind("<section", 0, i):h.find("</section>", i)]
    fp = re.search(r"</h2>\s*<p[^>]*>(.*?)</p>", cyg, re.S)
    if not fp or len(re.sub(r"<[^>]+>", "", fp.group(1)).split()) > 45 or not re.search(r"</h2>\s*<p>(Yes|No|Not)", cyg):
        todo.append("REWRITE Can You Get: direct Yes/No + base numbers, single paragraph <=45 words.")
    stats = ""
    si = h.find("Borrowing and Debt")
    if si >= 0:
        stats = h[si:h.find("</section>", si)]
    ncards = stats.count("stat-card")
    years = sorted(set(re.findall(r"\b(20\d{2})\b", re.sub(r"<[^>]+>", " ", stats))))
    if ncards != 2 or stats.count("<table") != 0 or stats.count('class="src"') != 0 \
            or stats.count("src-note") != 1 or (city and city not in stats) or len(years) < 2:
        todo.append("REWRITE statistics to v5: exactly 2 numeric cards (median income / gap to state) "
                    "with no per-card source lines, no table (the run told in prose naming the first "
                    "and last years) and one sources-only footnote. See references/page-spec.md 5c.")
    f = h.find("Borrowers Ask")
    if f >= 0:
        ans = [len(re.sub(r"<[^>]+>", "", m.group(1)).split()) for m in re.finditer(r'<div class="a">(.*?)</div>', h[f:h.find("</section>", f)], re.S)]
        if len(ans) != 3 or any(x > 60 for x in ans):
            todo.append(f"REWRITE FAQ: exactly 3 questions, each answer <=60 words (now {ans}).")
    b = h.find("Borrow Carefully")
    if b >= 0 and h[b:h.find("</section>", b)].count("<li>") != 4:
        todo.append("REWRITE Borrow Carefully: exactly 4 universal bullets, no page-specific $ facts.")
    ow = h.find("Other Ways")
    if ow >= 0 and (h[ow:h.find("</section>", ow)].count("alt-card") != 4 or "Bank small-dollar" not in h):
        todo.append("REWRITE Other Ways: 4 cards (PAL / Bank small-dollar / Employer / Utility).")
    law = h[h.find("Law at a Glance"):h.find("</section>", h.find("Law at a Glance"))] if "Law at a Glance" in h else ""
    if law.count("<tr>") - 1 > 8 or len(re.findall(r"§|C\.R\.S\.|R\.S\.\s*\d", re.sub(r"<[^>]+>", " ", law))) > 2:
        todo.append("TRIM Law table to <=8 rows, move statute citations to the state guide link.")
    if h.count('<div class="office-card">') < 1:
        todo.append("ASK USER for office addresses, then insert the office block.")
    if sum(1 for _ in re.findall(r'<script type="application/ld\+json">.*?</script>', h, re.S)) != 6:
        todo.append("REBUILD 6 JSON-LD (Organization, WebPage, BreadcrumbList, FAQPage, Article, Service) after the FAQ is final.")
    return todo

def main():
    args = sys.argv[1:]
    opt = {}
    rest = []
    i = 0
    while i < len(args):
        if args[i] in ("--city", "--state", "--st"):
            opt[args[i][2:]] = args[i + 1]; i += 2
        else:
            rest.append(args[i]); i += 1
    if not rest:
        print("usage: autofix.py page.html --city Name --state State --st ST")
        sys.exit(2)
    path = rest[0]
    city = opt.get("city", "")
    h, fixed = autofix(path, city, opt.get("state", ""), opt.get("st", ""))
    print("=== AUTO-FIXED (mechanical) ===")
    for x in fixed:
        print("  +", x)
    td = todos(h, city)
    print("\n=== STILL NEEDS HUMAN WORK (rewrite to spec / user input) ===")
    if td:
        for x in td:
            print("  -", x)
    else:
        print("  none — run validate.py to confirm PASS")
    print("\nNext: do the TODOs to the spec, then run scripts/validate.py until RESULT: PASS.")

if __name__ == "__main__":
    main()
