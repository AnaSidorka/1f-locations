# REPORT — Irvine, CA · обновление контента 27 октября 2026

Файл: `irvine-ca-loans-NEW.html` (копия в `builds/California Final/`).
До правок: `irvine-ca-loans-NEW.BEFORE.html`. Вывод гейта: `validate-output.txt` → `RESULT: PASS (all 36 rules)`.

## Что запрошено

1. В `Can You Get a Payday Loan in Irvine?` второй абзац не по теме заголовка — проверить и внести правки.
2. Доработать `Borrowing and Debt in Irvine: What the Numbers Show`:
   а) первые 3 карточки не несут информации; б) повторяющиеся источники собрать в одном месте
   со сноской; в) `$114,858` и `$14,728 above` перенести в подраздел таблицы;
   г) убрать все 6 миниблоков.

## Проверка утверждений (пункт 1 и 2а)

- ¶2 Can-You-Get — статистика округа (доход, жилищная нагрузка): под заголовком «Can You Get…»
  действительно не по теме. Его содержание уже полностью живёт в блоке статистики:
  доход выше медианы штата → карточка `$14,728 above`; жилищная нагрузка → сноска
  (`Over two households in five`); действие «считай сумму после платежа за жильё» →
  зафиксированная строка `A loan payment has to fit inside the last column…`. Ничего не потеряно.
- Карточки `Max check` / `Fee capped` / `Triple-digit` / `Free payment plan` дублировали таблицу
  закона ниже (Maximum check $300 · Fee 15% · Rate 460% APR · Payment plan) — подтверждено.

## Что сделано на странице

1. Can-You-Get — один абзац (прямой Yes + базовые числа, 41 слово). ¶2 удалён.
2. Statistics: 6 карточек убраны. Две числовые (`$114,858`, `$14,728 above`) стоят в подразделе
   таблицы — между `tbl-cap` и таблицей, без строк `class="src"`.
3. Источники — одна сноска `Sources:` под таблицей: SAIPE по округу и по штату (две ссылки FRED),
   NY Fed Consumer Credit Panel, DP04 ACS. 54 слова, в пределах 45–55.
4. В таблицу закона добавлена ссылка на статут (`Deferred Deposit Transaction Law` →
   leginfo FIN 23035) — первичный источник правовых цифр остался на странице после снятия карточек.

## Смена формы спеки v3 → v4 (по решению владельца, порядок P0-6)

1. Эталон `assets/GOLD-covington-example.html` переведён на v4 первым: ¶2 Can-You-Get снят,
   6 карточек → 2 числовые у таблицы, источники — сноска. Заодно убрано нарушение P4-8
   в подписи карточки разрыва (`the highest-income parish in our Louisiana pages`).
2. `scripts/validate.py`: правило 12 → `Statistics = exactly 2 stat-cards (median income + gap
   to state)`; правило 16 → `Statistics sources consolidated in one footnote` (0 строк
   `class="src"` + ровно 1 `src-note`). Всего по-прежнему 36 правил.
3. Дымовой тест эталона → `RESULT: PASS (all 36 rules)`; затем прогон страницы → PASS.
4. `scripts/autofix.py` TODO-подсказки переведены на v4; `references/page-spec.md` (§1d, §1e,
   §1f, §5, §5c, §7a) и `references/checklist.md` (строки 11/12/16, ручные проверки) синхронизированы;
   `CLAUDE.md` P2-1/P2-2/P4-6a обновлены, штамп `rules-version: 2026-10-01-fdc5ef0d`.

## Свежесть данных (P0-2a, перепроверено в этой сессии)

- FRED MHICA06059A052NCEN (Orange County): 2020–2024 = 98,786 / 100,210 / 106,047 / 109,768 /
  114,858 — совпадает с таблицей.
- FRED MHICA06000A052NCEN (California): 2024 = 100,130 → разрыв 114,858 − 100,130 = **14,728** ✓.
- FRED DP04ACS006059 (burdened households, Orange County): 2024 = 41.97% → «over two households in five» ✓.
- NY Fed databank: HTTP 200. leginfo FIN 23035: открыт, подтверждает $300 / 31 день / $15.

## Бюджеты и ручные проверки

- Каждая $-цифра и % — ≤2 вхождений (грепом: `$300` 2, `15%` 2, `460%` 2, `$114,858` 2, `$14,728` 1).
- Зебра пересчитана `autofix.py` после правок; штамп `<!-- skill-version: v2 -->` на месте; `{{` — нет.
- Снятие правовых карточек разгрузило тематический бюджет: APR и payment plan звучали 3 раза,
  стало 2 (P2-11).
- Страницы других штатов в `builds/* Final/` собраны по v3 и новым гейтом не пройдут — к этой
  партии вопросов нет, пакетная переработка не входила в задачу.

## Блок «Check the Cost Before You Apply» (вторая правка этой сессии)

Запрошено: сделать блок калькуляторов интереснее (референс — maxcash.com, секция
«Not sure which loan fits? Try our free calculators.»). Структура утверждена владельцем
дословно и поставлена на страницу Irvine:

1. H2 `Check the Cost Before You Apply` (eyebrow `Run the numbers`) → абзац-интро
   `Drag the amount. The fee comes out of the check up front…`.
2. Интерактивный виджет: слайдер суммы ($100–$300, шаг $10, дефолт $200) →
   `cash in hand` / `fee taken out` / `you repay in full` (FEE_RATE = 0.15, комиссия CA).
3. Дисклеймер `Illustration at the current state ceiling, not an offer…` — строка утверждена
   владельцем, не меняется.
4. Четыре карточки: круглая зелёная иконка + H3-ссылка + одна строка, без кнопок в карточках.
   URL `/calculators/payday-loan-calculator/`, `/installment-loan-calculator/`,
   `/cash-advance-calculator/`, `/budget-calculator/` — каждый открыт в этой сессии, HTTP 200 (P0-1).
5. Центрированная ghost-кнопка `See All Calculators` на `/calculators/` в конце секции.

Свойства формы: видимых цифр в блоке нет (значения рисует JS, гейт их не считает — бюджет
P2-10 не расходуется); APR цифрой в блоке не печатается (тема уже 2/2: Can-You-Get ¶1 +
таблица закона). Секция `id="calc-sec"` стоит между Can-You-Get и статистикой, зебра
пересчитана — 15 секций, строгое чередование. Гейт после установки → `RESULT: PASS
(all 36 rules)`, вывод сохранён в `validate-output.txt`.

Форма занесена для будущих страниц: эталон `assets/GOLD-covington-example.html` (та же
структура, луизианские `max=740 step=20 value=300`, `FEE_RATE = 0.1675`; дымовой тест PASS),
CSS — в `assets/page-template.html`, позиция 8a — в `references/page-spec.md` §1.

## Блок статистики — форма v5 (третья правка этой сессии)

Запрошено владельцем: в `Borrowing and Debt in Irvine` оставить только две карточки,
сноску источников сократить до самих источников, а таблицу-пятилетку и пояснения
передать краткой прозой для обычного заёмщика. Сначала собрано отдельно в превью,
после одобрения («отлично внедри в код страницы») внедрено по цепочке P0-6.

Что изменено на странице (и в эталоне):

1. Убраны `tbl-cap`, таблица 2020–2024 и строка `fine`. Секция теперь: две карточки
   (без изменений) → абзац ряда → абзац-пояснение → сноска.
2. Абзац ряда: доход Orange County $98,786 → $114,858 за 2020–2024 (~sixteen percent,
   словами) и долг на душу по штату $73,350 → $86,000 (~seventeen percent, словами).
3. Абзац-пояснение: «высокая медиана — не свободные деньги» → доля перегруженных жильём
   (DP04, ссылка на серию) → остаток ~$6,700/мес с пометкой `our calculation, not a
   published figure` → платёж умещается в остаток → единый потолок CA для всех доходов.
4. Сноска `src-note` держит только источники: SAIPE via FRED (округ + штат, две ссылки)
   и NY Fed Consumer Credit Panel.

Цепочка формы (P0-6): эталон `assets/GOLD-covington-example.html` переведён на v5 →
`scripts/validate.py` (правила 13 и 15 заменены: `Statistics has no table (v5: figures
in prose)` и `Statistics prose names the series years (v5)`, всего по-прежнему 36) →
дымовой тест эталона `RESULT: PASS (all 36 rules)` → `references/page-spec.md` §5c
переписан под v5 (проза ряда вместо таблицы, сноска только с источниками; §1d/§1e/§1g/§5/§7a
синхронизированы) → `references/checklist.md` зеркалит новые правила 13/15 → `CLAUDE.md`
P2-2/P2-3/P4-7/P4-9 обновлены, штамп `rules-version: 2026-10-01-7c120ca8`.

Гейт страницы после внедрения → `RESULT: PASS (all 36 rules)`, вывод сохранён в
`validate-output.txt`. Копия обновлена в `builds/California Final/`.

Бюджет цифр (греп по тексту без тегов): `$114,858` ×2 (карточка + проза), `$98,786`,
`$73,350`, `$86,000`, `$6,700`, `$14,728` — по одному; проценты словами, счётчик `\d+%`
не расходуется.

Заметка: остальные страницы в `builds/* Final/` собраны по формам v3/v4 и новым гейтом
не пройдут — пакетная переработка не входила в задачу.

## Перелинковка и кнопка отзывов — перенесены на основную страницу (четвёртая правка)

Владелец спросил, почему на основной странице нет перелинковки: блоки были утверждены
только как превью (`/tmp/irvine-links-preview.html`) и ждали слова «ставим». Дифф превью
против основной показал ровно четыре ожидаемых отличия и ничего лишнего, превью перенесено
на страницу целиком:

1. Секция `id="links-sec"` последней (после авторов, `section` plain — зебра 16 секций
   строго чередуется): eyebrow `Keep exploring`, H2 `More from 1F Cash Advance`, три
   колонки `.link-col` — Payday Amounts in California ($100/$150/$200/$250/$255 Loan +
   All loan amounts), More Ways to Borrow (6 ссылок + All loan options), From the 1F Cash
   Advance Blog (6 статей + All articles). CSS `.link-cols`/`.link-col` добавлен перед
   `</style>`. Все 18 URL открывались в сессии построения, HTTP 200 (P0-1).
2. H2 отзывов расслинкован: `<h2>Customer Reviews of 1F Cash Advance</h2>`.
3. Центрированная ghost-кнопка `See All Reviews` на `/customer-reviews/` после сетки
   отзывов.

`autofix.py` после переноса: только пересчёт зебры (изменений не потребовалось), TODO —
ноль. Гейт → `RESULT: PASS (all 36 rules)`, вывод в `validate-output.txt`. Копия обновлена
в `builds/California Final/`. Контрольный греп подтвердил наличие всех правок сессии:
NMLS-топбар, H2 офисов Nearby, 2 офисные карточки, блок калькуляторов (слайдер, 4 карточки,
кнопка), статистика v5 (0 таблиц), отзывы с расслинкованным H2 и кнопкой, links-sec с тремя
колонками, блок городов CA, 6 JSON-LD, штамп `skill-version: v2`.

Заодно TODO-проверка статистики в `scripts/autofix.py` переведена с v4 на v5 (2 карточки,
0 таблиц, ≥2 года в тексте секции, одна сноска) — инструмент больше не советует схему,
которую гейт отклонит. Стор скилла синхронизирован.

## Четыре текстовые правки владельца (пятая правка этой сессии)

1. Apply, мелкий шрифт: `Approval is not guaranteed and depends on verification of your
   income and application details.` → `Approval is not guaranteed.`
2. How 1F Works — зачищены смысловые повторы мысли «мы не лендер»: убрано `We do not fund
   loans, approve applications or set rates.` (второй пересказ), `and allowed to operate
   there` (дубль «licensed»), буллет 2 `lenders authorized to operate in California` →
   `many lenders`, закрывающая строка `Because the lender sets the terms, …` → `Before you
   accept, …`. Зафиксированные строки не тронуты: первое предложение (P3-1) и
   `(not 1F Cash Advance)` в буллете 3 (P3-2) — поэтому упоминаний осталось ровно два,
   оба обязательные.
3. Law at a Glance, вводный абзац: убрано предложение-оглавление таблицы `In plain terms:
   how much you can get, what it costs, and what happens if you cannot pay on time.`
   (ссылка на статью How Much Is a Payday Loan остаётся на странице — в колонке блога
   links-sec).
4. Блок городов: убран вводный абзац `The same California rules apply statewide. See how
   they work where you live:` — H2 блока самодостаточен.

Эталон, шаблон и §5b спеки эти строки пока содержат (страница от них отклоняется по решению
владельца); распространить на форму — одно слово владельца, цепочка P0-6 готова.

autofix: без изменений, TODO ноль. Гейт → `RESULT: PASS (all 36 rules)`, вывод в
`validate-output.txt`. Копия обновлена в `builds/California Final/`.

## Правка 2026-10-28 — мобильные отзывы каруселью

- В медиазапросе ≤900px блок `.rev-grid` больше не сжимается в одну колонку: карточки стали горизонтальной свайп-каруселью (flex + overflow-x, scroll-snap-type: x mandatory, карточка 82% ширины, край к краю через отрицательные поля, скроллбар скрыт). Десктоп не тронут.
- Гейт: `RESULT: PASS (all 36 rules)`. Копия синхронизирована в `builds/California Final/`.

## 2026-10-28 — правки Irvine зафиксированы в промптах (форма для всех новых страниц)

Перенесено из финальной версии Irvine в инструкции и эталон:

- `assets/GOLD-covington-example.html`: добавлены блок Reviews (3 карточки + See All Reviews + мобильная snap-карусель) и нижняя перелинковка `links-sec` (3 колонки, последняя секция); зачищен How 1F Works (без третьих перефразировок «не лендер»); короткий дисклеймер `Approval is not guaranteed.`; убраны `In plain terms: …` и вводный абзац блока городов; зебра пересчитана (17 секций). Дым: `RESULT: PASS (all 36 rules)`.
- `references/page-spec.md`: §1 — пункт 13a (Reviews, форма + мобильная карусель) и пункт 16 (links-sec); пункт 14 без вводного абзаца; скелет §5b без `In plain terms`.
- `references/checklist.md`: ручные проверки отзывов, карусели и перелинковки.
- `references/<state>.md` (12 файлов): убрано `In plain terms: …` из вводной блока закона.
- `assets/page-template.html`: CSS отзывов/карусели/перелинковки, зачищенный How 1F Works, короткий дисклеймер, метки позиций REVIEWS и LINKS-SEC.
- `SKILL.md`: лимиты статистики v5 (проза, без таблицы), строки Reviews и links-sec в лимитах и слоях, правило «не лендер ровно дважды», запрет оглашающих абзацев, валидатор помечен «спека v5».
- `CLAUDE.md`: P1-4 — 17 блоков; новые P2-13 (Reviews) и P2-14 (перелинковка); штамп rules-version `2026-10-01-70d7ec51` (проверен скриптом).
- Гейт `scripts/validate.py` не менялся: новые блоки закреплены эталоном + спекой + ручными проверками.
- Стор скила `/cursor/stores/user/skills/1f-page-builder-v2/` синхронизирован с репозиторием.
