# California — verified figures and ready state blocks

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11): payday разрешён
и выдаётся. Продукт — deferred deposit transaction, один платёж.

## Verified legal figures

Источник — **текст закона**, обе секции открыты 16 сентября 2026 на leginfo.legislature.ca.gov:

- §23035: https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=FIN&sectionNum=23035
- §23036: https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=FIN&sectionNum=23036

| Item | Verified value | Cite |
|---|---|---|
| Governing law | California Deferred Deposit Transaction Law, Financial Code §23000 и далее | — |
| Maximum check | **$300** — «The face amount of the check shall not exceed three hundred dollars ($300)» | 23035 |
| Maximum term | **31 день** — «may defer the deposit of a customer's personal check for up to 31 days» | 23035 |
| Fee | **15%** от номинала чека — «A fee for a deferred deposit transaction shall not exceed 15 percent of the face amount of the check» | 23036(a) |
| Extension / payment plan | разрешён, но **никакой платы**: «may not charge any additional fee or charge of any kind in conjunction with the extension or payment plan» | 23036(b) |
| Simultaneous loans | нельзя заключить новый договор, пока действует предыдущий с тем же клиентом | 23036(c) |
| Dishonored check | **$15**, и это **единственная** плата за возврат чека | 23036(e) |
| Cutoff for Apply step 3 | **9:30 am** (полоса CA в P2-12) | CLAUDE.md |

### Расчётные величины — помечать как расчёт

- **Комиссия при максимуме:** 15% от $300 = **$45**.
- **На руки при максимуме:** $300 − $45 = **$255**.
- **APR на 14 дней:** считается от выданной суммы, а не от номинала:
  ($45 / $255) × (365 / 14) = **≈460%**.

### Главная ловушка Калифорнии

**15% берётся от номинала чека, а не от выданной суммы.** Заёмщик оставляет чек на $300,
получает $255 и возвращает $300. Поэтому:

- нельзя писать «you can borrow $300» — на руки выдаётся меньше;
- нельзя считать APR от $300: получится ≈391% вместо верных ≈460%;
- формулировка на странице: «a check of up to $300, with the cash in hand smaller by the fee».

### Внутренний гид Калифорнии актуален — ссылаться можно
Страница https://1firstcashadvance.org/loans-by-state/payday-loans-california/ (открыта
16 сентября 2026) печатает те же величины, что статут: чек $300, на руки $255, комиссия $45,
15% от номинала, APR **460.08%** на 14 дней и 207.78% на 31 день. Расчёт APR сошёлся до сотых.

**URL гида у каждого штата свой — проверяй отдельно.** У Луизианы и Огайо адрес вида
`payday-loans-<штат>` отдавал 404 (рабочие — `/loans-by-state/louisiana/` и `/ohio/`),
а у Калифорнии рабочий именно `payday-loans-california`. Единого шаблона нет.

### NOT verified — do not publish

- Страницы **dfpi.ca.gov отдают 403** на любой автоматический запрос, включая обычный
  браузерный User-Agent. Это блокировка робота, а не отсутствие страницы, но содержимое
  сайта регулятора в этой сессии **не читалось**. Ссылку на DFPI в блоке Borrow Carefully
  оставляю как навигационную; перед публикацией её стоит открыть глазами.
- Любая цифра «средний APR в Калифорнии» из небанковских источников.
- AB 539 (2019) с потолком 36% относится к займам **$2,500–$10,000**, а не к deferred
  deposit. Не смешивать: на payday-странице этот потолок не действует.

## California city parameters

ZIP и региональную привязку подтверждать по каждому городу при сборке (P1-2).
Округ нужен для серий FRED — имя серии подтверждает округ.

| City | County | region label | ZIP | cutoff |
|---|---|---|---|---|
| Bakersfield | Kern County | the southern Central Valley | — | 9:30 am |
| Modesto | Stanislaus County | the northern Central Valley | — | 9:30 am |
| Oakland | Alameda County | the East Bay | — | 9:30 am |
| Riverside | Riverside County | the Inland Empire | — | 9:30 am |
| San Bernardino | San Bernardino County | the Inland Empire | — | 9:30 am |
| San Jose | Santa Clara County | the South Bay | — | 9:30 am |
| Stockton | San Joaquin County | the northern Central Valley | — | 9:30 am |
| Visalia | Tulare County | the southern Central Valley | — | 9:30 am |

Серии FRED: доход округа `MHICA06<FIPS>A052NCEN`, нагрузка `DP04ACS006<FIPS>`,
медиана штата `MHICA06000A052NCEN`.

**Riverside и San Bernardino — соседние города в разных округах**, но оба в Inland Empire.
Regional label у них совпадает; следи, чтобы ¶2 и FAQ не стали близнецами (P4-6).

## Ready state blocks (change only {{City}}/{{County}})

### Loan Products (CA) — exactly 2 cards
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>You leave a personal check and the lender holds it until your next payday, for up to 31 days under California law. The fee is taken out of the check, so the cash you receive is smaller than the amount you repay.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in monthly payments, not all at once. It is unsecured and has a set end date. Different rules and lower rate ceilings apply to these, and for a bigger need they usually cost less.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
```

### California Law at a Glance — 8 rows, one § mark
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>California Law at a Glance</h2>
    <p>These are the payday rules for all of California, including {{City}}. In plain terms: how much you can get, what it costs, and what happens if you cannot pay on time. Full legal detail is in the <a href="https://1firstcashadvance.org/loans-by-state/payday-loans-california/">California state guide</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>California position</th></tr>
      <tr><td>Governing law</td><td>Deferred Deposit Transaction Law, Financial Code §23000 and following, overseen by the DFPI</td></tr>
      <tr><td>Maximum check</td><td>$300, and the cash you receive is smaller because the fee comes out of it</td></tr>
      <tr><td>Fee</td><td>Up to 15% of the face amount of the check</td></tr>
      <tr><td>Term</td><td>No longer than 31 days</td></tr>
      <tr><td>Rate</td><td>About 460% APR on a two-week advance at the top of the limit</td></tr>
      <tr><td>Rollovers</td><td>A new transaction may not begin while an earlier one is still in effect</td></tr>
      <tr><td>Payment plan</td><td>A lender may offer one and may not charge any fee for it</td></tr>
      <tr><td>Returned check</td><td>A single charge of up to $15, and nothing else for the same check</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example: at the top of the limit the fee comes to $45 and the cash in hand is $255, repaid in one payment. These are illustrative figures at the current ceilings, not quoted offers.</p>
  </div>
</section>
```

### Other Ways to Cover an Emergency (CA)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below payday.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call your {{County}} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
```

### Borrow Carefully (CA) — 4 bullets, no $ figure inside
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Write the check for what closes the gap. The fee is a share of the check, so a smaller check costs less and still has to be covered in full on the day.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask what you will receive and what you will repay, and weigh the difference against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the amount inside what remains after fixed bills. If you cannot cover it, ask for the payment plan before the check is presented.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="https://dfpi.ca.gov/">California Department of Financial Protection and Innovation</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```

## Distinct local angles (заполнять по мере сборки)
Угол выбирается из данных округа при сборке, не придумывается заранее.
