# Oklahoma — verified figures and ready state blocks

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11). Payday легален:
«deferred deposit loan» по Deferred Deposit Lending Act, Title 59, Sections 3101–3119.
Заголовок офисов — форма по умолчанию. Can-You-Get открывается словом **Yes**.
Отсечка шага 3 — **11:30 am** (Оклахома целиком в Central Time).

## Источники — открыты 29 октября 2026

Официальный свод Оклахомы (oscn.net / govt.westlaw.com) из среды не открывался, текст
читался по зеркалу Justia с пометкой «2025 Oklahoma Statutes» — построчно, секции ниже.

| Документ | URL |
|---|---|
| Регулятор: Oklahoma Department of Consumer Credit | https://oklahoma.gov/okdocc.html |
| §59-3105, право отмены | https://law.justia.com/codes/oklahoma/title-59/section-59-3105/ |
| §59-3106, запрещённые действия (максимум, срок) | https://law.justia.com/codes/oklahoma/title-59/section-59-3106/ |
| §59-3108, финансовый сбор | https://law.justia.com/codes/oklahoma/title-59/section-59-3108/ |
| §59-3109, продления, база, план платежей | https://law.justia.com/codes/oklahoma/title-59/section-59-3109/ |
| §59-3107, взыскание (без уголовного преследования) | https://law.justia.com/codes/oklahoma/title-59/section-59-3107/ |
| §59-3103, область действия (интернет-займы тоже) | https://law.justia.com/codes/oklahoma/title-59/section-59-3103/ |
| Гайд штата на сайте 1F (301 → рабочий URL, 200) | https://1firstcashadvance.org/loans-by-state/oklahoma-loans/ |

## Verified figures

| Item | Verified value | Cite |
|---|---|---|
| Governing law | Deferred Deposit Lending Act, 59 O.S. §§ 3101–3119 (с 1 сент 2003) | — |
| Регулятор | Oklahoma Department of Consumer Credit; лицензирование DDL через NMLS | okdocc |
| Максимум займа | **$500** за транзакцию, без учёта финансового сбора | 3106.7 |
| Срок | **не менее 12 и не более 45 дней** | 3106.8 |
| Финансовый сбор | **$15 на каждые $100** из первых **$300** · **$10 на каждые $100** свыше $300; считается полностью заработанным в день сделки; раскрытие по Regulation Z | 3108.A |
| Что ещё можно брать | только сбор за вернувшийся инструмент (**≤ $25**) и фактический сбор базы данных | 3108.A/B |
| Продления | **запрещены**; новый заём в течение **13 календарных дней** после предыдущего считается продлением | 3109.A/C |
| Непогашенные займы | заявление-аффидевит + проверка по одобренной базе; если у заявителя **больше одного** непогашенного DDL — заём не выдаётся (максимум два с учётом нового) | 3109.B |
| План платежей | с **третьего подряд** займа: по просьбе до даты платежа — **4 равных взноса** в ближайшие дни зарплаты; сбор **10% от principal, не более $15**; новых займов во время плана и **15 дней** после; успешное завершение сообщается в бюро | 3109.D |
| Отмена | письменно **до 17:00 следующего рабочего дня**, полный возврат сборов (principal возвращается) | 3105 |
| Взыскание | нельзя угрожать уголовным делом за неоплаченный инструмент | 3107 |
| Онлайн | акт действует и при сделке через интернет | 3103.C |

### NOT verified — do not publish
- **APR как цифра из источника** — в статуте её нет; на странице только собственный расчёт
  из проверенного тарифа, подписанный как расчёт (пример: $15 на $100 за 14 дней ≈ 391% APR).
- Секции 3110–3119 (штрафы, лицензионные детали) — не читались.
- Число лицензиатов, средний размер займа, любые рыночные данные — нет источника.
- Займы supervised lenders по U3C (вторая карточка Products) — акт их не покрывает (3103.A),
  параметры не проверялись. Никаких цифр по ним.

## Oklahoma city parameters

| City | County | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Tulsa | Tulsa County | MHIOK40143A052NCEN | DP04ACS040143 | 11:30 am |

Медиана штата: `MHIOK40000A052NCEN`. Долг на душу: NY Fed, лист `total`, строка `OK`.

**Талса выходит за пределы округа Талса** (края в Osage, Rogers, Wagoner); данные — по
Tulsa County, ядру города, с дословной геометкой `in Tulsa County`.

Блок 14 — Tulsa пока единственный город Оклахомы в наборе: форма одиночного города
`1F Cash Advance Across Oklahoma` + ссылка на страницу штата (P2-15, решение владельца
19.09.2026). Заголовок `in Other Oklahoma Cities` не используется, пока в реестре один
город.

## Verified income series (SAIPE via FRED, read 2026-10-29)

Oklahoma state median household income: 2020 $54,512 · 2021 $55,829 · 2022 $59,632 ·
2023 $62,120 · **2024 $66,124**.

| County (city) | 2020 | 2021 | 2022 | 2023 | 2024 | growth | vs state 2024 |
|---|---|---|---|---|---|---|---|
| Tulsa (Tulsa) | 58,863 | 59,232 | 63,442 | 65,619 | **70,089** | +19.1% | +$3,965 |

Округ выше медианы штата во все пять лет, рос каждый год; 2024 — рекорд серии.

Долг на душу по Оклахоме, NY Fed Consumer Credit Panel, Q4 (read 2026-10-29):
2020 $35,130 · 2021 $37,620 · 2022 $39,830 · 2023 $40,990 · **2024 $41,880** (+19.2% за ряд).

Жилищная нагрузка (30%+ дохода на жильё), FRED ACS 5-year, 2024: Tulsa County **29.9%**
(2020 28.3 → 2024 29.9, росла почти каждый год).

## Distinct local angles
- Tulsa / Tulsa County — доход и долг росли почти вровень (оба примерно на пятую часть
  за четыре года); округ держится выше медианы штата каждый год ряда, но жилищная доля
  ползёт вверх и подобралась к трём десятым.

## Ready state blocks (change only {{City}}/{{County}})

**Статистика — v5:** правовые факты — в Can-You-Get ¶1 и таблице закона; стат-карточки
только числовые (доход округа, разрыв со штатом).

### Loan Products (OK) — exactly 2 cards, без цифр внутри
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>Oklahoma calls it a deferred deposit loan: one advance against your next paycheck, repaid in a single payment within about six weeks. The fee is set in tiers by law and earned up front, so the cost of the loan is fixed the day you sign.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan repaid on a schedule instead of in one lump sum, with a fixed end date. If you need more time or a bigger amount, this usually works out cheaper than taking one short-term loan after another.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a></div>
    </div>
  </div>
</section>
```

### Oklahoma Law at a Glance — 8 rows, меток для счётчика гейта нет
Секции названы словами («Title 59, Sections …»), без `§`. Бюджет цифр: `$15` и `$100`
в таблице по два раза — на странице больше нигде; `$500`, `$300`, `15%`, `10%` — второе
разрешённое место каждой цифры только Can-You-Get ¶1.
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>Oklahoma Law at a Glance</h2>
    <p>These are the payday rules for all of Oklahoma, including {{City}}. Full legal detail is in the <a href="https://1firstcashadvance.org/loans-by-state/oklahoma-loans/">Oklahoma state guide</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>Oklahoma position</th></tr>
      <tr><td>Governing law</td><td>Deferred Deposit Lending Act, Title 59, Sections 3101 through 3119 of the Oklahoma Statutes, overseen by the Department of Consumer Credit</td></tr>
      <tr><td>Maximum loan</td><td>$500 per loan, not counting the finance charge</td></tr>
      <tr><td>Term</td><td>At least 12 days and no more than 45 days</td></tr>
      <tr><td>Finance charge</td><td>$15 for every $100 of the first $300 advanced, then $10 for every $100 above that, earned in full when the loan is made</td></tr>
      <tr><td>Renewals</td><td>Not allowed; a new loan within 13 days of the previous one counts as a renewal</td></tr>
      <tr><td>Outstanding loans</td><td>No more than two at a time, checked through an approved database before each loan</td></tr>
      <tr><td>Payment plan</td><td>From the third consecutive loan you may ask for four equal installments on your next pay dates; the plan costs 10% of the principal, capped at $15</td></tr>
      <tr><td>Cancellation</td><td>Rescind in writing by 5 p.m. the next business day and every fee comes back</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">These are the legal limits, not quoted offers. Your own charge and due date come from the lender and appear in the loan agreement. Verify a license with the <a href="https://oklahoma.gov/okdocc.html">Oklahoma Department of Consumer Credit</a>.</p>
  </div>
</section>
```

### Other Ways to Cover an Emergency (OK)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below a payday loan.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call a {{County}} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
```

### Borrow Carefully (OK) — 4 universal bullets, no $ figure
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. The fee is a share of the advance, so a smaller loan costs less.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule. Changed your mind? A written cancellation by the next business day returns every fee. Struggling by the third loan in a row? Ask for the installment plan before the due date.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any deferred deposit loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="https://oklahoma.gov/okdocc.html">Oklahoma Department of Consumer Credit</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```
