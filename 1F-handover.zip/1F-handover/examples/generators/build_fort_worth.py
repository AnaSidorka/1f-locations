#!/usr/bin/env python3
"""Build the Fort Worth, Texas city page (spec v3) into builds/2026-10-05/.

Owner decision 2026-10-05: no office addresses exist, so the offices block is omitted
entirely (no placeholder card). The gate's two office rules are expected to FAIL; the page
is therefore UNVERIFIED and carries no skill-version stamp.

Sources opened 2026-10-05 (see REPORT.md):
  Finance Code ch. 393 / ch. 302 (tcss.legis.texas.gov), OCCC payday disclosure form,
  Fort Worth Ordinance 23991-12-2019 (PDF on fortworthtexas.gov) + city summary page,
  FRED SAIPE series for Tarrant County / Texas / US, FRED DP04ACS048439,
  NY Fed area_report_by_year.xlsx (February 2026 release, sheet `total`, row TX).
"""
import json, os, re

ROOT = "/Users/bamer/Downloads/VS CODE/1F Locations"
OUT = os.path.join(ROOT, "builds/2026-10-05")
BASE = os.path.join(ROOT, "builds/2026-09-17-tx/san-antonio-tx-loans-NEW.html")

CITY, COUNTY, STATE, ST = "Fort Worth", "Tarrant County", "Texas", "TX"
DATE, DATE_ISO, CUTOFF = "October 5, 2026", "2026-10-05", "11:30 am"

# Census SAIPE via FRED, MHITX48439A052NCEN (Tarrant County), pulled 2026-10-05
MHI = {2020: 72064, 2021: 71399, 2022: 76285, 2023: 80083, 2024: 85208}
STATE_MHI_2024 = 79723   # MHITX48000A052NCEN
US_MHI_2024 = 81604      # MHIUS00000A052NCEN
# NY Fed CCP, area_report_by_year.xlsx (Feb 2026), sheet total, row TX, Q4 values
DEBT = {2020: 46840, 2021: 49720, 2022: 54290, 2023: 56560, 2024: 57890}

FI393 = "https://tcss.legis.texas.gov/resources/FI/htm/FI.393.htm"
OCCCFORM = "https://occc.texas.gov/wp-content/uploads/2025/12/cab-disclosure-payday-single-rev2024.pdf"
FWORD = "https://www.fortworthtexas.gov/files/assets/public/development-services/documents/credit-access-business-ordinance-23991.pdf"
FRED_C = "https://fred.stlouisfed.org/series/MHITX48439A052NCEN"
FRED_S = "https://fred.stlouisfed.org/series/MHITX48000A052NCEN"
FRED_US = "https://fred.stlouisfed.org/series/MHIUS00000A052NCEN"
DP04 = "https://fred.stlouisfed.org/series/DP04ACS048439"
NYFED = "https://www.newyorkfed.org/microeconomics/databank.html"

PAGE_URL = "https://1firstcashadvance.org/loans-by-state/payday-loans-texas/fort-worth/"
OTHERS = [("Austin", "austin"), ("Baytown", "baytown"), ("Dallas", "dallas"), ("San Antonio", "san-antonio")]

P1 = ("Yes. A state-licensed credit access business arranges the loan with a separate lender, Texas does not cap "
      "its fee, and the state disclosure form puts the average payday APR at 415%. A Fort Worth location may advance "
      "at most 20% of gross monthly income.")
P2 = ("Fort Worth's ordinance defines a credit access business so that one working mainly online, with no location in "
      "the city that takes applications on site, falls outside it. A loan arranged online may therefore carry none of the "
      "city's limits on size, renewals or installments, so before you accept an online offer, check its renewal terms and "
      "number of payments against those limits yourself.")

FAQ = [
    ("How can I tell a Fort Worth store is registered with the city?",
     "Look for the city's certificate of registration on display. Fort Worth requires one for each physically separate "
     "credit access business and requires it to be shown conspicuously to the public. A certificate covers one location "
     "and expires after a year, or sooner if the business loses its state license."),
    ("What will the state cost form show me before I sign?",
     "The business must give you the state form before it arranges the loan. It lists interest and fees if you pay off in "
     "two weeks or one, two or three months, ranks payday loans against other credit, and reports renewals: of 10 people "
     "taking a new single-payment loan, one renews five or more times or never pays it off."),
    ("Do debt collection rules apply to a credit access business?",
     "Yes. Your contract must state that the business has to follow the Texas debt collection law in Finance Code "
     "Chapter 392 and the federal Fair Debt Collection Practices Act. If you believe a collector broke those rules, you "
     "can file a complaint with the Office of Consumer Credit Commissioner."),
]


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build():
    base = open(BASE, encoding="utf-8").read()
    h1 = f"Payday Loans in {CITY}, {STATE}"   # P3-11 form 1: texas.md says payday is available
    title = f"{h1} | Fort Worth Loan"

    head = base[:base.find("</head>")]
    head = head.replace("<!-- skill-version: v2 -->", "")   # no PASS -> no stamp (P1-8)
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)

    hs = base.find('<div class="topbar">')
    he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he].replace("Payday Loans in San Antonio, Texas", h1)
    hero = hero.replace("Updated: September 17, 2026", f"Updated: {DATE}")
    assert "San Antonio" not in hero and "September 17" not in hero

    a_s = base.rfind("<section", 0, base.find("Who wrote this"))
    a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e]
    old_bio = "Verified the latest payday-law changes, the inflation-adjusted maximum and the Bexar County income series on this page at the time of writing."
    assert old_bio in authors
    # Texas has no inflation-adjusted maximum (texas.md): drop the clause rather than repeat a false claim (P0-4)
    authors = authors.replace(old_bio, f"Verified the latest payday-law changes and the {COUNTY} income series on this page at the time of writing.")
    assert "Bexar" not in authors and "San Antonio" not in authors

    m24 = MHI[2024]
    gap = m24 - STATE_MHI_2024
    assert gap > 0
    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(MHI[y])}</td><td>{money(DEBT[y])}</td><td>{money(round(MHI[y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))
    cap_local = round(m24 / 12 * 0.20)
    cap_us = round(US_MHI_2024 / 12 * 0.20)
    inc_growth = (MHI[2024] / MHI[2020] - 1) * 100
    debt_growth = (DEBT[2024] / DEBT[2020] - 1) * 100
    print(f"income growth {inc_growth:.1f}%  debt growth {debt_growth:.1f}%  cap local {cap_local} cap US {cap_us}  gap {gap}")

    links = " &middot; ".join(
        f'<a href="https://1firstcashadvance.org/loans-by-state/payday-loans-texas/{s}/">{n}</a>' for n, s in OTHERS)
    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in FAQ)

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {CITY} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {CITY}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A small loan against your next paycheck, arranged by a licensed credit access business and funded by a separate lender. You repay it on payday or in a few set payments. The business charges its own fee on top of the interest.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in scheduled payments, not all at once. It is unsecured and has a set end date. If you need a bigger amount or more time, this usually costs less than renewing a payday loan again and again.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {CITY}?</h2>
    <p>{P1}</p>
    <p style="margin-top:14px">{P2}</p>
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {CITY}: What the Numbers Show</h2>
<div class="stat-grid">
<div class="stat-card"><div class="num gold">Income-based cap</div><div class="lbl">Fort Worth locations must hold a payday advance to a share of the borrower's documented gross monthly income</div><div class="src">Source: <a href="{FWORD}">Fort Worth Ordinance 23991-12-2019</a></div></div>
<div class="stat-card"><div class="num navy">No fee cap</div><div class="lbl">Texas lets the business set its fee by agreement, and the state regulator has no power to cap it</div><div class="src">Source: <a href="{FI393}">Texas Finance Code Chapter 393</a></div></div>
<div class="stat-card"><div class="num navy">Triple-digit</div><div class="lbl">The average APR on a Texas payday loan, as published by the state consumer credit regulator</div><div class="src">Source: <a href="{OCCCFORM}">OCCC payday loan disclosure form</a></div></div>
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">Median household income in {COUNTY} in 2024, after a dip in 2021 and three years of gains</div><div class="src">Source: <a href="{FRED_C}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{money(gap)} above</div><div class="lbl">How far {COUNTY} sat above the {STATE} median in 2024</div><div class="src">Source: <a href="{FRED_S}">Census SAIPE for Texas via FRED</a></div></div>
<div class="stat-card"><div class="num navy">No criminal threats</div><div class="lbl">The contract must state no one may threaten or pursue criminal charges over your check absent fraud, forgery or theft</div><div class="src">Source: <a href="{FI393}">Texas Finance Code Chapter 393</a></div></div></div>
<p class="tbl-cap">{COUNTY} median household income and {STATE} household debt, 2020 to 2024</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{STATE} debt per person</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">County income comes from <a href="{FRED_C}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column, from the <a href="{NYFED}">New York Fed Consumer Credit Panel</a>. County income grew about eighteen percent in five years, behind about twenty-four for state debt per person. <a href="{DP04}">More than a third of {COUNTY} households</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. At the {COUNTY} median the city's income test allows about {money(cap_local)} at a Fort Worth location, against {money(cap_us)} at the <a href="{FRED_US}">national median</a>. The last column and both amounts are calculations, not published figures: monthly county income after the standard housing share, and one fifth of monthly median income. They describe a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>These are the payday rules for all of Texas, plus the Fort Worth ordinance that applies to credit access businesses with a location in the city. In plain terms: who makes the loan, what it can cost, and how far it can be renewed. Full statutory text is in <a href="{FI393}">Finance Code Chapter 393</a>, and the city rules are in <a href="{FWORD}">Ordinance 23991-12-2019</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
      <tr><td>Governing law</td><td>Finance Code Chapter 393: a credit access business licensed by the OCCC arranges the loan from a third-party lender</td></tr>
      <tr><td>Lender interest</td><td>Generally limited to 10% a year under §302.001</td></tr>
      <tr><td>Broker fee</td><td>Set by agreement with you, with no state cap</td></tr>
      <tr><td>Rate</td><td>415% average APR on a payday loan, per the state disclosure form</td></tr>
      <tr><td>Loan amount</td><td>No state cap, but Fort Worth limits businesses with a location in the city to 20% of gross monthly income</td></tr>
      <tr><td>Renewals</td><td>State law sets no limit. At a Fort Worth location a single-payment loan can be renewed three times, each paying down at least a quarter of the principal</td></tr>
      <tr><td>Installments</td><td>At a Fort Worth location no more than four, each repaying at least a quarter of the principal</td></tr>
      <tr><td>Cost disclosure</td><td>Before the deal, the business must give you the state form comparing its cost with other credit, under §393.223</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example: the state disclosure form puts average fees and interest on a payday loan at $34.14 per $100 borrowed over one month. It is a statewide average, and your own quote can differ. To check a license or file a complaint, contact the <a href="https://occc.texas.gov/consumers/file-a-complaint/">Office of Consumer Credit Commissioner</a>.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {CITY}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {CITY} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below a payday loan.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call a {COUNTY} community action agency. Ask about energy bill assistance and a payment arrangement. That is assistance, not a loan. Call before a disconnection.</p></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Qualifying for more is not a reason to take more, and every extra dollar raises what you owe back.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you cannot pay on time, talk to the lender before the due date rather than taking another loan.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a credit access business license, use the <a href="https://alecs.occc.texas.gov/Generic/AdvanceSearch">OCCC license search</a> or call the OCCC consumer helpline; you can also contact the federal CFPB.</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{CITY} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>1F Cash Advance in Other {STATE} Cities</h2>
    <p style="max-width:760px">The same {STATE} rules apply statewide. See how they play out where you live:</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
"""

    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in FAQ]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": PAGE_URL, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": "https://1firstcashadvance.org/loans-by-state/payday-loans-texas/"}, {"@type": "ListItem", "position": 4, "name": CITY}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": {"@type": "Person", "name": "Latoria Williams"}, "editor": {"@type": "Person", "name": "Marsha Welch"}, "reviewedBy": {"@type": "Person", "name": "Michael Lefler"}, "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Payday loan matching in {CITY}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{CITY}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    assert not re.search(r"\{[a-z_]+\}", page), "unexpanded {name} left"
    assert "skill-version" not in page
    assert page.count('type="application/ld+json"') == 6
    return page


if __name__ == "__main__":
    p = os.path.join(OUT, "fort-worth-tx-loans-NEW.html")
    open(p, "w", encoding="utf-8").write(build())
    print("wrote", p)
