---
name: own-skills-locations
description: "Где лежат собственные скиллы пользователя, что установлено в ~/.claude/skills и в каком виде после переработки 14 сентября 2026"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 1bf7fff1-354f-4116-93fe-03a8b0e1d889
  modified: 2026-09-14T08:03:28.157Z
---

Собственные скиллы пользователя (20 штук) синхронизированы из аккаунта Claude и лежат в
`~/Library/Application Support/Claude/local-agent-mode-sessions/skills-plugin/147e5c77-206a-405b-9a0e-31d20c79c800/1d19ef07-23af-46c3-97c2-c00eac767a6e/skills/`
— авторитетный каталог. Там же 13 встроенных скиллов Anthropic (docx, pdf, pptx, xlsx,
skill-creator, morning, schedule, canvas-design и др.).

Копии и старые версии разбросаны: `~/Downloads/*.skill` — zip-архивы, часть новее
синхронизированных; `~/Downloads/Claude outputs/` — распакованные 1f-page-*;
`~/.codex/skills/1f-page-builder/` — версия для Codex CLI. `thairealtors-design` существует
только архивом в `~/Downloads`, в аккаунте его нет.

**14 сентября 2026 в `~/.claude/skills/` установлены и переработаны десять:**
ai-text-fingerprint, author-verification-audit, data-report-builder,
financial-editor-investopedia, gist-content-logic, google-update-auditor,
master-content-auditor, office-receptionist, seo-eeat-auditor, seo-full-audit.
`1f-page-builder` и `1f-page-validator` сознательно не переносились — их заменяет v2-связка
проекта 1F Locations.

Что важно знать об их текущем состоянии:

- **Рабочий язык внутри скиллов — английский**, включая переписанные с русского
  author-verification-audit и office-receptionist. Правило «отвечай на языке пользователя,
  по умолчанию русский» прописано в них явно. Русская сводка и changelog —
  `~/.claude/skills/README-ru.md`.
- **Два скилла исполняют скрипты, а не оценивают на глаз:**
  `ai-text-fingerprint/scripts/scan.py` (невидимые символы, гомоглифы, плотность пунктуации,
  лексика, структура) и `seo-full-audit/scripts/probe.py` (HTTP-замер: редиректы, robots,
  sitemap, canonical, JSON-LD, `--psi` для Core Web Vitals).
- **master-content-auditor — флагман.** Четыре его reference-файла написаны с нуля, шесть
  подключены по путям к ai-text-fingerprint и financial-editor-investopedia, а не
  скопированы. Правка общего файла чинит сразу оба скилла; удаление соседнего скилла ломает
  флагман.
- **office-receptionist вызывает специалистов через `Skill(skill="...")`.** Старая механика
  «специалист активируется сам по триггерам» в Claude Code не работает.
- Бэкап до переработки: `~/.claude/skills-backup-2026-09-14/`.

**Почему это важно:** пользователь говорит «мои агенты», имея в виду именно этот набор, а на
диске лежит несколько разошедшихся копий каждого. Версия в аккаунте не всегда самая свежая:
office-receptionist в аккаунте от 13 мая знал 7 специалистов, копия в `~/Downloads` от 16
июля — 8.

**Как применять:** прежде чем править скилл пользователя, сравни даты всех копий, а не бери
первую найденную; и помни, что установленные версии уже разошлись с аккаунтом — синхронизация
обратно затрёт переработку. Связано с [[1f-page-skills-location]].
