# South Carolina — verified figures and ready state blocks

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11): payday (deferred
presentment) разрешён и выдаётся лицензиатами. Заголовок офисов — `Where to get payday loan {{City}}`.
Отсечка шага 3 — **12:30 pm** (полоса OH/NC/SC/RI/VA в P2-12).

## Источники — открыты 16–17 сентября 2026

| Документ | URL | Что даёт |
|---|---|---|
| S.C. Code Title 34 Chapter 39, Deferred Presentment Services (официальный сайт легислатуры) | https://www.scstatehouse.gov/code/t34c039.php | все цифры закона ниже |
| Статус кодекса | https://www.scstatehouse.gov/code/statmast.php | «current through the 2025 Session of the General Assembly» |
| S.379 (2025–2026), отмена главы 39 | https://www.scstatehouse.gov/billsearch.php?billnumbers=379&session=126&summary=B | внесён 25.02.2025, передан в комитет Banking and Insurance, **дальше не двигался** |
| S.488 (2025–2026), predatory loan practices + база | https://www.scstatehouse.gov/billsearch.php?billnumbers=488&session=126&summary=B | внесён 25.03.2025, в комитете, **дальше не двигался** |

**Регулятор — South Carolina State Board of Financial Institutions, Consumer Finance Division.**
Сайт `bofi.sc.gov` (и весь `sc.gov`, включая Department of Consumer Affairs) отдаёт 403 —
в сессии **не открывался**. На страницах регулятор называется **без ссылки**; все ссылки-источники
ведут на текст статута на scstatehouse.gov.

## Verified figures — S.C. Code §34-39

| Item | Verified value | Секция |
|---|---|---|
| Лицензия | обязательна, отдельная на каждую точку | 34-39-130 |
| Максимум | **$550** — всё, что выдано клиенту одновременно, **без учёта комиссии** | 34-39-180(B) |
| Комиссия | не больше **15%** от суммы займа, **один раз** на договор | 34-39-180(E) |
| Срок | до **31 дня** | 34-39-180(A), (C) |
| Раскрытие | комиссия в долларах **и** как APR в письменном договоре | 34-39-180(C) |
| Продление | запрещено; нельзя погасить чек новым чеком у того же лицензиата или аффилированного | 34-39-180(F) |
| Возврат чека | **нет** сбора за возвращённый чек; только гражданское взыскание; заёмщик **не несёт уголовной ответственности** | 34-39-180(G) |
| Один заём | нельзя, если есть непогашенный заём **у любого** лицензиата; нельзя в тот же рабочий день, когда погашен прошлый | 34-39-270(A)(1),(2) |
| 8-й и далее за календарный год | не в тот же и не в следующий рабочий день после погашения предыдущего | 34-39-270(A)(3), (B) |
| База | проверка перед каждым займом; ответ — eligible/ineligible с причиной; заёмщик может запросить подробности у оператора базы | 34-39-270(C),(E) |
| Сбор за проверку | оператор берёт с лицензиата не больше **$1**; лицензиат может переложить на клиента **половину** | 34-39-270(H) |
| Отказ от займа | бесплатно, до закрытия **следующего рабочего дня** | 34-39-270(K) |
| План рассрочки | **один раз в 12 месяцев**; запросить **до** даты погашения и подписать дополнение; не меньше **4** примерно равных платежей в дни получения дохода; без процентов и сборов; досрочно — без штрафа; до погашения нового займа не будет | 34-39-280 |
| Залог и поручитель | требовать **нельзя** | 34-39-200(8) |
| Дата на чеке | нельзя менять или удалять дату; нельзя брать чек без даты или с другой датой | 34-39-200(6),(7) |
| Counter checks | не принимаются; имя заёмщика должно быть напечатано на чеке | 34-39-120(2) |
| Вывеска с ценами | комиссия должна быть вывешена в точке и подана в Board | 34-39-170(B) |
| Другие товары в точке | продажа запрещена, кроме money orders, марок, оплаты коммунальных счетов без доплаты, торговых автоматов, факса, переводов, почтовых ящиков | 34-39-200(9) |
| Нарушения | Board может обязать вернуть незаконные сборы; штраф до **$1,000** за нарушение | 34-39-230 |
| Без лицензии | умышленное — мисдиминор класса B, каждая сделка — отдельное нарушение | 34-39-240 |

### Расчётные величины — помечать как расчёт

- Комиссия на максимуме: 15% × $550 = **$82.50**.
- APR на 14 дней: 15% × 365 / 14 = **≈391%**; на 31 день — ≈177%. Срок меняет APR вдвое:
  писать «about 391% APR over two weeks», не «APR в SC».

### Внутренний гид — ссылку НЕ ставить

https://1firstcashadvance.org/loans-by-state/south-carolina/ (обновлён September 8, 2026) верно даёт
$550, 15%, 391.07% на 14 дней и $82.50, но расходится с законом:
- «Late payments may result in an **NSF fee of up to $10**» — с 2009 года §34-39-180(G) прямо
  **запрещает** сбор за возвращённый чек (формулировку про сервисный сбор до $10 закон удалил);
- «must be repaid within **14 to 31 days**» — минимального срока в §34-39-180 нет;
- «extended repayment plan **for a 12-month period**» — закон даёт план **один раз в 12 месяцев**.

### NOT verified — do not publish

- Всё со страниц регулятора (списки лицензиатов, форма жалобы, телефоны) — сайт недоступен.
- Регламент Board по базе и размер фактического сбора за проверку (ниже $1).
- Правила supervised lenders (installment) по S.C. Code Title 37 — не открывались.

## South Carolina city parameters

| City | County | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Anderson | Anderson County | MHISC45007A052NCEN | DP04ACS045007 | 12:30 pm |
| Florence | Florence County | MHISC45041A052NCEN | DP04ACS045041 | 12:30 pm |
| Greenville | Greenville County | MHISC45045A052NCEN | DP04ACS045045 | 12:30 pm |
| Greenwood | Greenwood County | MHISC45047A052NCEN | DP04ACS045047 | 12:30 pm |
| North Augusta | Aiken County | MHISC45003A052NCEN | DP04ACS045003 | 12:30 pm |

Медиана штата: `MHISC45000A052NCEN`. Долг на душу: NY Fed area report, лист `total`, строка `SC`.

- **North Augusta** лежит в Aiken и Edgefield (Census 2020 place-by-county). Округ ряда подтверждать
  по геокоду офисов; долей населения не утверждать.
- **Омонимы:** Greenville SC (Greenville County) ≠ Greenville NC (Pitt County); Greenwood SC ≠ Greenwood MS.
  Слаги `greenville-sc-loans`, `greenwood-sc-loans`.

## Ready state blocks

Форма блоков — как у Миссисипи (payday, первая форма): Products (Payday + Installment «usually
unsecured»), Other Ways (PAL §8 / Bank small-dollar / Employer / Utility с `{{County}}`),
Borrow Carefully (4 универсальных буллета). Закрывающая строка Borrow Carefully называет
**South Carolina State Board of Financial Institutions, Consumer Finance Division** без ссылки.

### South Carolina Law at a Glance — 8 rows из 8, одна метка `§`
```html
<table class="rate-table">
  <tr><th>Item</th><th>South Carolina position</th></tr>
  <tr><td>Governing law</td><td>Deferred Presentment Services Act, S.C. Code §34-39-110 and following, overseen by the State Board of Financial Institutions</td></tr>
  <tr><td>Maximum advance</td><td>$550 at one time, not counting the fee</td></tr>
  <tr><td>Fee</td><td>Up to 15% of the amount advanced, charged once per agreement</td></tr>
  <tr><td>Term</td><td>Up to 31 days</td></tr>
  <tr><td>One loan at a time</td><td>Checked against a statewide database, and no new loan on the day an old one is repaid</td></tr>
  <tr><td>Renewal</td><td>Not allowed, and a loan cannot be paid off with a new check to the same lender</td></tr>
  <tr><td>Returned check</td><td>No returned-check charge and no criminal liability for you; the lender may still collect through civil court</td></tr>
  <tr><td>Trouble repaying</td><td>One extended payment plan every 12 months, in at least four equal installments at no extra cost</td></tr>
</table>
<p class="fine" style="margin-top:12px">Representative example: an advance at the top of the state limit carries a fee of up to $82.50, which works out to about 391% APR over 14 days. These are illustrative figures at the current limits, not quoted offers.</p>
```
Вводный абзац ссылается на статут: `Full legal text is in <a href="https://www.scstatehouse.gov/code/t34c039.php">S.C. Code Title 34, Chapter 39</a>.`

### Шесть стат-карточек — правовые (1–3, 6) одинаковы по штату
| # | `.num` | Источник |
|---|---|---|
| 1 | `Max advance` | S.C. Code §34-39-180 |
| 2 | `Charged once` | S.C. Code §34-39-180 |
| 3 | `Triple-digit` | S.C. Code §34-39-180 (расчёт из потолка комиссии) |
| 6 | `Next-day cancel` | S.C. Code §34-39-270 |

## Distinct local angles (из таблицы SAIPE)
- Anderson / Anderson — рост каждый год, в $2,732 от медианы штата.
- Florence / Florence — рост каждый год, в $11,187 ниже медианы штата.
- Greenville / Greenville — рост каждый год, выше медианы штата.
- Greenwood / Greenwood — скачок в 2021, спад в 2022.
- North Augusta / Aiken — спад в 2021, скачок в 2022, почти без изменений в 2023.
