# 104 города набора 1F Cash Advance (по штатам)

Статус штатного слоя: **[READY]** = есть references/<state>.md · **[TODO]** = файл штата надо собрать с нуля (верифицировать закон регулятора + 4 штатных блока).
Статус payday: **[payday]** = classic payday разрешён · **[installment/ban]** = payday запрещён, только регулируемый installment или полный запрет.

**URL-формат страниц (сверено с полной выгрузкой сайта 29.10.2026):** городская страница живёт по
`https://1firstcashadvance.org/loans-by-state/<state-slug>/<city-slug>/`; исторический формат
`/{city}-{st}-loans/` весь отдаёт 404. Slug штата — таблица ниже; slug города — нижний регистр,
пробелы в дефисы. Все города наших блоков 14 присутствуют в выгрузке как live-200.

| ST | state-slug | ST | state-slug | ST | state-slug |
|---|---|---|---|---|---|
| AL | `alabama` | GA | `georgia-loans` | MS | `payday-loans-mississippi` |
| AZ | `payday-loans-in-arizona` | IL | `illinois-loans` | NC | `payday-loans-in-north-carolina` |
| CA | `payday-loans-california` | IN | `in` | NM | `nm` |
| CO | `payday-loans-colorado` | IA | `payday-loans-in-iowa` | NV | `payday-loans-nevada` |
| DC | `washington-dc` | KY | `payday-loans-kentucky` | OH | `ohio` |
| DE | `payday-loans-delaware` | LA | `la` | OK | `oklahoma-loans` |
|  |  | MD | `payday-loans-maryland` | OR | `payday-loans-oregon` |
|  |  | MO | `missouri` | RI | `rhode-island` |
|  |  |  |  | SC | `south-carolina` |
|  |  |  |  | TN | `payday-loans-tennessee` |
|  |  |  |  | TX | `payday-loans-texas` |
|  |  |  |  | UT | `payday-loans-in-utah` |
|  |  |  |  | VA | `virginia` |
|  |  |  |  | WA | `payday-loans-washington` |

---

## Alabama (AL) — 8 · [READY] · [payday]
Anniston, Birmingham, Dothan, Eufaula, Foley, Huntsville, Northport, Oneonta

## Arizona (AZ) — 3 · [READY] · [installment/ban] · H1 форма 3
Mesa, Phoenix, Tucson

## California (CA) — 8 · [READY] · [payday]
Bakersfield, Modesto, Oakland, Riverside, San Bernardino, San Jose, Stockton, Visalia

## Colorado (CO) — 5 · [READY] · [installment/ban] · H1 форма 2
Aurora, Colorado Springs, Grand Junction, Littleton, Pueblo

## Delaware (DE) — 1 · [READY] · [payday]
Milford

## District of Columbia (DC) — 1 · [READY] · [installment/ban] · H1 форма 3
Washington

## Georgia (GA) — 8 · [READY] · [installment/ban] · H1 форма 3
Athens, Atlanta, Augusta, Decatur, Hiram, Lagrange, Rome, Warner Robins

## Illinois (IL) — 6 · [READY] · [installment/ban] · H1 форма 2
Belleville, Champaign, Decatur, Peoria, Rockford, Springfield

## Indiana (IN) — 4 · [READY] · [payday]
Evansville, Greenfield, Hammond, Lafayette

## Iowa (IA) — 1 · [READY] · [payday]
Des Moines

## Kentucky (KY) — 1 · [READY] · [payday]
Lexington

## Louisiana (LA) — 10 · [READY] · [payday]
Alexandria, Bossier City, Covington, Houma, Lake Charles, Monroe, Opelousas, Ruston, Shreveport, Slidell

## Mississippi (MS) — 7 · [READY] · [payday]
Columbus, Corinth, Greenwood, Gulfport, Laurel, Meridian, Tupelo

## Missouri (MO) — 2 · [READY] · [payday]
Joplin, Kansas City

## Nevada (NV) — 4 · [READY] · [payday]
Henderson, Las Vegas, North Las Vegas, Reno

## New Mexico (NM) — 4 · [READY] · [installment/ban] · H1 форма 3
Albuquerque, Clovis, Gallup, Las Cruces

## North Carolina (NC) — 6 · [READY] · [installment/ban] · H1 форма 3
Charlotte, Durham, Fayetteville, Greenville, Lumberton, Rocky Mount

## Ohio (OH) — 3 · [READY] · [payday] · H1 форма 2
Akron, Dayton, Toledo

## Oklahoma (OK) — 1 · [READY] · [payday]
Tulsa

## Oregon (OR) — 1 · [READY] · [payday]
Portland

## Rhode Island (RI) — 1 · [READY] · [payday]
Warwick (вместо North Providence — решение владельца 19.09.2026: ни один присланный офис не лежит в North Providence)

## South Carolina (SC) — 5 · [READY] · [payday]
Anderson, Florence, Greenville, Greenwood, North Augusta

## Tennessee (TN) — 5 · [READY] · [payday]
Clarksville, Dyersburg, Murfreesboro, Nashville, Paris

## Texas (TX) — 4 · [READY] · [payday]
Austin, Baytown, Dallas, San Antonio

## Utah (UT) — 1 · [READY] · [payday]
Salt Lake City

## Virginia (VA) — 2 · [READY] · [installment/ban] · H1 форма 2
Lynchburg, Richmond

## Washington (WA) — 2 · [READY] · [payday]
Seattle, Vancouver

---

## Свод
- **Всего:** 99 городов, 25 штатов + DC (26 секций).
- **Сделано:** 104 страницы — CO (5/5), NV (4/4), IN (4/4) в `builds/Final`; LA (10/10) в `builds/Louisiana Final`;
  AL (8/8) в `builds/Alabama Final`; OH (3/3) в `builds/Ohio Final`; CA (8/8) в `builds/California Final`;
  GA (8/8) в `builds/Georgia Final`; MS (7/7) в `builds/Mississippi Final`; NC (6/6) в `builds/North Carolina Final`; IL (6/6) в `builds/Illinois Final`; SC (5/5) в `builds/South Carolina Final`; TN (5/5) в `builds/Tennessee Final`; NM (4/4) в `builds/New Mexico Final`; TX (4/4) в `builds/Texas Final`; AZ (3/3) в `builds/Arizona Final`; VA (2/2) в `builds/Virginia Final`; WA (2/2) в `builds/Washington Final`; DE (1/1) в `builds/Delaware Final`; IA (1/1) в `builds/Iowa Final`; OR (1/1) в `builds/Oregon Final`; MO (2/2) в `builds/Missouri Final`; OK (1/1) в `builds/Oklahoma Final`; DC (1/1) в `builds/District of Columbia Final`; KY (1/1) в `builds/Kentucky Final`; RI (1/1) в `builds/Rhode Island Final`; UT (1/1) в `builds/Utah Final`. Остаток **0**.
  Плюс Irvine CA — пилот формы v5, в реестр не входит.
- **Штатный слой READY (26 юрисдикций, 99 городов):** LA (10), AL (8), CA (8), GA (7), MS (7), NC (6), IL (6), SC (5), TN (5), CO (5), NM (4), TX (4), AZ (3), OH (3), NV (3), IN (3), VA (2), WA (2), DE (1), IA (1), OR (1), MO (1), DC (1), KY (1), RI (1), UT (1).
  Сверено с `references/*.md` на диске: есть `louisiana.md`, `alabama.md`, `california.md`, `georgia.md`, `mississippi.md`, `north-carolina.md`, `illinois.md`, `south-carolina.md`, `tennessee.md`, `new-mexico.md`, `texas.md`, `arizona.md`, `colorado.md`, `ohio.md`, `nevada.md`, `indiana.md`, `virginia.md`, `washington.md`, `delaware.md`, `iowa.md`, `oregon.md`, `missouri.md`, `district-of-columbia.md`, `kentucky.md`, `rhode-island.md`, `utah.md`.
- **Штатный слой TODO:** нет. KY, RI и UT собраны по архивным копиям официальных текстов (исключение владельца от 21 сентября 2026); **страницу Utah сверить заново**, когда откроется le.utah.gov.
- **Ближайший остаток в готовых штатах:** нет — все шестнадцать подготовленных штатов собраны полностью.
- **Города со статусом [ban/installment]:** AZ, CO, DC, GA, IL, NM, NC, VA (payday запрещён/только installment — Can You Get открывается "No"/"Not the old kind").
- **Метка payday ≠ форма H1.** Форму берёшь только из `references/<state>.md` (P3-11), не из метки в этом файле.
  Известные случаи: CO и IL — форма 2 `Short-term loans` (не запрет, а потолок 36% и уход лицензиатов); OH — форма 2, хотя штат помечен [payday].

## Города-омонимы (следить, чтобы не смешать)
- Decatur — есть в GA и IL (разные города).
- Greenville — есть в NC и SC.
- Greenwood — есть в MS и SC.

## Отложено 19 сентября 2026 — закон недоступен из среды сборки

Адреса по трём штатам уже проверены геокодером Census; текст закона и сайты регуляторов не открываются
(TCP-таймаут у `apps.legislature.ky.gov`, `webserver.rilegislature.gov`, `le.utah.gov`; 403 у `dbr.ri.gov`
и `dfi.utah.gov`). Выдержки поисковика — не прочитанный источник, публиковать по ним нельзя (P0-1).
При сборке данные SAIPE / NY Fed / DP04 тянуть заново (P0-2a).

- **Kentucky — Lexington, Fayette County.** Все 5 адресов в Lexington-Fayette: 1301 Winchester Rd Ste 77 (40505),
  1328 Versailles Rd (40504), 212 E New Circle Rd (40505), 565 E New Circle Rd #10 (40505), 671 N Broadway (40508).
  Отсечка — 12:30 pm (восточный пояс). Сайт регулятора kfi.ky.gov открывается, но цифр закона не содержит.
- **Rhode Island — Warwick, Kent County.** На страницу: 775 Bald Hill Rd (02886), 400 Warwick Ave Ste. 2 (02888).
  Сняты: 500 Dyer Ave (Cranston), 325 Armistice Blvd (Pawtucket), 1700 Diamond Hill Rd (Woonsocket),
  628 Metacom Ave Unit 14 (02885 Warren, адрес не находится). Отсечка — 12:30 pm (RI уже в полосе).
  Кодекс регламентов rules.sos.ri.gov открывается, но часть 230-40-20-2 — только лицензирование.
- **Utah — Salt Lake City, Salt Lake County.** В черте SLC: 1465 S State St #9 (84115), 1338 S Foothill Dr #195 (84108),
  1645 W 700 N K (84116), 130 W 2100 S Expy (84115). Почтовый SLC, другой муниципалитет — оставить с пометкой:
  2120 S State St, 2716 S State St, 243 E 3300 S (South Salt Lake); 1296 E 3300 S, 757 E 3300 S, 981 E 3300 S (Millcreek);
  3514 W 3500 S, 4083 S Redwood Rd (West Valley City). Снять: 7045 State St (84047 Midvale),
  10486 S Redwood Rd (South Jordan, 84095). Отсечка — 10:30 am (горный пояс). Проверить судьбу SB 329 (2025,
  «Deferred Deposit Lending Modifications») до публикации.

## Maryland — добавлен 1 октября 2026 (вне исходных 99)

Baltimore (Baltimore City). Слой штата — `references/maryland.md`, сборка — `builds/2026-10-01-md/`,
витрина — `builds/Maryland Final/`. Набор стал 100 страниц.
