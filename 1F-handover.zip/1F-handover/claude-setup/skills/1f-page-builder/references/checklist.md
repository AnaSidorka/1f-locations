# Pre-publish checklist — run on every 1F page

Run this scan before presenting. Fix everything that fails.

## Structure
- [ ] Block order matches page-spec §1 (Hero → Apply → Products → Qualify → How 1F Works → Office → Can You Get → Statistics → Law → Other Ways → Borrow Carefully → FAQ → City links → Authors).
- [ ] Office block is right after How 1F Works and before Can You Get.
- [ ] Authors block present at the end, with the correct {Parish} in Michael Lefler's line.
- [ ] Section zebra correct: hero, then alternating section / section alt.
- [ ] Balanced HTML tags (section, div, p, h1–h3, ul, li, table, tr, td, details, summary).

## Locked wording (page-spec §8)
- [ ] Hero is the locked version, unchanged.
- [ ] How 1F Works bullet 3 contains "(not 1F Cash Advance)".
- [ ] Other Ways H2 = "Other Ways to Cover an Emergency in {City}".
- [ ] Credit-union card heading = "Credit union Payday Alternative Loans".
- [ ] First sentence of How 1F Works = "1F Cash Advance is a loan connector and financial marketplace, not a direct lender."

## Figures (state reference)
- [ ] Louisiana: $740 present, $720 absent; small loan $370 (if shown), not $360; representative fee $124, not $117/$121.
- [ ] Legal figures re-verified against the regulator if it's a new inflation period or a new state.
- [ ] No invented numbers, addresses, or lender names.

## Numbers & themes
- [ ] Every dollar figure ≤2 occurrences.
- [ ] Every percentage ≤2 occurrences.
- [ ] Every theme explained ≤2 times.
- [ ] No water paragraph after the statistics block.
- [ ] No water paragraph after the Law table / representative example.
- [ ] No accidental duplicated phrase (e.g. "the same statewide, the same statewide") — re-read edited FAQ answers.

## Tone
- [ ] No banned alarming phrases (lands hardest / bites hardest / makes the due date risky / blunt No./Rarely. / honest reading / awkward moment).
- [ ] Advice framed helpfully.

## ZIP & offices
- [ ] ZIP removed from the Apply H2 ("How to Apply from {City}, {ST}" — no ZIP).
- [ ] ZIP appears only inside office addresses.
- [ ] Office addresses match what the user supplied; house-number-in-ZIP errors fixed and flagged; hours are "Open today 8:00 AM – {close}".

## Uniqueness (per-city)
- [ ] Can-You-Get first paragraph worded differently from sibling cities.
- [ ] FAQ questions distinct from sibling cities.
- [ ] Local angle distinct from sibling cities (see louisiana.md angle list).
- [ ] Statistics from verified sources, city/county/state.

## Schema
- [ ] 6 JSON-LD blocks, all valid JSON.
- [ ] FAQ page copy and FAQPage schema in exact sync (same questions, same answers).

## Quick scan commands (adapt paths)
```python
import re, json
from collections import Counter
h=open('FILE.html',encoding='utf-8').read()
body=re.sub(r'<style.*?</style>','',h,flags=re.S)
txt=re.sub(r'<[^>]+>',' ',body)
print('money>2:',[x for x in Counter(re.findall(r'\$[\d,]+',txt)).most_common() if x[1]>2] or 'OK')
print('pct>2:',[x for x in Counter(re.findall(r'\d+(?:\.\d+)?%',txt)).most_common() if x[1]>2] or 'OK')
print('$720 present:', '$720' in h, '| $740 present:', '$740' in h)
print('not1F:', '(not 1F Cash Advance)' in h, '| PAL:', 'Credit union Payday Alternative Loans' in h, '| Emergency:', 'Cover an Emergency' in h)
print('dup phrase:', bool(re.search(r'(\bthe same statewide\b|\bset statewide\b),\s+\1', h)))
print('ZIP in Apply H2:', bool(re.search(r'How to Apply from [^<]+ \d{5}', h)))
print('JSON-LD:', sum(1 for b in re.findall(r'<script type="application/ld\+json">(.*?)</script>',h,re.S) if (json.loads(b) or True)))
print('tags:',[t for t in ['section','div','p','h1','h2','h3','ul','li','table','tr','td','details','summary'] if len(re.findall(r'<'+t+r'[ >]',h))!=h.count('</'+t+'>')] or 'balanced')
```
