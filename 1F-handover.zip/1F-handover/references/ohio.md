# Ohio — verified figures and ready state blocks

Ohio is **not** a classic single-payment payday state. Since House Bill 123 (the Fairness in
Lending Act, effective **October 29, 2018**) the product is a **short-term loan** under the
Short-Term Loan Law, ORC **1321.35 – 1321.48**. Two-week single-payment payday loans no
longer exist here. Write every block to that product, not to the LA payday shape.

**H1-режим: вторая форма** — `Short-term loans in {{City}}, {{State}}` (P3-11): payday заменён
short-term продуктом по HB 123.

## Verified legal figures

Source: Ohio Revised Code 1321.36 / 1321.39 / 1321.40 / 1321.401 / 1321.41, statutory text
read 2026-09-10. Regulator: **Ohio Division of Financial Institutions**, Ohio Department of
Commerce — https://com.ohio.gov/divisions-and-programs/financial-institutions/financial-institutions

| Item | Verified value | Cite |
|---|---|---|
| Governing law | Short-Term Loan Law, ORC 1321.35–1321.48 (House Bill 123) | — |
| Licence | Required from the superintendent of financial institutions; unlicensed loans are voidable | 1321.36 |
| Maximum loan | **$1,000** | 1321.39(A) |
| Aggregate limit | No new loan that puts the borrower over **$2,500** total outstanding principal across **all** licensees | 1321.41 |
| Minimum term | **91 days** — may be shorter only if the total monthly payment is no more than 6% of verified gross monthly income or 7% of verified net, whichever is greater | 1321.39(B) |
| Maximum term | **one year** | 1321.39(B) |
| Structure | Precomputed, payable in substantially equal installments of principal, fees and interest | 1321.39(D) |
| Interest | **Not exceeding 28% per annum** | 1321.40(A) |
| Monthly maintenance fee | Lesser of **10%** of the originally contracted loan amount or **$30** (exception for active-duty military and dependents) | 1321.40(B) |
| Loan origination charge | **2%** of the originally contracted loan amount, only if that amount is **$500 or more** | 1321.40(C) |
| Check collection charge | One per loan, **$20** plus amounts passed on from other financial institutions | 1321.40(D) |
| Check cashing fee | **$10** where proceeds are paid by check | 1321.40(E) |
| Rollovers | No new loan while one is outstanding with the same licensee, except a refinance under 1321.401 | 1321.41 |
| Refinancing | Allowed only if the refinance is itself a short-term loan, interest stays at or under 28% per annum, and **no monthly maintenance fee** is charged | 1321.401 |
| Prepayment | No prepayment penalty | 1321.41 |
| Collateral | Vehicle title, real property and physical assets may not be taken | 1321.41 |
| Cancellation | Borrower may rescind by returning the loan amount **by 5 p.m. of the third business day** after the transaction | 1321.39(E) |
| Cutoff for Apply step 3 | **12:30 pm** (OH band in the spec) | — |

### Внутренний гид противоречит этому файлу — не ссылаться как на источник цифр
Страница https://1firstcashadvance.org/loans-by-state/ohio/ (открыта 16 сентября 2026) печатает
**оба** запрещённых ниже утверждения: «State law caps the maximum interest rate on short-term
loans at 28% APR» и «The law caps all fees and charges at 60% of the originally contracted loan
amount». Первое — ловушка из раздела ниже, второе не подтверждено в тексте ORC. Ссылка в блоке
закона ведёт туда как на общий гид; **источником цифры карточки этот URL быть не может**.
Прежний адрес `payday-loans-ohio` отдавал 404 и исправлен 16 сентября 2026.

### NOT verified — do not publish
- **"Total interest and fees capped at 60% of principal."** Pew, the Ohio House and several
  statutory summaries state it, but it was not located in the ORC text on 2026-09-10.
  Dropped from the Dayton page by the user's decision. Re-open only with a regulator cite.
- **"Average pre-reform Ohio payday APR ≈ 591%."** A Pew figure, not a regulator figure.
- Any worked dollar example ("$140 in interest", "$190 a month"). Ohio loans are precomputed
  installments; a representative example needs a fixed principal, term and fee set. The
  Dayton page carries **no** representative example by the user's decision.

### The trap to avoid
**28% is the interest cap, not an all-in APR ceiling.** The monthly maintenance fee and the
origination charge sit **on top** of interest, so the disclosed APR is higher than 28%.
Never write "all-in ceiling of 28% APR", "maximum APR 28%", or "the fees must live inside
the ceiling". Say "interest is capped at 28% a year, with a monthly maintenance fee and an
origination charge on top".

## Ohio city parameters

| City | County | region label | ZIP | cutoff |
|---|---|---|---|---|
| Akron | Summit County | northeast Ohio | 44310 | 12:30 pm |
| Dayton | Montgomery County | the Miami Valley | 45402 | 12:30 pm |
| Toledo | Lucas County | northwest Ohio | 43613 | 12:30 pm |

## Ready state blocks (change only {{City}}/{{Parish}})

### Loan Products (OH) — exactly 2 cards
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Short-Term Loans</h3>
        <p>Ohio's regulated replacement for the old payday loan. It is repaid in equal installments over at least ninety-one days rather than in one payment on your next check, and rollovers are not allowed. Ask for the annual percentage rate and the full payment schedule before you sign.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a>
      </div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>For a bigger need, an installment loan spreads repayment over a longer schedule with fixed payments. Ask for the annual percentage rate and the total cost of credit in dollars, and compare that figure across offers. For a larger repair bill, this is usually the better fit than a short-term loan.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a>
      </div>
    </div>
  </div>
</section>
```

### Ohio Law at a Glance — 7 rows, no water paragraph after the table
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>Ohio Law at a Glance</h2>
    <p>These are the short-term loan rules for all of Ohio, including {{City}}. Full legal detail is in the <a href="https://1firstcashadvance.org/loans-by-state/ohio/">Ohio state guide</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>Ohio position</th></tr>
      <tr><td>Governing law</td><td>Short-Term Loan Law, ORC 1321.35 to 1321.48 (House Bill 123), overseen by the Ohio Division of Financial Institutions</td></tr>
      <tr><td>Maximum loan</td><td>$1,000, and no more than $2,500 outstanding at one time across all licensed lenders</td></tr>
      <tr><td>Term</td><td>At least 91 days and no more than one year, repaid in equal installments</td></tr>
      <tr><td>Interest</td><td>Up to 28% a year</td></tr>
      <tr><td>Other charges</td><td>A monthly maintenance fee of the lesser of 10% of the amount borrowed or $30, plus a 2% origination charge on loans of $500 or more</td></tr>
      <tr><td>Rollovers</td><td>Not allowed: a lender may not make a new loan while one with the same lender is outstanding</td></tr>
      <tr><td>Cancellation</td><td>You may cancel by returning the money by 5 p.m. of the third business day after signing</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">These are the legal ceilings, not quoted offers. Your own rate, fee and payment schedule come from the lender and appear in the loan contract.</p>
  </div>
</section>
```

### Other Ways to Cover an Emergency (OH)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a low rate cap. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is usually below a short-term loan.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call a {{Parish}} community action agency. Ask about HEAP energy assistance and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
```
Note: the §8 locked CU body ends "a rate cap around 28% APR". In Ohio that would be a third
occurrence of 28% on the page, which P2-10 forbids. The cap wins (P2 > P3); the heading stays
locked verbatim and only the rate phrase is generalised.

### Borrow Carefully (OH) — 4 universal bullets, no $ figure, no state fact
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. The cost rises with the amount, and qualifying for more is not a reason to take more.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the payment schedule in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment dates.</strong> Line the payments up with your pay schedule and keep each one inside what remains after fixed bills. If money gets tight, call the lender before a payment is missed.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any short-term loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="https://com.ohio.gov/divisions-and-programs/financial-institutions/financial-institutions">Ohio Division of Financial Institutions</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```

## Distinct local angles used (keep new cities distinct from these)
- Dayton — city median household income sits far below both the county and the state median.
