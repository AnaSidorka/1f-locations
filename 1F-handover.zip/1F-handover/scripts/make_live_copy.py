#!/usr/bin/env python3
"""Делает локальный дубль живой страницы сайта, подменив авторов на новых.

Страница скачивается целиком (как отдаёт сайт), меняются только блоки авторов:
байлайн в hero, карточки внизу и JSON-LD. Фотографии прежних авторов удаляются —
у новых авторов фото на сайте нет, а чужие оставлять нельзя.

usage: python3 scripts/make_live_copy.py <url> <out.html>
"""
import json, re, sys, urllib.request

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
      "(KHTML, like Gecko) Version/17.0 Safari/605.1.15")

# старый автор -> (новое имя, ссылка на профиль, должность, био, теги-креды)
PEOPLE = {
    "Latoria Williams": (
        "Tara Wellema",
        "https://www.linkedin.com/in/taralachapellewellema/",
        "Financial writer and editor",
        "Tara Wellema is a longtime Bloomberg financial journalist and columnist. She now writes and edits "
        "thought-leadership and investor-communications material for a financial-services firm.",
        ["Northwestern University", "Former Bloomberg columnist", "Harding Loevner LP"],
    ),
    "Marsha Welch": (
        "Rebecca McClay",
        "https://www.linkedin.com/in/rebeccamcclay/",
        "Financial editor",
        "Rebecca McClay provides stocks and market-related finance coverage for numerous publications, and has "
        "worked as a freelance business writer, editor and media consultant since 2012.",
        ["University of Maryland, College Park"],
    ),
    "Michael Lefler": (
        "Colin Scott",
        "https://www.linkedin.com/in/paydayloansdallas/",
        "Financial adviser",
        "Colin Scott is a financial adviser at Payday Loans Dallas with a graduate-level background in finance.",
        ["University of Dallas", "Payday Loans Dallas"],
    ),
}

OLD_PAGES = {
    "https://1firstcashadvance.org/latoria-williams/": PEOPLE["Latoria Williams"][1],
    "https://1firstcashadvance.org/marsha-welch/": PEOPLE["Marsha Welch"][1],
    "https://1firstcashadvance.org/michael-lefler/": PEOPLE["Michael Lefler"][1],
}

OLD_SOCIALS = {
    "https://www.linkedin.com/in/latoria-williams": PEOPLE["Latoria Williams"][1],
    "https://www.linkedin.com/in/marsha-welch": PEOPLE["Marsha Welch"][1],
    "https://www.linkedin.com/in/michael-lefler": PEOPLE["Michael Lefler"][1],
    "https://www.facebook.com/latoria.williams.522": PEOPLE["Latoria Williams"][1],
    "https://x.com/WiliamsLatoria": PEOPLE["Latoria Williams"][1],
    "https://www.facebook.com/people/Marsha-Welch/100088909682775/": PEOPLE["Marsha Welch"][1],
    "https://x.com/LeflerMich": PEOPLE["Michael Lefler"][1],
}

ROLES = {"CEO": PEOPLE["Latoria Williams"][2]}


QUOTES = [
    # (куда вставлять — якорь в HTML, текст, ник, дата)
    (r'Dallas County income dipped in 2021.*?</p>',
     "I got caught in the payday loan doom loop&hellip; By the end, my entire paycheck was going to the loan as soon as it was deposited.",
     "CaseyAnthonysMouth", "August 2025"),
    (r'Borrow Carefully.*?</ul>',
     "I had the same problem. Finally had to pay it all off after it showed up on my credit report for almost 3x the original amount.",
     "Sanmartian41", "August 2025"),
    (r'Utility and assistance programs.*?</div>\s*</div>',
     "My credit union is the best bank I&rsquo;ve worked with, highly recommend looking into your options.",
     "wantondavis", "February 2024"),
]

QUOTE_CSS = ('<style>.rquote{position:relative;background:#f7f8fa;border-left:3px solid #4468b2;'
             'border-radius:0 8px 8px 0;padding:18px 24px 14px 30px;margin:22px 0}'
             '.rquote p{font-style:italic;margin:0 0 10px}'
             '.rquote footer{font-style:normal;font-size:14px;color:#6f685d}</style>')


def add_quotes(t):
    """Вставляет цитаты Reddit и кладёт их в JSON-LD как citation."""
    if "rquote" in t:
        return t
    for anchor, text, user, date in QUOTES:
        m = re.search(anchor, t, re.S)
        if not m:
            continue
        block = ('<blockquote class="rquote"><p>&ldquo;' + text + '&rdquo;</p>'
                 '<footer>said the Reddit user <a href="https://www.reddit.com/user/' + user + '/" '
                 'rel="nofollow noopener noreferrer" target="_blank">' + user + '</a>, ' + date + '</footer></blockquote>')
        t = t[:m.end()] + block + t[m.end():]
    cites = [{"@type": "Quotation",
              "text": re.sub(r"&[a-z]+;", lambda x: {"&hellip;": "...", "&rsquo;": "'"}.get(x.group(0), x.group(0)), text),
              "creator": {"@type": "Person", "name": user, "url": f"https://www.reddit.com/user/{user}/"},
              "datePublished": {"August 2025": "2025-08", "February 2024": "2024-02"}.get(date, date)}
             for _, text, user, date in QUOTES]
    for s in re.findall(r"(?s)<script[^>]*type=['\"]application/ld\+json['\"][^>]*>(.*?)</script>", t):
        try:
            d = json.loads(s)
        except Exception:
            continue
        if isinstance(d, dict) and d.get("@type") in ("WebPage", "Article") and "citation" not in d:
            d["citation"] = cites
            t = t.replace(s, json.dumps(d, ensure_ascii=False, indent=1), 1)
            break
    return t.replace("</head>", QUOTE_CSS + "</head>", 1)


def offline_fix(t):
    """Чтобы копия выглядела как живая при открытии с диска."""
    t = re.sub(r'src="data:image/svg\+xml[^"]*"\s+', "", t)          # заглушки lazy-load
    t = t.replace("data-lazy-srcset=", "srcset=").replace("data-lazy-src=", "src=")
    t = t.replace("data-lazy-bg=", "style-bg=")
    t = t.replace(".rll-youtube-player, [data-lazy-src]{display:none !important;}", "")
    t = re.sub(r'(href|src)="(/(?!/)[^"]*)"', lambda m: f'{m.group(1)}="https://1firstcashadvance.org{m.group(2)}"', t)
    return t


def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    return urllib.request.urlopen(req, timeout=60).read().decode("utf-8", "ignore")


def swap(t):
    # 1. фотографии прежних авторов — вырезаем контейнер целиком
    for old in PEOPLE:
        t = re.sub(r'<div class="ab-ph"[^>]*>\s*<img[^>]*alt="' + re.escape(old) + r'".*?</div>', "", t, flags=re.S)
    # 2. ссылки на страницы авторов сайта -> профили LinkedIn
    for old, new in OLD_PAGES.items():
        t = t.replace(old, new)
    # 3. соцсети прежних авторов -> профиль нового
    for old, new in OLD_SOCIALS.items():
        t = t.replace(old, new)
    # 4. должности
    t = t.replace('<span class="ab-author-role">CEO</span>',
                  f'<span class="ab-author-role">{PEOPLE["Latoria Williams"][2]}</span>')
    roles = [PEOPLE["Marsha Welch"][2], PEOPLE["Michael Lefler"][2]]
    for role in roles:
        t = t.replace('<span class="ab-mini-role">Financial Author</span>',
                      f'<span class="ab-mini-role">{role}</span>', 1)
    # 5. био и теги-креды у основного автора
    bio_tail = PEOPLE["Latoria Williams"][3].split(" ", 2)[2]  # без имени, с глаголом
    t = re.sub(r'<div class="ab-bio">.*?</div>',
               f'<div class="ab-bio"><a href="{PEOPLE["Latoria Williams"][1]}">{PEOPLE["Latoria Williams"][0]}</a>'
               f' {bio_tail}</div>', t, count=1, flags=re.S)
    tags = "".join(f'<span class="ab-tag">{c}</span>' for c in PEOPLE["Latoria Williams"][4])
    t = re.sub(r'<div class="ab-tags">.*?</div>', f'<div class="ab-tags">{tags}</div>', t, count=1, flags=re.S)
    # 6. jobTitle в JSON-LD
    t = t.replace('"jobTitle": "CEO"', f'"jobTitle": "{PEOPLE["Latoria Williams"][2]}"')
    for old, role in (("Marsha Welch", PEOPLE["Marsha Welch"][2]), ("Michael Lefler", PEOPLE["Michael Lefler"][2])):
        t = t.replace('"jobTitle": "Financial Author"', f'"jobTitle": "{role}"', 1)
    # 7. картинки авторов в JSON-LD убираем вместе с ключом
    t = re.sub(r'"image":\s*"https://1firstcashadvance\.org/wp-content/uploads/\d+/\d+/'
               r'(?:Latoria-Williams|Marsha-Welch|Michael-Lefler)[^"]*",?\s*', "", t)
    # 7b. в sameAs мог оказаться один и тот же профиль несколько раз
    def dedup(m):
        urls = re.findall(r'"([^"]+)"', m.group(1))
        seen = list(dict.fromkeys(urls))
        return '"sameAs": [' + ", ".join(f'"{u}"' for u in seen) + ']'
    t = re.sub(r'"sameAs":\s*\[([^\]]*)\]', dedup, t)
    # 8. сами имена
    for old, new in PEOPLE.items():
        t = t.replace(old, new[0])
    return t




def swap_schema_only(t):
    """Эксперимент: на странице остаются авторы сайта, в JSON-LD подставляются новые."""
    def fix(block):
        try:
            d = json.loads(block)
        except Exception:
            return block
        changed = False

        def walk(o):
            nonlocal changed
            if isinstance(o, dict):
                if o.get("@type") == "Person" and o.get("name") in PEOPLE:
                    new = PEOPLE[o["name"]]
                    o["name"] = new[0]
                    o["url"] = new[1]
                    o["jobTitle"] = new[2]
                    o["sameAs"] = [new[1]]
                    o.pop("image", None)
                    changed = True
                for v in o.values():
                    walk(v)
            elif isinstance(o, list):
                for v in o:
                    walk(v)

        walk(d)
        return json.dumps(d, ensure_ascii=False, indent=1) if changed else block

    for s in re.findall(r"(?s)<script[^>]*type=['\"]application/ld\+json['\"][^>]*>(.*?)</script>", t):
        fixed = fix(s)
        if fixed != s:
            t = t.replace(s, fixed, 1)
    return t




# ВНИМАНИЕ: тексты ниже — заглушки для эксперимента, реальные авторы их не писали.
EXPERT_QUOTES = [
    (r'Texas Law at a Glance.*?</table>',
     "The number that matters is the dollar cost of the loan, not the rate on the sign. Ask what you hand back in total, and on which date.",
     "Tara Wellema", "Financial writer and editor", "https://www.linkedin.com/in/taralachapellewellema/"),
    (r'Dallas Borrowers Ask',
     "Before you sign anything, price the same amount at a credit union and at your own bank. Five minutes of comparison changes what this costs you.",
     "Rebecca McClay", "Financial editor", "https://www.linkedin.com/in/rebeccamcclay/"),
]

EXPERT_CSS = ('<style>.equote{background:#fff;border:1px solid #d9e0ea;border-left:4px solid #123a5f;'
              'border-radius:6px;padding:18px 22px;margin:22px 0}'
              '.equote p{font-style:italic;margin:0 0 10px}'
              '.equote footer{font-style:normal;font-size:14px;color:#4b5563}</style>')


def add_expert_quotes(t):
    """Цитаты экспертов в текст + Quotation в JSON-LD. Тексты — заглушки."""
    if "equote" in t:
        return t
    cites = []
    for anchor, text, name, role, url in EXPERT_QUOTES:
        m = re.search(anchor, t, re.S)
        if m:
            block = ('<blockquote class="equote"><p>&ldquo;' + text + '&rdquo;</p>'
                     '<footer>&mdash; <a href="' + url + '" rel="nofollow noopener" target="_blank">' + name +
                     '</a>, ' + role + '</footer></blockquote>')
            if "Borrowers Ask" in anchor:
                h = re.search(r'<h2[^>]*>[^<]*Borrowers Ask', t)
                pos = h.start() if h else m.start()
            else:
                pos = m.end()
            t = t[:pos] + block + t[pos:]
        cites.append({"@type": "Quotation", "text": text,
                      "creator": {"@type": "Person", "name": name, "jobTitle": role, "url": url, "sameAs": [url]}})
    for s in re.findall(r"(?s)<script[^>]*type=['\"]application/ld\+json['\"][^>]*>(.*?)</script>", t):
        try:
            d = json.loads(s)
        except Exception:
            continue
        if isinstance(d, dict) and d.get("@type") in ("WebPage", "Article"):
            d["citation"] = d.get("citation", []) + cites
            t = t.replace(s, json.dumps(d, ensure_ascii=False, indent=1), 1)
            break
    marker = "<!-- ТЕСТОВЫЙ ФАЙЛ: цитаты экспертов — заглушки, реальные авторы их не писали. Не публиковать. -->"
    return t.replace("<head>", "<head>" + marker + EXPERT_CSS, 1)


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    flags = {a for a in sys.argv[1:] if a.startswith("--")}
    url, out = args[0], args[1]
    page = fetch(url)
    what = []
    if "--authors" in flags:
        page = swap(page); what.append("новые авторы на странице и в разметке")
    if "--quotes" in flags:
        page = add_quotes(page); what.append("цитаты Reddit + citation")
    if "--schema-only" in flags:
        page = swap_schema_only(page); what.append("новые авторы только в разметке")
    if "--expert-quotes" in flags:
        page = add_expert_quotes(page); what.append("цитаты экспертов (заглушки)")
    if not what:
        what.append("оригинал без правок")
    page = offline_fix(page)
    open(out, "w", encoding="utf-8").write(page)
    print(f"сохранено: {out} ({len(page):,} символов) — " + "; ".join(what))
