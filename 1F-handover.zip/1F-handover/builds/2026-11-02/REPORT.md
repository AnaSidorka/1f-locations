# REPORT — 2026-11-02 · обновление общего шаблона (карта Google, ближайшие города, отзывы без офиса)

Три решения владельца от 02.11.2026 применены к шаблону на примере Irvine CA и раскатаны на все
шесть собранных страниц. Порядок P0-6: эталон GOLD → правила гейта → дым → страницы → спеки.

## 1. Карта — Google Maps вместо Leaflet

- Выбран вариант, который работает наверняка: **безключевой embed-iframe**
  `https://maps.google.com/maps?q=<адрес офиса>&z=16&output=embed` (301 → 200 на
  `www.google.com/maps/embed`; все 17 URL офисов шести страниц проверены curl — 200).
  Maps Embed API с ключом отклонён: ключ — внешняя зависимость, «наверняка» не даёт.
- Прежние требования к карте сохранены (29.10.2026): порядок карточек == порядок URL в
  массиве `views`; клик/Enter/Space по карточке переключает iframe на её офис; `active` у
  выбранной карточки; по умолчанию первая. Проверено headless-рендером: клик по второй
  карточке Irvine переключил iframe на `9864 Research Dr` и перенёс `active` (title-тест).
  Скриншот: карта отрисована с пином 1F Cash Advance на 2691 Richter Ave.
- Leaflet удалён полностью: link CSS, script src, init-блок, переменные маркеров.

## 2. Строка ближайших городов под картой

Без заголовка, абзац `<p class="office-nearby">The services are available for the residents of …</p>`
сразу под картой. Составы (10–15 пунктов, до ~30 мин езды) проверены геокодером Nominatim —
расстояния по прямой от центра города:

- **Irvine (15):** Tustin 4.2 · Santa Ana 5.2 · Costa Mesa 4.7 · Orange 5.3 · North Tustin 5.7 ·
  Corona del Mar 6.5 · Newport Beach 7.5 · Laguna Woods 7.8 · Lake Forest 8.5 · Villa Park 9.0 ·
  Aliso Viejo 9.5 · Foothill Ranch 9.6 · Laguna Hills 10.1 · Laguna Beach 10.1 · Mission Viejo 11.4 (мили)
- **North Las Vegas (10):** Las Vegas 2.8 · Winchester 4.2 · Sunrise Manor 5.1 · Whitney 7.7 ·
  Nellis AFB 7.8 · Paradise 8.9 · Centennial Hills 9.6 · Spring Valley 11.2 · Summerlin South 13.5 ·
  Enterprise 14.0
- **Kansas City (12):** Kansas City, KS 2.7 · Mission 6.5 · Prairie Village 8.0 · Gladstone 8.4 ·
  Independence 8.9 · Raytown 8.9 · Shawnee 9.0 · Overland Park 10.4 · Liberty 13.3 · Lenexa 14.2 ·
  Grandview 14.7 · Blue Springs 16.9
- **Greenfield (10):** New Palestine 7.7 · Cumberland 10.0 · Fortville 11.0 · McCordsville 11.1 ·
  Lawrence 14.1 · Pendleton 15.1 · Beech Grove 17.5 · Fishers 17.5 · Shelbyville 18.2 ·
  Indianapolis 20.7 (25 мин по I-70)
- **Tulsa (10):** Sand Springs 6.6 · Jenks 9.2 · Owasso 10.9 · Sapulpa 12.3 · Broken Arrow 13.3 ·
  Glenpool 13.8 · Catoosa 14.0 · Bixby 15.9 · Collinsville 17.0 · Verdigris 17.7
- **Hiram (12):** Powder Springs 4.6 · Dallas 5.6 · Austell 8.5 · Douglasville 8.6 ·
  Lithia Springs 9.2 · Mableton 11.0 · Kennesaw 13.2 · Marietta 13.3 · Acworth 14.0 ·
  Smyrna 14.2 · Villa Rica 13.4 · Rockmart 18.3

Отсечённые кандидаты (дальше ~30 мин): Blue Diamond 19.4 (NLV), Lee's Summit 26.4 · Belton 20.1 ·
Raymore 20.9 · Olathe 19.7 (KC), Greenwood 21.6 · Speedway 25.0 (Greenfield), Claremore 23.7 ·
Coweta 23.6 (Tulsa).

## 3. Отзывы без названия офиса

`rev-meta` теперь: имя · давность · ссылка `Google review`. Подпись `for our …, ST office`
убрана на всех страницах и в эталоне; ссылка-источник сохранена. У Tulsa один отзыв со ссылкой
формата `maps.app.goo.gl` — правило гейта принимает оба short-link формата Google.
Требование «отзывы из офиса того же штата» (29.10.2026) остаётся правилом **отбора при сборке** —
на странице локация больше не печатается, гейт её не ищет; флаг `--state` из валидатора удалён.

## Гейт и спеки

- `scripts/validate.py`: правила 41 (rev-meta: ссылка есть, офиса нет), 42 (карта — Google embed,
  Leaflet запрещён), 43 (строка ближайших городов под картой). `--state` удалён. Всего **43 правила**.
- Доказательство на Irvine до правки: 3 FAIL ровно по новым правилам; после — PASS.
- GOLD обновлён первым (rev-meta), дым: `PASS (all 43 rules)`. Все 6 страниц: `PASS (all 43 rules)`.
- `scripts/apply_gmap_nearby.py` — идемпотентный апдейтер (карта + nearby + rev-meta), лежит в репо.
- Доки: page-spec §3 (карта Google + nearby), §1 п.13a (rev-meta без офиса); checklist 41–43;
  CLAUDE.md P2-9 и P2-13 + штамп `2026-10-01-54bcaeed`; SKILL.md (таблица, команда гейта).

## Замечено / риски

- **Сборщик `/tmp/build_pages.py` и спеки городов не пережили рестарт среды** (жили вне репо).
  Эта правка выполнена точечным апдейтером поверх готовых страниц, что безопаснее для контента.
  Сборщик надо восстановить в `scripts/` отдельной задачей — иначе новые города собирать нечем.
- Секция офисов Irvine на скриншоте: карта рисует пин и подпись «1F Cash Advance» — Google сам
  резолвит адрес в бизнес-точку. Наезд подписи на карточку нет, iframe 360px.

---

# Сборщик восстановлен (02.11.2026, вторая половина дня)

`/tmp/build_pages.py` и спеки не пережили рестарт — восстановлены в репо, больше не в `/tmp`.

## Что появилось

- `scripts/build_page.py` — сборщик: spec JSON → страница. Генерирует head+CSS (общий
  `assets/page-shell-v5.css`), topbar, hero (P0-5: меняются только H1, штат в карточке, дата),
  обёртки секций с вычисляемой зеброй (alt на нечётных, никогда не из спеки), 6 JSON-LD
  (FAQPage пересериализуется из видимого FAQ — P0-9 по построению). Гварды: нет `{{`,
  блок городских ссылок == реестр `cities-99.md` минус текущий город, зебра-дрейф.
  В конце сам прогоняет гейт.
- `scripts/extract_spec.py` — готовая страница → spec JSON. Тела секций хранятся сырым HTML
  (контент не переизобретается шаблоном), структурными остаются только hero-поля, FAQ и
  мета (slug'и, даты, service name). Разделители между секциями и форма обёртки FAQ-LD
  сохраняются в спеке — пересборка побайтова.
- `specs/<slug>.json` — 6 спек: irvine-ca, north-las-vegas-nv, kansas-city-mo,
  greenfield-in, tulsa-ok, hiram-ga.

## Критерий приёмки — выполнен

- Пересборка каждой из 6 страниц воспроизводит файл **бит-в-бит** (`diff` пуст на всех).
- Гейт на каждой пересобранной копии: `RESULT: PASS (all 43 rules)` ×6.
- Дым эталона после правки CLAUDE.md: `PASS (all 43 rules)`; штамп `2026-10-01-3ff27b88`.

## Замечено при восстановлении

- Calc-JS у страниц разный (Irvine `FEE_RATE`, Tulsa ступенчатая формула OK, у KC/Hiram
  свои варианты; у Hiram calc-секции нет вовсе) — поэтому `<script>`-блоки хранятся в спеке
  сырыми, как и тела секций. Сборщик отвечает за каркас, не за контент.
- Обёртка FAQPage JSON-LD двух поколений: Irvine — JSON на отдельных строках, остальные
  пять — вплотную к тегам. Флаг `faq_ld_newlines` в спеке.
- Между некоторыми секциями в исходниках пустая строка (KC перед cities, Hiram перед
  stats) — разделители сохранены в спеке (`seps`).

---

# Перелинковка из краула сайта (02.11.2026, вечер)

Решение владельца: после генерации страницы links-sec пополняется ссылками на внутренние
страницы сайта из присланного краула `internal_1f_all_9947.csv` (Screaming Frog, 30.10.2026,
930 URL) — без повторов с уже имеющимися блоками перелинковки.

## Что сделано

- Краул сохранён в репо: `references/internal-links.csv` (источник P0-1 для целей ссылок:
  только 200 + Indexable).
- `scripts/interlink.py` — пополняет links-sec по правилам: +≤2 суммы (≤ потолка штата,
  по возрастанию, **не из таблицы закона** — §1 блок 16, голых вхождений `$N` ≤ 1 до
  добавления), +2 лендинга, +2 поста; URL не повторяет ни один URL страницы; режим запрета —
  без payday-лендингов/постов; $255 — только CA; наборы ротируются по городу (crc32).
- Прогон на 6 страницах. Добавлено:
  - Irvine: ways Direct Lender/Guaranteed Payday Loans; blog Medical Bill Loans, Loans Without
    a Bank Account. Сумма $300 **не** добавлена — она в таблице закона (§1 блок 16).
  - North Las Vegas: $150, $800; ways Weekend/No Teletrack; blog Home Repair Loans,
    Emergency Cash for Single Mothers.
  - Kansas City: $150, $250; ways Guaranteed Installment/Tribal; blog How Many Americans Use
    Payday Loans, Loans for the Unemployed.
  - Greenfield: $150, $300; ways Holiday/Vacation Loans; blog Loans for Groceries,
    Personal Loans vs. Credit Cards.
  - Tulsa: $200 (остальное уперто в бюджет $≤2); ways Guaranteed Installment/Second Chance;
    blog Small Business Loans, What Are Title Loans.
  - Hiram (режим запрета): $800, $1,000; ways Secured/Unsecured Personal Loans; blog
    Line of Credit vs. Loan, Ways to Make Extra Money — без payday-специфики.
- Гейт после правок: `PASS (all 43 rules)` ×6 (validate-output.txt обновлён).
- Спеки ре-извлечены, пересборка бит-в-бит ×6; витрины `<Штат> Final/` синхронизированы.
- Промт обновлён: CLAUDE.md P2-14 + структура (штамп `2026-10-01-15786da3`), SKILL.md
  (шаг 5 маршрута B + таблица), page-spec §1 блок 16, checklist (ручная проверка).
- `.BEFORE.html` копии шести страниц — в той же папке, по правилу выдачи.

## Замечено

- Краул содержит 535 `wp-content` URL (картинки/ассеты) — в пулы не входят, фильтр по
  префиксам разделов. Свежие страницы сайта вне пулов скрипта не подхватываются: новый
  лендинг/пост сначала добавляется в пул скрипта, затем попадает на страницы.
