#!/usr/bin/env python3
"""Build the six North Carolina city pages (spec v3) into builds/2026-09-16-nc/."""
import html, json, os, re, sys

ROOT = "/Users/bamer/Downloads/VS CODE/1F Locations"
OUT = os.path.join(ROOT, "builds/2026-09-16-nc")
BASE = os.path.join(ROOT, "builds/Alabama Final/dothan-al-loans-NEW.html")

STATE, ST = "North Carolina", "NC"
DATE, DATE_ISO, CUTOFF = "September 16, 2026", "2026-09-16", "12:30 pm"
DEBT = {2020: 48480, 2021: 51130, 2022: 55370, 2023: 57650, 2024: 58900}
STATE_MHI_2024 = 74055

DOJ = "https://ncdoj.gov/protecting-consumers/credit-and-debt/payday-loans/"
CF = "https://nccob.nc.gov/financial-institutions/consumer-finance"
CFFAQ = "https://nccob.nc.gov/financial-institutions/consumer-finance/frequently-asked-questions"
COMPLAINT = "https://nccob.nc.gov/consumer-information/consumer-inquiries-and-complaint-information"

CUTOFF_FAQ = ("How fast could the money reach my account?",
              "If a lender approves you and the application is finalized by 12:30 pm local time on a weekday, funds can arrive the same day. Later applications, weekends and bank holidays move funding to the next business day, and same-day deposit is not available to every customer.")

CITIES = [
 dict(city="Charlotte", county="Mecklenburg County", fips="119",
      mhi={2020: 72340, 2021: 75138, 2022: 80645, 2023: 84796, 2024: 90698},
      offices=[('122 W Trade St', '28202', 'Open today 8:00 AM &ndash; 8:00 PM'), ('6105 The Plaza F', '28215', 'Open today 8:00 AM &ndash; 8:00 PM'), ('8537 Park Rd #17', '28210', 'Open today 8:00 AM &ndash; 8:00 PM'), ('9335 Center Lake Dr #150', '28216', 'Open today 8:00 AM &ndash; 5:00 PM'), ('3701 Arco Corporate Dr #125', '28273', 'Open today 8:00 AM &ndash; 8:00 PM')],
      p1="No. Payday lenders were shut down in North Carolina, so the legal route is a licensed consumer finance loan of up to $25,000, repaid over 12 to 96 monthly payments at no more than 33% a year on the first $4,000.",
      p2="Mecklenburg County income rose in every year shown below and ended 2024 above the state median, but a licensed loan is repaid in fixed monthly installments that do not rise with a county average. Size the payment against your own take-home pay for the months ahead, not against the county's climb.",
      lbl4="Median household income in Mecklenburg County in 2024, the latest year in the table below",
      growth="County income grew about twenty-five percent in five years, ahead of just over twenty-one for state debt per person.",
      housing="One in three households here",
      faq=[("Can an online lender in another state make me a payday loan anyway?",
            "Some try, and the Attorney General has taken them to court. In one 2020 case against an out-of-state online lender, North Carolina borrowers received full refunds and had their outstanding loans canceled. If an online offer looks like a payday loan, check the lender's state license before sharing any bank details."),
           ("Does the company collecting my loan payments need a license too?",
            "It does if the loan was made under the Consumer Finance Act. Since October 1, 2023, a business that takes scheduled payments on those loans must be licensed by the Commissioner of Banks, even when it did not make the loan itself."),
           ("Is a credit card cash advance better than a payday loan?",
            "The Attorney General's office says a credit card advance, or a loan from a local consumer finance company, costs more than a credit union loan but is still a better choice than a payday loan. Start with a credit union, then compare the other two on total cost.")]),
 dict(city="Durham", county="Durham County", fips="063",
      mhi={2020: 65619, 2021: 71436, 2022: 79524, 2023: 81413, 2024: 84375},
      offices=[('1221 University Dr', '27707', 'Open today 8:00 AM &ndash; 7:00 PM'), ('1100 N Miami Blvd #109', '27703', 'Open today 8:00 AM &ndash; 6:00 PM'), ('3411C University Dr', '27707', 'Open today 8:00 AM &ndash; 7:00 PM'), ('7103 NC-751', '27707', 'Open today 8:00 AM &ndash; 5:30 PM'), ('2200 W Main St L100', '27705', 'Open today 8:00 AM &ndash; 5:00 PM')],
      p1="No. North Carolina closed its payday lenders. What a licensed lender can offer instead is a consumer finance loan capped at $25,000, with interest held to 33% a year on the first $4,000 and repayment spread across 12 to 96 months.",
      p2="Durham County income climbed each year from 2020 to 2024 and finished $10,320 above the state median. A higher local median can make a larger loan look affordable, yet every dollar borrowed is repaid monthly for the whole term, so borrow what closes the gap rather than what a county figure suggests you could carry.",
      lbl4="Median household income in Durham County in 2024, the most recent year of county data shown below",
      growth="County income rose nearly twenty-nine percent in five years, while state debt per person rose just over twenty-one.",
      housing="Nearly a third of households here",
      faq=[("How do I stop an online lender from drafting my bank account?",
            "Tell your bank you are canceling the electronic draft, and tell the lender in writing or by email that you have withdrawn permission. If the drafts continue, the Attorney General's office notes you may need to close the account, but open a new one at a different bank first."),
           ("Do banks and credit unions need the same license as finance companies?",
            "They are exempt from it. The consumer finance license covers non-bank lenders, and the Commissioner of Banks lists banks, trust companies and credit unions among the businesses that do not need one."),
           CUTOFF_FAQ]),
 dict(city="Fayetteville", county="Cumberland County", fips="051",
      mhi={2020: 49160, 2021: 52463, 2022: 58013, 2023: 61511, 2024: 60831},
      offices=[('2718 Bragg Blvd Ste B-2', '28303', 'Open today 8:00 AM &ndash; 5:30 PM'), ('2653 Hope Mills Rd Ste 13', '28306', 'Open today 8:00 AM &ndash; 5:30 PM'), ('7711 S Raeford Rd #101', '28304', 'Open today 8:00 AM &ndash; 5:30 PM'), ('1400 Walter Reed Road Ext #110', '28304', 'Open today 8:00 AM &ndash; 5:30 PM')],
      p1="No. A payday loan is not a legal option in North Carolina. A licensed consumer finance loan of $25,000 or less takes its place, charging at most 33% a year on the first $4,000 and paid back in monthly installments.",
      p2="Cumberland County income rose through 2023 and then slipped in 2024. A licensed loan runs for at least 12 monthly payments, long enough to outlast a year like that, so before signing, check that the payment still fits if next year's pay dips the same way.",
      lbl4="Median household income in Cumberland County in 2024, the second highest of the five years in the table below",
      growth="County income grew about twenty-four percent in five years, a little ahead of state debt per person.",
      housing="More than a third of households here",
      faq=[("A collector says I owe on a payday loan I never took out. What should I do?",
            "The Attorney General's office warns that crooks try to collect on online payday loans that were never made. You can ask for collection efforts to stop, and if the caller threatens arrest or wage garnishment, file a complaint at 1-877-5-NO-SCAM."),
           ("Can I push back a payment on a licensed loan?",
            "Yes, if the lender agrees. A licensed lender may charge up to 1.5% of each monthly installment you defer, and the loan's final due date does not move. If you defer more than one payment, get the deferral agreement in writing."),
           ("Where can I get a small loan quickly instead of a payday loan?",
            "The Attorney General's office points to credit unions, including the State Employees' Credit Union, for low-interest short-term loans with quick approval. Salary advances from an employer and an extended payment plan with the company you owe are other options it lists.")]),
 dict(city="Greenville", county="Pitt County", fips="147",
      mhi={2020: 49955, 2021: 48116, 2022: 57319, 2023: 60268, 2024: 59430},
      offices=[('3015 S Memorial Dr', '27834', 'Open today 8:00 AM &ndash; 5:30 PM'), ('2803 Evans St Ste 106', '27834', 'Open today 8:00 AM &ndash; 5:00 PM'), ('3130 Evans St Ste 103', '27834', 'Open today 8:00 AM &ndash; 5:30 PM'), ('460 Moye Blvd Ste 103', '27834', 'Open today 8:00 AM &ndash; 5:30 PM')],
      p1="No. Payday lending was pushed out of North Carolina. In its place, licensed lenders make consumer finance loans of up to $25,000, and the rate cannot pass 33% a year on the first $4,000 of what you owe.",
      p2="Pitt County income fell in two of the five years shown below, in 2021 and again in 2024. Because a licensed loan here lasts at least a year of monthly payments, one of those down years could land in the middle of it, so build the payment around your leanest recent month, not your best.",
      lbl4="Median household income in Pitt County in 2024, the second highest year in the table below",
      growth="County income grew about nineteen percent in five years, behind state debt per person at just over twenty-one.",
      housing="About one in three households here",
      faq=[("How can I check that a lender is licensed?",
            "The Commissioner of Banks licenses consumer finance lenders and lists them on its website. Look up the company named in your offer before you sign, and if a licensed lender treats you unfairly, the Commissioner's office takes complaints through an online form."),
           ("What does a late payment cost on a licensed loan?",
            "A late fee can apply only once a payment is 10 days past due and only if your contract discloses it. The Commissioner of Banks puts the current cap at $18, and just one fee can be charged for each late payment."),
           ("Is a car title loan an option here?",
            "Not from a lender following North Carolina's rules. The Attorney General's office says car title lenders were pushed out of the state along with payday lenders, and it has gone after a title lender across the border that charged North Carolina borrowers triple-digit interest.")]),
 dict(city="Lumberton", county="Robeson County", fips="155",
      mhi={2020: 39139, 2021: 38613, 2022: 39931, 2023: 42180, 2024: 46927},
      offices=[('2204 N Pine St', '28358', 'Open today 8:00 AM &ndash; 5:00 PM'), ('3217 Fayetteville Rd', '28358', 'Open today 8:00 AM &ndash; 5:30 PM'), ('601 N Elm St', '28358', 'Open today 8:00 AM &ndash; 5:30 PM')],
      p1="No. Payday lenders no longer operate in North Carolina, so borrowing here goes through a lender the Commissioner of Banks licenses. That loan can reach $25,000, caps interest at 33% a year on its first $4,000, and runs 12 to 96 months.",
      p2="Robeson County income slipped in 2021, rose three years running, and still finished 2024 some $27,128 under the state median. On a budget that far below the state's typical household, the monthly payment is the number to test first; if it only fits in a good month, borrow less or look at the alternatives below.",
      lbl4="Median household income in Robeson County in 2024, the highest level in the table below",
      growth="County income rose about twenty percent across these five years, slightly behind state debt per person.",
      housing="Nearly three in ten households here",
      faq=[("I already have an online payday loan and cannot keep up. Where do I start?",
            "Start with the lender. The Attorney General's office suggests offering to repay the principal amount. You can also withdraw permission for the lender to draft your bank account, and if collectors harass you or threaten arrest, call 1-877-5-NO-SCAM."),
           ("What happens to the interest rate if my loan goes to court?",
            "Once a licensed loan reaches maturity or becomes subject to a court judgment, the Commissioner of Banks says the rate should drop to 8% a year. Check that the balance you are asked to pay reflects that lower rate from that point on."),
           ("Does it cost anything to apply through 1F Cash Advance?",
            "The request form is free to use, and prequalifying runs a soft check that does not affect your credit score. Any charges come from the lender whose offer you accept, so read the rate and total cost in that offer before you agree.")]),
 dict(city="Rocky Mount", county="Nash County", fips="127",
      mhi={2020: 49883, 2021: 55956, 2022: 55406, 2023: 65457, 2024: 66531},
      offices=[('850 W Raleigh Blvd', '27803', 'Open today 8:00 AM &ndash; 6:00 PM'), ('4461 Sunset Ave', '27804', 'Open today 8:00 AM &ndash; 6:00 PM'), ('1575 Benvenue Rd Unit E-03', '27804', 'Open today 8:00 AM &ndash; 5:30 PM')],
      p1="No. Where a payday loan once filled the gap, North Carolina now allows only licensed consumer finance lending: at most 33% a year on the first $4,000 borrowed, a ceiling of $25,000, and no fewer than 12 monthly payments.",
      p2="Nash County income dipped in 2022 and then jumped in 2023, a swing large enough to change what a household can afford from one year to the next. A licensed loan's monthly payment stays fixed through swings like that, so set it by the pay you receive now, not by the latest gain.",
      lbl4="Median household income in Nash County in 2024, the highest of the five years in the table below",
      growth="County income grew about a third in five years, well ahead of state debt per person.",
      housing="About a quarter of households here",
      faq=[("What if a collector threatens to have me arrested over a payday loan?",
            "Report it. The Attorney General's office asks people to file a complaint when a payday lender or collector harasses them or threatens arrest or wage garnishment, at 1-877-5-NO-SCAM toll free within North Carolina. You can also ask that collection efforts stop."),
           ("Why do payday offers still reach me online if they are shut down here?",
            "Payday lenders still reach North Carolina residents over the internet, and the Attorney General's office warns the risks there are higher: collectors may be unlicensed or based overseas. Once such a lender has your account details, stopping withdrawals can be hard, so keep bank information private."),
           ("Who oversees a lender that stays at or below the general state rate?",
            "Not the Commissioner of Banks. Its consumer finance license covers loans priced above the general limit, which is 16% a year on certain consumer loans. Questions about lenders at or below that rate go to the North Carolina Department of Justice.")]),
]


def slug(c):
    return c.lower().replace(" ", "-") + "-nc-loans"


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build(c):
    if not c["offices"]:
        raise SystemExit(f"no offices for {c['city']} — ask the user first (P1-1)")
    base = open(BASE, encoding="utf-8").read()
    head = base[:base.find("</head>")]
    city, county = c["city"], c["county"]
    h1 = f"Payday loan alternatives in {city}, {STATE}"
    title = f"{h1} | 1F Cash Advance"
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)
    assert "<!-- skill-version: v2 -->" in head
    fred_c = f"https://fred.stlouisfed.org/series/MHINC37{c['fips']}A052NCEN"
    fred_s = "https://fred.stlouisfed.org/series/MHINC37000A052NCEN"
    dp04 = f"https://fred.stlouisfed.org/series/DP04ACS037{c['fips']}"
    m24 = c["mhi"][2024]
    gap = STATE_MHI_2024 - m24
    gap_txt = f"{money(abs(gap))} {'below' if gap > 0 else 'above'}"
    gap_lbl = f"How far {county} sat {'under' if gap > 0 else 'above'} the {STATE} median in 2024"

    hs = base.find('<div class="topbar">'); he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he]
    hero = hero.replace("Payday Loans in Dothan, Alabama", h1).replace("licensed Alabama lender", f"licensed {STATE} lender")
    hero = hero.replace("Updated: September 3, 2026", f"Updated: {DATE}")
    assert "Dothan" not in hero and "Alabama" not in hero

    offices = "".join(
        f'<div class="office-card">\n<p class="office-addr">{html.escape(st)}<br>{city}, {ST} {z}</p>\n'
        f'<p class="office-hours">{hours}</p>\n</div>'
        for st, z, hours in c["offices"])

    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(c['mhi'][y])}</td><td>{money(DEBT[y])}</td><td>{money(round(c['mhi'][y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))

    others = [x["city"] for x in CITIES if x["city"] != city]
    links = " &middot; ".join(f'<a href="https://1firstcashadvance.org/{slug(o)}/">{o}</a>' for o in others)

    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in c["faq"])

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {city} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {city}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>The legal route in {STATE}. You repay in monthly payments on a set schedule rather than in one lump sum, and the lender has to hold a state license. Ask for the total cost of credit in dollars before you sign.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Personal Loans</h3>
        <p>For a larger or longer need, a personal loan spreads repayment further and is priced on your credit and income. Compare the total cost in dollars against an installment loan rather than comparing monthly payments alone.</p>
        <a href="https://1firstcashadvance.org/personal-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Personal Loans &rarr;</a></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>Where to get payday loan alternatives in {city}</h2>
    <div class="office-grid">
{offices}
</div>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {city}?</h2>
    <p>{c['p1']}</p>
    <p style="margin-top:14px">{c['p2']}</p>
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {city}: What the Numbers Show</h2>
<div class="stat-grid">
<div class="stat-card"><div class="num gold">Shut down</div><div class="lbl">Payday lenders no longer operate in the state, though some still reach residents online</div><div class="src">Source: <a href="{DOJ}">North Carolina Department of Justice, payday loans</a></div></div>
<div class="stat-card"><div class="num navy">State ceiling</div><div class="lbl">A licensed consumer finance loan has a dollar ceiling written into state law</div><div class="src">Source: <a href="{CF}">North Carolina Commissioner of Banks, consumer finance</a></div></div>
<div class="stat-card"><div class="num navy">Capped by size</div><div class="lbl">The highest rate a licensed lender may charge steps down as the balance grows</div><div class="src">Source: <a href="{CFFAQ}">Commissioner of Banks consumer finance FAQ</a></div></div>
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">{c['lbl4']}</div><div class="src">Source: <a href="{fred_c}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{gap_txt}</div><div class="lbl">{gap_lbl}</div><div class="src">Source: <a href="{fred_s}">Census SAIPE for North Carolina via FRED</a></div></div>
<div class="stat-card"><div class="num navy">Lower after maturity</div><div class="lbl">Once a licensed loan matures or goes to judgment, its interest rate has to come down</div><div class="src">Source: <a href="{CFFAQ}">Commissioner of Banks consumer finance FAQ</a></div></div></div>
<p class="tbl-cap">{county} median household income and {STATE} household debt, 2020 to 2024</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{STATE} debt per person</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">County income comes from <a href="{fred_c}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column comes from the <a href="https://www.newyorkfed.org/microeconomics/databank.html">New York Fed Consumer Credit Panel</a>. {c['growth']} <a href="{dp04}">{c['housing']}</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. {STATE} sets a flat ceiling instead of an income test, so the amount does not change with local earnings. The last column is a calculation, not a published figure: monthly county income after the standard housing share. It describes a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>These are the small-loan rules for all of {STATE}, including {city}. In plain terms: what has been shut down, what is allowed instead, and who to call if a lender breaks the rules. Full detail is in the <a href="{CFFAQ}">Commissioner of Banks consumer finance FAQ</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
      <tr><td>Payday lending</td><td>Payday lenders were shut down in the state, and the Attorney General pursues online lenders that still reach residents</td></tr>
      <tr><td>Allowed instead</td><td>A consumer finance loan from a lender licensed by the Commissioner of Banks, for amounts up to the state ceiling</td></tr>
      <tr><td>Rate, loans up to $12,000</td><td>33% a year on the first $4,000 of balance, 24% up to $8,000, and 18% above that</td></tr>
      <tr><td>Rate, larger loans</td><td>18% a year on loans over $12,000</td></tr>
      <tr><td>Term</td><td>12 to 96 monthly payments</td></tr>
      <tr><td>Late fee</td><td>Only after a payment is 10 days late, currently capped at $18</td></tr>
      <tr><td>Without a license</td><td>16% a year on certain loans of $25,000 or less</td></tr>
      <tr><td>Where to report it</td><td>The Commissioner of Banks for licensed lenders, or the Attorney General's consumer protection line</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Ask for the annual percentage rate and the total cost in dollars before you sign, and check both against what your budget can carry for every month of the term.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {city}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {city} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history rather than a credit score alone.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call your {county} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Check the license before anything else.</strong> Ask which state license the lender holds and confirm it with the regulator before you share your bank details.</li>
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Interest runs on the balance, and qualifying for more is not a reason to take more.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the payment schedule in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any small loan.</li>
      </ul>
      <p style="margin-bottom:0">To check a license or file a complaint, contact the <a href="{COMPLAINT}">North Carolina Office of the Commissioner of Banks</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{city} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>1F Cash Advance in Other {STATE} Cities</h2>
    <p style="max-width:760px">The same {STATE} rules apply statewide. See how they play out where you live:</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
"""
    a_s = base.rfind("<section", 0, base.find("Who wrote this")); a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e].replace("Houston County", county)
    assert "Dothan" not in authors and "Alabama" not in authors

    url = f"https://1firstcashadvance.org/{slug(city)}/"
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": url, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": "https://1firstcashadvance.org/loans-by-state/north-carolina/"}, {"@type": "ListItem", "position": 4, "name": city}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": {"@type": "Person", "name": "Latoria Williams"}, "editor": {"@type": "Person", "name": "Marsha Welch"}, "reviewedBy": {"@type": "Person", "name": "Michael Lefler"}, "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Payday loan alternative matching in {city}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{city}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    for c in CITIES:
        if only and c["city"] not in only:
            continue
        p = os.path.join(OUT, slug(c["city"]) + "-NEW.html")
        open(p, "w", encoding="utf-8").write(build(c))
        print("wrote", p)


if __name__ == "__main__":
    main()
