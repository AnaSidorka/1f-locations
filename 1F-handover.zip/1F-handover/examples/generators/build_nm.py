#!/usr/bin/env python3
"""Build the four New Mexico city pages (spec v3) into builds/2026-09-17-nm/."""
import html, json, os, re, sys

ROOT = "/workspace"
OUT = os.path.join(ROOT, "builds/2026-09-17-nm")
BASE = os.path.join(ROOT, "builds/Alabama Final/dothan-al-loans-NEW.html")

STATE, ST = "New Mexico", "NM"
DATE, DATE_ISO, CUTOFF = "September 17, 2026", "2026-09-17", "10:30 am"
DEBT = {2020: 41800, 2021: 42930, 2022: 46710, 2023: 47140, 2024: 47920}
STATE_MHI_2024 = 67838

SLC = "https://www.rld.nm.gov/financial-institutions/who-we-regulate/small-loan-companies/"
SIGN = "https://www.srca.nm.gov/parts/title12/12.018.0004.html"
COMPLAINT = "https://www.rld.nm.gov/financial-institutions/file-a-complaint/"


def hrs(close):
    return f"Open today 8:00 AM &ndash; {close}" if close else "Opens 8:00 AM &middot; call ahead for closing"


CITIES = [
 dict(city="Albuquerque", county="Bernalillo County", fips="001",
      mhi={2020: 56632, 2021: 59723, 2022: 65034, 2023: 68286, 2024: 72986},
      offices=[("111 Coors Blvd NW Ste C1", "87121", hrs("7:00 PM")), ("1521 Eubank Blvd NE", "87112", hrs("7:00 PM")),
               ("333 Montaño Rd NW Ste E", "87107", hrs("7:00 PM")), ("4420 Central Ave SW", "87105", hrs("7:00 PM")),
               ("1500 Juan Tabo Blvd NE", "87112", hrs("7:00 PM")), ("8400 Menaul Blvd NE Ste B", "87112", hrs("6:00 PM")),
               ("7307 Jefferson St NE Ste C1", "87109", hrs("8:00 PM")), ("4625 4th St NW", "87107", hrs("6:00 PM")),
               ("6001 Central Ave NE", "87105", hrs("6:00 PM")), ("5614 Central Ave NW", "87105", hrs("6:00 PM"))],
      p1="No. What licensed lenders in New Mexico offer instead is an installment loan of up to $10,000, repaid in at least four roughly equal payments over 120 days or more, with an NM-APR capped at 36% for all but the smallest loans.",
      p2="Bernalillo County income rose in every year shown below and ended 2024 above the state median. A county that keeps gaining can make a larger installment loan look easy to carry, but the payments keep coming for the full term, so size the loan to pay you have now, not to next year's expected raise.",
      lbl4="Median household income in Bernalillo County in 2024, the latest year in the table below",
      growth="County income grew about twenty-nine percent in five years, ahead of about fifteen for state debt per person.",
      housing="About a third of households here",
      faq=[("Why does my loan paperwork show two different APRs?",
            "Federal law requires a standard APR so you can compare lenders. New Mexico adds its own NM-APR, which can count charges the federal figure leaves out. The state caps apply to the NM-APR, so that is the number to check against the limit."),
           ("How do I file a complaint against a small loan company?",
            "Fill out the Financial Institutions Division complaint form and send it, with any documents, to the Division, or call it at (505) 476-4885. The Division does not oversee federally chartered banks or credit unions, so a complaint about one of those goes to its federal regulator."),
           ("How fast could the money reach my account?",
            "If a lender approves you and the application is finalized by 10:30 am local time on a weekday, funds can arrive the same day. Later applications, weekends and bank holidays move funding to the next business day, and same-day deposit is not available to every customer.")]),
 dict(city="Clovis", county="Curry County", fips="009",
      mhi={2020: 53864, 2021: 50322, 2022: 52463, 2023: 53858, 2024: 57333},
      offices=[("403 Pile St", "88101", hrs("9:00 PM")), ("301 W Llano Estacado Blvd", "88101", hrs(None)),
               ("4205 N Prince St", "88101", hrs("5:00 PM")), ("2020 Sheffield Dr", "88101", hrs(None)),
               ("1820 N Prince St", "88101", hrs("6:00 PM")), ("500 W 7th St", "88101", hrs("6:00 PM"))],
      p1="No. New Mexico's licensed small loan companies lend in installments instead: four or more roughly equal payments, a term of at least 120 days, a ceiling of $10,000, and a 36% NM-APR limit above the smallest loan size.",
      p2="Curry County income fell in 2021 and took until 2023 to climb back to about where it stood in 2020, finishing 2024 some $10,505 under the state median. A recovery that slow can stall again, so pick a monthly payment you could still make in a year like 2021, even if that means borrowing less.",
      lbl4="Median household income in Curry County in 2024, the highest of the five years in the table below",
      growth="County income grew about six percent in five years, behind about fifteen for state debt per person.",
      housing="Nearly a third of households here",
      faq=[("What is a refund anticipation loan?",
            "It is a loan repaid, directly or indirectly, from your federal or state income tax refund or tax credits, including when a lender buys your refund at a discount. Licensed small loan companies may offer them, and state law defines them separately from installment loans."),
           ("Why was I quoted a higher rate than someone else?",
            "Your actual terms and APR are set when you apply and depend on your application and credit information, so not every borrower qualifies for a lender's lowest rate. Whatever the quote, a licensed small loan still has to stay within the state's NM-APR limits."),
           ("Does 1F Cash Advance lend the money?",
            "It does not. 1F Cash Advance is a loan connector: it passes one request to licensed lenders, and the lender that makes an offer sets the terms and funds the loan. Your agreement will name that lender, and that is the company the New Mexico rules on this page apply to.")]),
 dict(city="Gallup", county="McKinley County", fips="031",
      mhi={2020: 35659, 2021: 40149, 2022: 43720, 2023: 41427, 2024: 45517},
      offices=[("1373 W Jefferson Ave", "87301", hrs("5:30 PM")), ("307 W Aztec Ave #6303", "87301", hrs("5:00 PM")),
               ("1383 US-491", "87301", hrs("5:00 PM"))],
      p1="No. Here the licensed option is an installment loan, not a two-week one: as much as $10,000, a schedule of 120 days or more with at least four payments, and a 36% NM-APR limit past the smallest tier.",
      p2="McKinley County income grew in most years shown below but slipped in 2023, and it finished 2024 some $22,321 under the state median. With household budgets that tight, a monthly loan payment has to survive a down year, so test it against your leanest recent month before you sign.",
      lbl4="Median household income in McKinley County in 2024, the highest level in the table below",
      growth="County income grew about twenty-eight percent in five years, well ahead of state debt per person.",
      housing="Just over one in five households here",
      faq=[("Do tribal or offshore lenders have to follow these rate limits?",
            "Not always. The Financial Institutions Division warns that foreign companies and Native American lenders operating on tribal land are not subject to the New Mexico small loan rate laws. Ask about the company's license and your exact rate before you sign anything."),
           ("Is there an extra fee on the smallest loans?",
            "On the smallest small loans, a lender may add a fee of up to 5% of the principal on top of the NM-APR limit, and it can charge that fee to a borrower only once in any 12-month period. Larger loans do not get that extra allowance."),
           ("What should I have ready before I apply?",
            "A photo ID, your Social Security number, a checking account with its routing number and a recent pay stub or other proof of income. You also need proof of a New Mexico address, a working phone and email, and to be at least 18.")]),
 dict(city="Las Cruces", county="Doña Ana County", fips="013",
      mhi={2020: 46547, 2021: 46619, 2022: 52011, 2023: 56233, 2024: 60154},
      offices=[("2750 Mall Dr Ste 220", "88011", hrs("5:00 PM")), ("1240 S Valley Dr Ste A", "88005", hrs("6:00 PM")),
               ("2144 N Main St", "88001", hrs("6:00 PM")), ("111 S Solano Dr Ste A", "88001", hrs("7:00 PM")),
               ("400 N Telshor Blvd Ste B", "88011", hrs("5:30 PM")), ("1303 E Lohman Ave Ste 5", "88001", hrs("5:30 PM")),
               ("540 Walton Blvd Ste B", "88001", hrs("5:30 PM"))],
      p1="No. A licensed small loan in New Mexico works differently: it can reach $10,000, it must run at least 120 days with four or more roughly equal payments, and its NM-APR stops at 36% once it is larger than the smallest tier.",
      p2="Doña Ana County income barely moved in 2021 before rising three years in a row, ending 2024 some $7,684 under the state median. A run of raises can make a payment look smaller than it will feel if pay flattens again, so plan it around a year like 2021, not 2024.",
      lbl4="Median household income in Doña Ana County in 2024, the most recent year of county data shown below",
      growth="County income rose about twenty-nine percent, about twice the rise in state debt per person.",
      housing="Close to a third of households here",
      faq=[("What should a small loan office show me before I borrow?",
            "Every licensed office must post a sign listing its APR and every fee it may charge, with a contact for complaints, and keep a brochure of common loan terms by the main door. Lenders taking applications online must link to the same information."),
           ("Do banks and credit unions follow the same small loan rules?",
            "They do not need a small loan license, but the state's NM-APR limits also cover installment loans made under the Bank Installment Loan Act of 1959. Ask any lender, bank or not, for both APR figures before you sign."),
           ("Can I apply from my phone?",
            "Yes. The request form works on a phone, stays open around the clock and takes about five minutes. Keep your pay stub and bank details handy, since the lender verifies your income and application details before deciding.")]),
]


def slug(c):
    return c.lower().replace(" ", "-") + "-nm-loans"


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build(c):
    if not c["offices"]:
        raise SystemExit(f"no offices for {c['city']} — ask the user first (P1-1)")
    base = open(BASE, encoding="utf-8").read()
    head = base[:base.find("</head>")]
    city, county = c["city"], c["county"]
    h1 = f"Payday loan alternatives in {city}, {STATE}"
    title = f"{h1} | 1F Cash Advance"
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)
    assert "<!-- skill-version: v2 -->" in head
    fred_c = f"https://fred.stlouisfed.org/series/MHINM35{c['fips']}A052NCEN"
    fred_s = "https://fred.stlouisfed.org/series/MHINM35000A052NCEN"
    dp04 = f"https://fred.stlouisfed.org/series/DP04ACS035{c['fips']}"
    m24 = c["mhi"][2024]
    gap = STATE_MHI_2024 - m24
    gap_txt = f"{money(abs(gap))} {'below' if gap > 0 else 'above'}"
    gap_lbl = f"How far {county} sat {'under' if gap > 0 else 'above'} the {STATE} median in 2024"

    hs = base.find('<div class="topbar">'); he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he]
    hero = hero.replace("Payday Loans in Dothan, Alabama", h1).replace("licensed Alabama lender", f"licensed {STATE} lender")
    hero = hero.replace("Updated: September 3, 2026", f"Updated: {DATE}")
    assert "Dothan" not in hero and "Alabama" not in hero

    offices = "".join(
        f'<div class="office-card">\n<p class="office-addr">{html.escape(st)}<br>{city}, {ST} {z}</p>\n'
        f'<p class="office-hours">{hours}</p>\n</div>'
        for st, z, hours in c["offices"])

    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(c['mhi'][y])}</td><td>{money(DEBT[y])}</td><td>{money(round(c['mhi'][y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))

    others = [x["city"] for x in CITIES if x["city"] != city]
    links = " &middot; ".join(f'<a href="https://1firstcashadvance.org/{slug(o)}/">{o}</a>' for o in others)

    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in c["faq"])

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {city} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {city}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>The legal route in {STATE}. You repay in monthly payments on a set schedule rather than in one lump sum, and the lender has to hold a state license. Ask for the total cost of credit in dollars before you sign.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Personal Loans</h3>
        <p>For a larger or longer need, a personal loan spreads repayment further and is priced on your credit and income. Compare the total cost in dollars against an installment loan rather than comparing monthly payments alone.</p>
        <a href="https://1firstcashadvance.org/personal-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Personal Loans &rarr;</a></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>Where to get payday loan alternatives in {city}</h2>
    <div class="office-grid">
{offices}
</div>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {city}?</h2>
    <p>{c['p1']}</p>
    <p style="margin-top:14px">{c['p2']}</p>
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {city}: What the Numbers Show</h2>
<div class="stat-grid">
<div class="stat-card"><div class="num gold">Installment instead</div><div class="lbl">Licensed small loan companies here offer installment, tax refund and small business loans</div><div class="src">Source: <a href="{SLC}">New Mexico Financial Institutions Division, small loan companies</a></div></div>
<div class="stat-card"><div class="num navy">State ceiling</div><div class="lbl">A licensed small loan has a dollar ceiling written into the Small Loan Act</div><div class="src">Source: <a href="{SLC}">New Mexico Financial Institutions Division, small loan companies</a></div></div>
<div class="stat-card"><div class="num navy">Capped since 2023</div><div class="lbl">Small loans made from January 2023 on carry a statewide ceiling on the NM-APR</div><div class="src">Source: <a href="{SIGN}">12.18.4 NMAC, small loan signage rule</a></div></div>
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">{c['lbl4']}</div><div class="src">Source: <a href="{fred_c}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{gap_txt}</div><div class="lbl">{gap_lbl}</div><div class="src">Source: <a href="{fred_s}">Census SAIPE for New Mexico via FRED</a></div></div>
<div class="stat-card"><div class="num navy">Posted in full</div><div class="lbl">Every licensed office has to display its APR and a complete list of the fees it charges</div><div class="src">Source: <a href="{SIGN}">12.18.4 NMAC, small loan signage rule</a></div></div></div>
<p class="tbl-cap">{county} median household income and {STATE} household debt, 2020 to 2024</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{STATE} debt per person</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">County income comes from <a href="{fred_c}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column comes from the <a href="https://www.newyorkfed.org/microeconomics/databank.html">New York Fed Consumer Credit Panel</a>. {c['growth']} <a href="{dp04}">{c['housing']}</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. {STATE} sets a flat ceiling instead of an income test, so the amount does not change with local earnings. The last column is a calculation, not a published figure: monthly county income after the standard housing share. It describes a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>These are the small-loan rules for all of {STATE}, including {city}. In plain terms: what licensed lenders offer instead of payday loans, what they may charge, and who to call if something goes wrong. Full detail is on the <a href="{SLC}">Financial Institutions Division small loan page</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
      <tr><td>Payday loans</td><td>Not among the products licensed small loan companies offer; they make installment, tax refund and small business loans</td></tr>
      <tr><td>Small loan license</td><td>Required for loans of $10,000 or less under the Small Loan Act, §58-15-1 and following; banks and credit unions are exempt</td></tr>
      <tr><td>Installment loans</td><td>At least four substantially equal payments, with at least 120 days to maturity</td></tr>
      <tr><td>Rate cap</td><td>36% NM-APR on loans above $500, for loans made since January 1, 2023</td></tr>
      <tr><td>Loans of $500 or less</td><td>The same cap plus a fee of up to 5% of principal, charged no more than once in 12 months</td></tr>
      <tr><td>NM-APR</td><td>Can include charges the federal APR leaves out, and both figures must be disclosed</td></tr>
      <tr><td>Posted rates and fees</td><td>Each licensed office and lender website must show the APR and a list of all fees</td></tr>
      <tr><td>Where to report it</td><td>The Financial Institutions Division, (505) 476-4885</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">The caps are ceilings, not prices. Ask for both APR figures and the total cost in dollars before you sign, and check them against what your budget can carry for every month of the term.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {city}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {city} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history rather than a credit score alone.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call the utility and ask about a payment plan and LIHEAP energy assistance for {county} households. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Check the license before anything else.</strong> Ask which state license the lender holds and confirm it with the regulator before you share your bank details.</li>
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Interest runs on the balance, and qualifying for more is not a reason to take more.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the payment schedule in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any small loan.</li>
      </ul>
      <p style="margin-bottom:0">To check a license or file a complaint, contact the <a href="{COMPLAINT}">New Mexico Financial Institutions Division</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{city} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>1F Cash Advance in Other {STATE} Cities</h2>
    <p style="max-width:760px">The same {STATE} rules apply statewide. See how they play out where you live:</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
"""
    a_s = base.rfind("<section", 0, base.find("Who wrote this")); a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e].replace("Houston County", county)
    assert "Dothan" not in authors and "Alabama" not in authors

    url = f"https://1firstcashadvance.org/{slug(city)}/"
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": url, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": "https://1firstcashadvance.org/loans-by-state/new-mexico/"}, {"@type": "ListItem", "position": 4, "name": city}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": {"@type": "Person", "name": "Latoria Williams"}, "editor": {"@type": "Person", "name": "Marsha Welch"}, "reviewedBy": {"@type": "Person", "name": "Michael Lefler"}, "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Payday loan alternative matching in {city}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{city}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    for c in CITIES:
        if only and c["city"] not in only:
            continue
        p = os.path.join(OUT, slug(c["city"]) + "-NEW.html")
        open(p, "w", encoding="utf-8").write(build(c))
        print("wrote", p)


if __name__ == "__main__":
    main()
