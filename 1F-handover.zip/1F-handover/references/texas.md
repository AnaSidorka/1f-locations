# Texas — verified figures and ready state blocks

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11): payday разрешён
и выдаётся. Модель своя: займ даёт независимый сторонний кредитор, а оформляет его
**credit access business (CAB)** — посредник с лицензией OCCC. Лицензируется посредник,
а не кредитор.

Regulator: **Office of Consumer Credit Commissioner (OCCC)** — https://occc.texas.gov/industry/cab/

## Verified legal figures

Все цитаты ниже открыты и прочитаны 16 сентября 2026. Статуты — через файловый сервер
Легислатуры (`statutes.capitol.texas.gov` отдаёт только JS-оболочку без текста):

- Finance Code ch. 393: https://tcss.legis.texas.gov/resources/FI/htm/FI.393.htm
- Finance Code ch. 302: https://tcss.legis.texas.gov/resources/FI/htm/FI.302.htm
- Форма раскрытия OCCC (payday, один платёж, ред. 2024): https://occc.texas.gov/wp-content/uploads/2025/12/cab-disclosure-payday-single-rev2024.pdf
- Жалоба в OCCC: https://occc.texas.gov/consumers/file-a-complaint/ (200)
- Поиск лицензии OCCC: https://alecs.occc.texas.gov/Generic/AdvanceSearch (200)

| Item | Verified value | Cite |
|---|---|---|
| Governing law | Credit Services Organizations, Finance Code ch. 393; CAB — subch. G | 393.601 |
| License | «must obtain a license under this subchapter for each location at which the organization operates as a credit access business» | 393.603 |
| CAB fee | **Потолка нет.** «A credit access business may assess fees for its services as agreed to between the parties» | 393.602(b) |
| Fee cap authority | «Nothing in Section 393.201(c) or Sections 393.601-393.628 grants authority to the finance commission or the Office of Consumer Credit Commissioner to establish a limit on the fees charged by a credit access business» | 393.622(c) |
| Lender interest | «The maximum rate or amount of interest is **10 percent a year** except as otherwise provided by law» | 302.001(b) |
| Loan amount | **Штатного потолка нет** — в ch. 393 его нет | — |
| Loan term | **Штатного максимума нет.** 180 дней в 393.201(b)(2) — срок услуг посредника, не срок займа | — |
| Average APR | **415%** — средний APR payday по форме раскрытия OCCC; **$34.14** комиссий и процентов на $100 за один месяц | форма OCCC, данные 2022 |
| Repayment pattern | «Of 10 people who get a new single-payment payday loan: 5 ¾ will pay the loan on time … 1 will renew 5 or more times or will never pay off the loan. This data is from 2022 reports to the OCCC» | форма OCCC |
| Disclosure | До оказания услуг посредник обязан выдать форму OCCC со сравнением стоимости и суммой комиссий при продлении на 2 недели, 1, 2 и 3 месяца | 393.223(a) |
| No criminal charges | «may not threaten or pursue criminal charges against a consumer related to a check or other debit authorization provided by the consumer as security for a transaction in the absence of forgery, fraud, theft, or other criminal conduct» | 393.201(c)(3) |
| Prepayment | Договор обязан содержать «a statement that there is no prepayment penalty» | 393.201(c)(1) |
| Refinancing notice | «Refinancing the loan rather than paying the debt in full when due will require the payment of additional charges.» Штатного лимита на число продлений нет | 393.222(a)(3) |
| Cutoff for Apply step 3 | **11:30 am** (полоса TX в P2-12) | CLAUDE.md |

### NOT verified — do not publish

- **Штатного extended payment plan для займов через CAB нет.** Не писать «ask for the
  payment plan» — поиск по ch. 393, 342, 392 и 7 TAC 83 subch. B его не нашёл.
- **«Payday loans in Texas are limited to 180 days»** — неверно, см. строку Loan term.
- **Штатный долларовый потолок** ($1,000, $920 и т. п.) — нет. $920 — потолок подглавы F
  главы 342 для regulated lenders, к займам через CAB не относится.
- **7-дневный минимум срока** (7 TAC §83.604) — только для лицензиатов главы 342, не для CAB.
- **«APR often exceeding 700%»** — так пишет внутренний гид 1F (см. ниже). Официальная
  средняя цифра OCCC — 415%. На странице использовать только 415%.
- 7 TAC 83 читался через зеркало Cornell LII (официальный портал TAC — JS без текста).
  Цифр из TAC на страницах нет, поэтому ссылок на LII тоже нет.

### Внутренний гид Техаса — расходится с регулятором
`https://1firstcashadvance.org/loans-by-state/payday-loans-texas/` отдаёт 200
(`/loans-by-state/texas/` → 301 на него). Гид печатает «APRs, often exceeding 700%»
и таблицу с «a lender fee of $18 per $100 plus a CAB service fee of $10 per $100» — это
противоречит модели CAB: проценты кредитора ограничены 10% в год (302.001(b)), комиссия
идёт посреднику (393.602(b)). **Ссылку на гид во вводном абзаце Law at a Glance ставить
можно как навигационную, но ни одну цифру из гида не переносить** (P0-4). О расхождении
сообщено владельцу 16 сентября 2026.

## Главные ловушки Техаса

1. **Городские ордонансы.** Лимиты по доходу, продлениям и платежам — это закон города,
   а не штата. У каждого города свой ордонанс (или его нет) — проверять **по тексту кодекса
   города** на каждой сборке, не переносить с другого города и не брать из модельного
   ордонанса Texas Municipal League.
2. **Сфера ордонанса.** Ордонанс Baytown регистрирует «each physically separate credit access
   business» и не говорит прямо, что распространяется на онлайн-займы от посредников
   за пределами города. Формулировка на странице: лимиты действуют для посредников,
   работающих в городе. Не писать, что любой заём жителя города ограничен 20% дохода.
3. **Кредитор ≠ лицензиат.** Лицензию OCCC проверяют у посредника (CAB), а не у кредитора.
4. **Счётчик цитирований гейта** видит `§`. В таблице закона не больше двух `§`; форма
   `Finance Code Chapter 393` ему невидима — лимит «минимум цитирования» держи сам.

## City ordinance — Baytown (verified)

Baytown Code of Ordinances, ch. 20, art. II «Credit Access Businesses», Ord. No. 12,550,
adopted May 22, 2014. Текст прочитан 16 сентября 2026 через API Municode:
https://api.municode.com/CodesContent?jobId=497872&nodeId=PTIICOOR_CH20BU_ARTIICRACBU&productId=10022 ·
публичная страница (JS): https://library.municode.com/tx/baytown/codes/code_of_ordinances?nodeId=PTIICOOR_CH20BU_ARTIICRACBU

| Item | Verified value | Sec. |
|---|---|---|
| Payday amount | «may not exceed **20 percent** of the consumer's gross monthly income» | 20-31(a) |
| Title loan amount | lesser of «Three percent of the consumer's gross annual income» or «Seventy percent of the retail value of the motor vehicle» | 20-31(b) |
| Income proof | «shall use a paycheck or other documentation establishing income» | 20-31(c) |
| Installments | «may not be payable in more than **four** installments», каждый гасит «at least 25 percent of the principal», рефинансировать нельзя | 20-31(d) |
| Single-payment renewals | «may not be refinanced or renewed more than **three** times», каждое продление гасит ≥ 25% исходной суммы | 20-31(e) |
| Re-borrowing | новый заём в течение 7 дней после погашения считается продлением | 20-31(f) |
| Registration | регистрация в городе для каждой физической точки | 20-25 |
| Language | договоры на английском и испанском на месте; неграмотному клиенту договор читается вслух | 20-32 |

Не опубликованы в кодексе три ордонанса (16,517 / 16,538 / 16,561); поиск по «credit access»
изменений не нашёл. Перепроверять при каждой сборке.

## OCCC data (для справки, на страницу не обязательно)

Annual CAB report CY2025 (https://occc.texas.gov/wp-content/uploads/2026/03/2025_Annual_State.pdf):
по штату single-payment payday — 46,129 заёмщиков, installment payday — 1,208,226.
Средних сумм и APR отчёт не печатает — не выводить их как цифры OCCC.
MSA-отчёт даёт строку «Houston - Sugar Land - Baytown» — это метро, не город (P0-2).
Эти файлы открывались проверяющим агентом, не лично — перед использованием открыть заново.

## Texas city parameters

| City | County | region label | primary ZIP | cutoff | ordinance |
|---|---|---|---|---|---|
| Baytown | Harris County | the east side of Greater Houston | — | 11:30 am | ch. 20 art. II, verified |
| Austin | Travis County | — | — | 11:30 am | ch. 4-12, verified 2026-09-17 (ред. 2020, строже: 25% от всей суммы долга) |
| Dallas | Dallas County | — | — | 11:30 am | ch. 50 art. XI есть; действующий текст (amlegal) не открылся — цифры не публиковать |
| San Antonio | Bexar County | — | — | 11:30 am | ch. 16 art. XVI, verified 2026-09-17 |

Baytown лежит в Harris и Chambers County; основная часть — Harris. Серии FRED: доход округа
`MHITX48201A052NCEN`, нагрузка `DP04ACS048201`, медиана штата `MHITX48000A052NCEN`.
ZIP Baytown: 77520, 77521, 77522 (абонентские ящики), 77523 (частично Chambers County / Mont Belvieu).
Соседи, чьи ZIP легко принять за Baytown: Highlands 77562, La Porte 77571, Mont Belvieu 77580.

## Ready state blocks (change only {{City}}/{{County}})

Строка ордонанса в таблице закона и в Products — **городская**: для города без ордонанса
замени её на строку штата («No state cap on the loan amount») и перепиши ¶1.

### Loan Products (TX) — exactly 2 cards
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A small loan against your next paycheck, arranged by a licensed credit access business and funded by a separate lender. You repay it on payday or in a few set payments. The business charges its own fee on top of the interest.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in scheduled payments, not all at once. It is unsecured and has a set end date. If you need a bigger amount or more time, this usually costs less than renewing a payday loan again and again.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
```

### Texas Law at a Glance — 8 rows, two § marks (as published on Baytown, 2026-09-16)
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>Texas Law at a Glance</h2>
    <p>These are the payday rules for all of Texas, plus the city ordinance that applies to credit access businesses operating in {{City}}. In plain terms: who makes the loan, what it can cost, and how far it can be renewed. Full legal detail is in the <a href="https://1firstcashadvance.org/loans-by-state/payday-loans-texas/">Texas state guide</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>Texas position</th></tr>
      <tr><td>Governing law</td><td>Finance Code Chapter 393: a credit access business licensed by the OCCC arranges the loan from a third-party lender</td></tr>
      <tr><td>Lender interest</td><td>Generally limited to 10% a year under §302.001</td></tr>
      <tr><td>Broker fee</td><td>Set by agreement with you, with no state cap</td></tr>
      <tr><td>Rate</td><td>415% average APR on a payday loan, per the state disclosure form (2022 data)</td></tr>
      <tr><td>Loan amount</td><td>No state cap, but the {{City}} ordinance limits businesses in the city to 20% of gross monthly income</td></tr>
      <tr><td>Renewals</td><td>State law sets no limit. In {{City}} a single-payment loan can be renewed three times, each paying down at least a quarter of the principal</td></tr>
      <tr><td>Installments</td><td>In {{City}} no more than four, each repaying at least a quarter of the principal</td></tr>
      <tr><td>Cost disclosure</td><td>Before the deal, the business must give you the state form comparing its cost with other credit, under §393.223</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example: the state disclosure form puts average fees and interest on a payday loan at $34.14 per $100 borrowed over one month, based on 2022 reports. It is a statewide average, and your own quote can differ. To check a license or file a complaint, contact the <a href="https://occc.texas.gov/consumers/file-a-complaint/">Office of Consumer Credit Commissioner</a>.</p>
  </div>
</section>
```

Строки Loan amount / Renewals / Installments — **ордонанс Baytown**. Для другого города проверить его кодекс
и переписать эти три строки (или заменить на строки штата). Запрет угроз уголовным делом (§393.201(c)(3))
ушёл из таблицы в стат-карточку 6, чтобы тема не звучала трижды.

Бюджет: `20%` и `415%` — Can-You-Get ¶1 + таблица = 2/2, в карточки не идут. `10%` — 1/2.
`$34.14` — 1/2. `§` — 2/2, запас 0.

### Other Ways to Cover an Emergency (TX)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below a payday loan.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call a {{County}} community action agency. Ask about energy bill assistance and a payment arrangement. That is assistance, not a loan. Call before a disconnection.</p></div>
    </div>
  </div>
</section>
```

### Borrow Carefully (TX) — 4 universal bullets, no $ figure, no payment plan claim
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Qualifying for more is not a reason to take more, and every extra dollar raises what you owe back.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you cannot pay on time, talk to the lender before the due date rather than taking another loan.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a credit access business license, use the <a href="https://alecs.occc.texas.gov/Generic/AdvanceSearch">OCCC license search</a> or call the OCCC consumer helpline; you can also contact the federal CFPB.</p>
    </div>
  </div>
</section>
```

## Verified data — Harris County (pulled 2026-09-16)

Доход (SAIPE, `MHITX48201A052NCEN`): 2020 $61,906 · 2021 $63,539 · 2022 $68,748 · 2023 $72,348 · **2024 $74,682**
(рос каждый год, +20.6%). Медиана Техаса 2024 `MHITX48000A052NCEN` — $79,723 → разрыв **$5,041 below**.
Медиана США 2024 `MHIUS00000A052NCEN` — $81,604. Перегружены жильём (`DP04ACS048201`, 2024): 37.2%.
Долг на душу, Техас, NY Fed (релиз февраль 2026, лист `total`, Q4): 2020 $46,840 · 2021 $49,720 · 2022 $54,290 ·
2023 $56,560 · 2024 $57,890 (+23.6%). В файле уже есть Q4 2025 — $60,020, но SAIPE заканчивается на 2024.
Chambers County (восточная часть Baytown): 2024 $106,175 — на странице не используется.

## Distinct local angles (занятые ракурсы)
- Baytown — ¶2: правило 7 дней ордонанса (новый заём в течение недели после погашения = продление).
  FAQ: договоры на испанском (§20-32), отмена договора CAB до полуночи третьего дня (§393.202),
  досрочное погашение и способ начисления комиссии (§393.602(b)).

**Перед блоком офисов любого техасского города:** каждый адрес сверить с реестром лицензий OCCC
(https://alecs.occc.texas.gov/Generic/AdvanceSearch) — §393.603 требует лицензию на каждую точку.
Finder (обновлено 2025-09-09) приводит отзывы, что по адресам 1F «there was no store».


## Ордонансы Austin, San Antonio, Dallas — проверено 17 сентября 2026 (сборка 1F, builds/2026-09-17-tx)

Тексты — через API Municode (`api.municode.com/CodesContent`), публичные страницы открываются (200).

**Austin — City Code ch. 4-12** (Ord. 20200521-028, 20200730-004; Supplement 174):
https://library.municode.com/tx/austin/codes/code_of_ordinances?nodeId=TIT4BUREPERE_CH4-12RECRSEORCRACBU
- §4-12-22(A) аванс ≤ **20%** gross monthly income; (B) title loan — меньшее из 3% годового дохода и 70% стоимости авто;
  (C) доход — paycheck, bank statement, W-2, tax return, письмо работодателя и т. п.;
- (D) **четыре или меньше платежей**, каждый уменьшает на **25% всю сумму долга, включая проценты и сборы CAB**
  (у Baytown и San Antonio — 25% **principal**);
- (E)(F) продлевать можно только заём с одним платежом, **не больше трёх раз**, каждое продление гасит ≥ 25% всей суммы;
- (G) новый заём в течение **7 business days** после погашения — продление;
- §4-12-23 список некоммерческих организаций каждому клиенту + постер в зале;
- §4-12-24 для займов CSO, не являющихся payday/title: сборы ≤ 0.1% в день от остатка;
- §4-12-26 нарушение — Class C misdemeanor, штраф до $500 за каждую сделку.

**San Antonio — City Code ch. 16, art. XVI** (Ord. 2012-09-20-0739; Supplement 146):
https://library.municode.com/tx/san_antonio/codes/code_of_ordinances?nodeId=PTIICO_CH16LIBURE_ARTXVICRACBU
- §16-900.10 — как Baytown: 20% GMI; title 3%/70%; installments ≤ 4, каждый ≥ 25% principal, без рефинанса;
  single payment ≤ 3 продлений, каждое ≥ 25% principal; 7 дней;
- §16-900.11 договор **на языке, который выбрал клиент**; на месте — английская и испанская версии; неграмотному читают вслух.

**Dallas — City Code ch. 50, art. XI.** Страница города
https://dallascityhall.com/departments/codecompliance/Pages/payday_lending_cab-archive.aspx — **архив** с §50-151.3
(Ord. 28287, 2012). Действующий кодекс (codelibrary.amlegal.com) закрыт Cloudflare; по заголовкам поиска статья
переименована («Credit Services Organizations and Credit Access Businesses», §50-151.4) — редакцию, вероятно, меняли.
**На странице Dallas цифры ордонанса не публикуются**, только факт, что город регулирует CAB в своём кодексе.

### Проверено лично 17 сентября 2026
FI.393 (393.201(c)(1)–(3), 393.202, 393.222, 393.602(b), 393.603, 393.622(c)), FI.302 (302.001(b)),
форма OCCC (415%, $34.14, данные 2022) — цитаты совпали.

### Tucson/Austin — адреса вне городской черты (для будущих сборок)
Austin `3101 Bee Caves Rd` 78746 — геокодер Census: **Rollingwood city**. Ордонанс Austin на эту точку не распространяется.
