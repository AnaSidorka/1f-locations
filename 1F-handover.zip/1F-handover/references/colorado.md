# Colorado — verified figures and state notes

Colorado is **not** a working single-payment payday state. The Deferred Deposit Loan Act still
stands, but Proposition 111 (approved November 2018, in force **February 1, 2019**) capped the
finance charge at **36% APR**, and licensed lenders stopped making these loans altogether.
The small-dollar product people can actually get is the **alternative charge loan** under
C.R.S. 5-2-214. Write the blocks to that reality, not to the Louisiana payday shape.

**H1-режим: вторая форма** — `Short-term loans in {{City}}, {{State}}` (P3-11). Payday здесь
не запрещён, но лицензиаты его не выдают, а законная замена существует.

Regulator: **Administrator of the Uniform Consumer Credit Code**, Colorado Department of Law
(Attorney General) — https://coag.gov/office-sections/consumer-protection/consumer-credit-unit/uniform-consumer-credit-code/
Licensing line (720) 508-6010 · uccc@coag.gov

## Verified figures — deferred deposit loan (the "payday" product)

Source: Colorado Revised Statutes Title 5 Article 3.1, statutory text read 2026-09-10.

| Item | Verified value | Cite |
|---|---|---|
| Governing law | Deferred Deposit Loan Act, C.R.S. 5-3.1-101 to 5-3.1-123 | — |
| Licence | Required; supervised by the UCCC Administrator | 5-3.1-116 |
| Maximum loan | **$500** at any one time from any one lender | 5-3.1-106 |
| Finance charge | **Must not exceed an annual percentage rate of thirty-six percent** | 5-3.1-105 |
| Minimum term | **Six months** from the loan transaction date | 5-3.1-103 |
| Prepayment | Must be accepted, no penalty; prorated refund of the finance charge | 5-3.1-103, 5-3.1-105 |
| Renewal | **Not more than once**, then payable in full | 5-3.1-108 |
| Multiple loans | Total financed ≤ $500; at least a **thirty-day** wait between loans | 5-3.1-106 |
| Returned instrument | **One** charge per loan, **not to exceed $25** | 5-3.1-112 |
| Right to rescind | By **5 p.m. the next business day** after the transaction | 5-3.1-106 |
| Other charges | Only those expressly authorised by the article | 5-3.1-105 |

## Verified figures — alternative charge loan (what lenders actually make)

Source: C.R.S. 5-2-214, statutory text read 2026-09-10. Figures below are the version
**in force from January 1, 2024**; the pre-2024 numbers are historical.

| Item | Verified value (from Jan 1 2024) | Historical (to Dec 31 2023) |
|---|---|---|
| Maximum loan | not more than **one thousand dollars** | same |
| Acquisition charge | not to exceed **8%** of the amount financed | 10% original / 7.5% refinanced |
| Monthly maintenance fee | **$8.50 – $17.50** by loan size | $12.50 – $20.00 |
| Minimum term | **six months** | ninety days |
| Maximum term | **twelve months** | same |
| Refinancing | not more than **once** in one year | not more than three times in one year |

## Market reality — publishable, and important

From the Attorney General's own consumer lending study (January 2023), quoted exactly:

> "Beginning in February 2019, when the 36% annual percentage-rate cap passed by Colorado
> voters in 2018 took effect with respect to deferred deposit loans, lenders ceased offering
> such loans. Some of those lenders switched to making alternative charge loans, which permit
> an annual percentage rate above 36%."

> "In 2018, Colorado voters overwhelmingly approved Proposition 111 (by a vote of 77% to 23%),
> which imposed a 36% annual percentage-rate cap on deferred deposit loans."

Source: https://coag.gov/app/uploads/2023/01/Consumer-lending-study-Jan.-2023.pdf

## NOT verified — do not publish

- **"45% per year interest on alternative charge loans."** The 2023 AG study describes the
  pre-2024 structure as an acquisition charge plus "an interest rate of 45% per year" plus
  monthly maintenance fees, but the statute text as read on 2026-09-10 lists only the
  acquisition charge and the monthly maintenance fee. Do not publish an interest figure for
  alternative charge loans until the discrepancy is resolved against the current statute.
- **Average or typical APR figures** (186% before Prop 111, 339% before the 2010 law). These
  are study figures, useful as background, not regulator rate limits. Not for a rate table.
- **Any worked dollar example.** Alternative charge loans price from an acquisition charge plus
  a monthly fee over six to twelve months; a representative example needs a fixed principal,
  term and fee set that is not yet settled. Follow the Ohio decision: no representative example
  unless the user asks for one.
- **Number of licensed locations today.** The study counts 2021 licences; that is stale.

## The trap to avoid

**Do not tell a Colorado reader that a 36% cap makes payday loans cheap here.** The honest
statement is that the cap ended the product: no licensee makes deferred deposit loans, and the
loan actually on offer is the alternative charge loan, whose all-in cost runs above 36% APR
because the acquisition charge and the monthly maintenance fee sit outside the interest rate.
Never write "capped at 36% APR" as a description of what a borrower will be charged.

## Gate constraint specific to Colorado

The citation counter in `scripts/validate.py` matches `C.R.S.` literally and allows **at most
two marks in the whole Law at a Glance section** (§5b). Ohio escapes this because `ORC` is
invisible to the regex; Colorado does not. **Use `C.R.S.` exactly once**, in the governing-law
row, and keep every other row citation-free. Section numbers without the `C.R.S.` prefix
(for example `5-3.1-106`) do not trip the counter.

## Colorado city parameters

| City | County | region label | primary ZIP | cutoff |
|---|---|---|---|---|
| Aurora | Arapahoe County (city also spans Adams and Douglas) | the Denver metro area | 80012 | 10:30 am |
| Colorado Springs | El Paso County | the Pikes Peak region | 80903 | 10:30 am |
| Grand Junction | Mesa County | the Western Slope | 81501 | 10:30 am |
| Pueblo | Pueblo County | southern Colorado | 81004 | 10:30 am |
| Littleton | Arapahoe County (city also spans Jefferson and Douglas) | the south Denver suburbs | 80128 | 10:30 am |

Two open items that only the user can settle:
1. **`{{CUTOFF}}` for Colorado.** The band table in page-spec §2 lists OH/NC/SC/RI/VA,
   LA/TN/AL/IL/TX and CA. Colorado is absent. Either assign a value in `H:MM am` form or
   confirm there is no same-day funding, in which case the cutoff leaves Apply step 3.
2. **Aurora's county for the §5c income series.** Aurora spans Arapahoe, Adams and Douglas
   counties. §5c needs one county series with a literal geo-label; picking Arapahoe (where most
   of the city sits) is defensible but it is an editorial choice, not a fact.

Note: Grand Junction sits in **Mesa County, Colorado** — unrelated to Mesa, Arizona.

## Ready state blocks (change only {{City}}/{{County}})

### Loan Products (CO) — exactly 2 cards
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Short-Term Loans</h3>
        <p>Colorado's regulated small-dollar loan. It is repaid in installments over at least six months rather than in one payment on your next check, and the schedule is fixed when you sign. Ask for the annual percentage rate and the full payment schedule before you agree to it.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a>
      </div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>For a bigger need, an installment loan spreads repayment over a longer schedule with fixed payments. Ask for the annual percentage rate and the total cost of credit in dollars, and compare that figure across offers. For a large repair bill, this is usually the better fit.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a>
      </div>
    </div>
  </div>
</section>
```

### Colorado Law at a Glance — 8 rows, one C.R.S. mark, one fine paragraph
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>Colorado Law at a Glance</h2>
    <p>These are the small-dollar lending rules for all of Colorado, including {{City}}. Full legal detail is in the <a href="https://1firstcashadvance.org/loans-by-state/payday-loans-colorado/">Colorado state guide</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>Colorado position</th></tr>
      <tr><td>Governing law</td><td>Deferred Deposit Loan Act, C.R.S. 5-3.1-101 and following, overseen by the Administrator of the Uniform Consumer Credit Code</td></tr>
      <tr><td>Single-payment payday loans</td><td>Finance charge capped at 36% a year since February 2019, after which licensed lenders stopped offering them</td></tr>
      <tr><td>What is available instead</td><td>A small installment loan of up to $1,000 under the Uniform Consumer Credit Code</td></tr>
      <tr><td>Term</td><td>At least six months and no more than twelve, repaid on a fixed schedule</td></tr>
      <tr><td>Charges</td><td>An acquisition charge of up to 8% of the amount financed, plus a monthly maintenance fee set by loan size</td></tr>
      <tr><td>Refinancing</td><td>Not more than once in a year</td></tr>
      <tr><td>Returned payment</td><td>One charge per loan, up to $25</td></tr>
      <tr><td>Cancellation</td><td>A deferred deposit loan may be cancelled by 5 p.m. of the next business day</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">These are the legal ceilings, not quoted offers. Your own rate, fee and payment schedule come from the lender and appear in the loan contract.</p>
  </div>
</section>
```

### Other Ways to Cover an Emergency (CO)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is usually below a short-term loan.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call a {{County}} community action agency. Ask about LEAP energy assistance and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
```

### Borrow Carefully (CO) — 4 universal bullets, no $ figure
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. The cost rises with the amount, and qualifying for more is not a reason to take more.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the payment schedule in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment dates.</strong> Line the payments up with your pay schedule and keep each one inside what remains after fixed bills. If money gets tight, call the lender before a payment is missed.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any short-term loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="https://coag.gov/office-sections/consumer-protection/consumer-credit-unit/uniform-consumer-credit-code/">Colorado Administrator of the Uniform Consumer Credit Code</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```

## Verified income series (SAIPE via FRED, read 2026-09-10)

Colorado state median household income: 2020 $77,688 · 2021 $82,228 · 2022 $89,096 · 2023 $92,790 · **2024 $96,871** (series MHICO08000A052NCEN).

| County (city) | 2020 | 2021 | 2022 | 2023 | 2024 | growth | vs state 2024 |
|---|---|---|---|---|---|---|---|
| Arapahoe (Aurora) | 82,381 | 84,308 | 93,525 | 97,560 | **103,442** | +25.6% | +$6,571 |
| El Paso (Colorado Springs) | 72,459 | 79,094 | 82,248 | 88,794 | **90,778** | +25.3% | −$6,093 |
| Mesa (Grand Junction) | 64,141 | 63,531 | 69,578 | 66,339 | **73,997** | +15.4% | −$22,874 |
| Pueblo (Pueblo) | 50,885 | 56,311 | 58,314 | 63,801 | **62,186** | +22.2% | −$34,685 |

Series: MHICO08005A052NCEN (Arapahoe), MHICO08041A052NCEN (El Paso), MHICO08077A052NCEN (Mesa),
MHICO08101A052NCEN (Pueblo). Titles confirmed at fred.stlouisfed.org.
2024 is the record high of every series **except Pueblo**, where the record is 2023 ($63,801)
and 2024 fell back to $62,186. Never write "a record high" on the Pueblo page.

## Distinct local angles used (keep new cities distinct from these)
- Aurora — округ держится выше медианы штата во все годы ряда; доход рос каждый год.

**Формулируй привязки без ссылок на другие страницы набора (P4-8).** Список ниже — внутренняя заметка о том, какой ракурс уже занят. В тексте страницы сравнение идёт только со штатом, со своим округом и с собственной историей города по годам.
- Colorado Springs — grew at almost the same pace as Aurora but stayed below the state median throughout.
- Grand Junction — the slowest growth of the set and a series that fell in two of five years;
  its gap to the state widened from about $13,500 in 2020 to $22,874 in 2024.
- Pueblo — the widest gap below the state median in the set, and the only county whose most
  recent year fell rather than set a record.

- Littleton — тот же округ Arapahoe; страница держится на том, что окружная медиана ничего
  не говорит об отдельном бюджете, а сам город лежит в трёх округах. В тексте Аврора не упоминается.

**Занятые округа.** Arapahoe несёт две страницы — Аврору и Littleton. Числа в их блоках
статистики совпадают, потому что это один и тот же округ; различаются подписи карточек,
закрывающий абзац, ¶2 и FAQ. Совпадение блока — около 87%. Спецификация случай «два города
набора в одном округе» не описывает: если такое дублирование неприемлемо, нужно правило,
а не переназначение округа — Littleton действительно окружной центр Arapahoe.

## Долг и жилищная нагрузка (для таблицы §5c, тянуть заново на каждой сборке)

Долг на душу по Колорадо, NY Fed Consumer Credit Panel, Q4:
2020 $76,340 · 2021 $82,100 · 2022 $89,170 · 2023 $90,760 · **2024 $90,540**
Файл: `newyorkfed.org/medialibrary/interactives/householdcredit/data/xls/area_report_by_year.xlsx`, лист `total`.

Доля домохозяйств, отдающих 30%+ дохода на жильё (FRED, ACS 5-year, 2024):
Arapahoe 36.0% (`DP04ACS008005`) · El Paso 34.6% (`DP04ACS008041`) · Mesa 31.5% (`DP04ACS008077`) · Pueblo 33.8% (`DP04ACS008101`)
