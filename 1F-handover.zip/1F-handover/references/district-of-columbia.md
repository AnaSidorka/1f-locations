# District of Columbia — verified figures and ready state blocks

**H1-режим: третья форма** — `Payday loan alternatives in {{City}}, {{State}}` (P3-11), то есть
`Payday loan alternatives in Washington, District of Columbia`. Заголовок офисов —
`Where to get payday loan alternatives in Washington` (P3-5). Can-You-Get открывается словом **No**.
Отсечка шага 3 — **12:30 pm** (восточный пояс).

**Особенность DC.** Город, округ и «штат» — одна и та же единица, ряд SAIPE по округу и по «штату»
совпадает. Поэтому карточка «разрыв с медианой штата» заменена на **рост медианы с 2020 года**
(решение владельца 21 сентября 2026): число берётся из той же таблицы на странице, форма карточки
сохраняется, P4-9 не нарушается.

## Источники — открыты 21 сентября 2026

| Документ | URL |
|---|---|
| D.C. Code § 28-3301 Rate of interest expressed in contract | https://code.dccouncil.gov/us/dc/council/code/sections/28-3301 |
| D.C. Code § 26-319 Limitations on business (Check Cashers) | https://code.dccouncil.gov/us/dc/council/code/sections/26-319 |
| D.C. Code § 26-905 Maximum rate of interest (Money Lenders) | https://code.dccouncil.gov/us/dc/council/code/sections/26-905 |
| D.C. Code § 26-907 Violations | https://code.dccouncil.gov/us/dc/council/code/sections/26-907 |
| D.C. Code § 28-3312 Unlawful practices | https://code.dccouncil.gov/us/dc/council/code/sections/28-3312 |
| D.C. Code § 28-3313 Penalties | https://code.dccouncil.gov/us/dc/council/code/sections/28-3313 |
| DISB, проверка лицензии | https://disb.dc.gov/service/verify-financial-institution-or-representative-licensed-disb |
| DISB, жалобы | https://disb.dc.gov/complaints |

## Verified figures

| Item | Verified value | Cite |
|---|---|---|
| Потолок ставки | договорная ставка не выше **24% годовых** | §28-3301(a) |
| Чек с будущей датой | лицензиат-check casher **не вправе** обналичивать чек с будущей датой или выдавать под него деньги — механика payday закрыта | §26-319(b) |
| Money lender: ставка | не выше законной ставки по гл. 33 Title 28, и эта ставка **покрывает все сборы, расходы и услуги** (кроме издержек при обращении взыскания) | §26-905 |
| Вычет процентов вперёд | проценты **нельзя удерживать из основной суммы** при выдаче | §26-905 |
| Документы заёмщику | письменная выписка при выдаче (сумма, даты выдачи и погашения, стороны, размер процентов) и расписка за **каждый** платёж | §26-905 |
| Размер займа | по этой главе **не больше $200** одному лицу | §26-905 |
| Превышение ставки | кредитор **теряет все проценты** и дополнительно выплачивает заёмщику **четверть основной суммы**, вычитаемую из долга | §26-905 |
| Нарушение главы 26-9 | штраф **$300**, арест от 30 до 90 дней, возможна реституция | §26-907 |
| Запрещённые практики | искажение и умолчание существенных фактов, реклама услуг без намерения их оказать, акселерация долга не по причине нарушения заёмщиком, отказ заёмщика от прав по главе | §28-3312 |
| Умышленное нарушение гл. 33 | штраф по §22-3571.01 или до **1 года** лишения свободы | §28-3313 |
| Кто проверяет лицензию | **DISB** — Department of Insurance, Securities and Banking; у DISB же подаётся жалоба | DISB |

### NOT verified — do not publish
- Слова «payday lending banned in 2007» и ссылки на D.C. Law 16-0281: сам закон не читался,
  в §26-319 виден только результат — отменённая часть (c) и действующий запрет на postdated check.
- Исключения §26-912 и правила отдельных видов кредиторов — не читались.
- Любые APR и статистика рынка: DISB их не публикует на открытых страницах.

## District of Columbia city parameters

| City | Unit | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Washington | District of Columbia | MHIDC11001A052NCEN | DP04ACS011001 | 12:30 pm |

Ряд «штата» (`MHIDC11000A052NCEN`) совпадает с окружным. Долг на душу: NY Fed, лист `total`, строка `DC`.

## Ready state blocks

Форма — как у New Mexico и Arizona (третья форма): Products = Installment Loans + Personal Loans,
заголовок офисов со словом alternatives. Блок 14 — форма одиночного города:
`1F Cash Advance Across the District of Columbia` + ссылка на страницу штата.

### Шесть стат-карточек — правовые (1–3, 6)
| # | `.num` | Источник |
|---|---|---|
| 1 | `Rate ceiling` | §28-3301 |
| 2 | `Fees inside the rate` | §26-905 |
| 3 | `No postdated checks` | §26-319 |
| 6 | `Overcharge forfeits` | §26-905 |

Borrow Carefully: DISB назван со ссылкой на проверку лицензии; жалобы — DISB или федеральный CFPB.

## Distinct local angles
- Washington / District of Columbia — доход снизился в 2021, затем рос три года подряд;
  в 2024 он на **$17,332** выше уровня 2020 года; жилищная нагрузка 36.1%;
  долг на душу снижался в 2023 и 2024 после пика 2022 года.
