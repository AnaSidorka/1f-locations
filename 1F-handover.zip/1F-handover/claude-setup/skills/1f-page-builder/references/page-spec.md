# 1F City Page — Full Specification

Table of contents:
1. Assembly order
2. Global blocks (locked wording)
3. Office block
4. Authors block
5. Unique blocks (per city)
6. Tone rules
7. Number & theme rules
8. Locked wording — the copywriter's final corrections
9. Verification

---

## 1. Assembly order (top to bottom)

1. topbar (NMLS)
2. Hero *(global, locked)*
3. How to Apply *(global)*
4. Loan Products *(state)*
5. What You Need to Qualify *(global)*
6. How 1F Works *(global)*
7. **Office block** *(per city, from user addresses)* — right after How 1F Works
8. Can You Get a Payday Loan in {City}? *(unique)*
9. Borrowing and Debt in {City} — statistics *(unique)*
10. Louisiana/State Law at a Glance *(state)*
11. Other Ways to Cover an Emergency in {City} *(state)*
12. Borrow Carefully *(state)*
13. {City} Borrowers Ask — FAQ *(unique)*
14. 1F Cash Advance in Other {State} Cities — links *(unique)*
15. About the Authors *(global, parish swapped)*

Section zebra: `hero`, then strictly alternating `section` / `section alt`. Recompute after every insert.

The ZIP is **removed from the Apply H2** ("How to Apply from {City}, {ST}" — no ZIP). ZIP appears only inside office addresses.

---

## 2. Global blocks (locked wording)

Take these verbatim; change only {City}/{State}/{ST}. Full HTML is in `assets/page-template.html`. Key wording that must not drift:

**Hero** — LOCKED, never rewrite:
- H1: `Payday Loans in {City}, {State}`
- sub: `Apply online in minutes, from your phone.`
- ticks: `5-minute request, fast lender decision` / `Soft credit check to prequalify` / `Same-day funding available on weekday approvals`
- hero-card "Check your rate" + consent line
- hero-foot: two trust badges (Why Trust Us? / Fact-Checked) + byline-mini (Updated date · Written by Latoria Williams | Edited by Marsha Welch | Reviewed by Michael Lefler)

**How to Apply** — 3 steps: "Fill out the online form" (open 24/7, ~5 min) · "Get a decision" (pass to lenders licensed in {State}, within the hour) · "Receive the funds" (same-day cutoff {cutoff} local time*) + fine print. Cutoff by state: OH/NC/SC/RI/VA = 12:30 pm · LA/TN/AL/IL/TX = 11:30 am · CA = 9:30 am.

**What You Need to Qualify** — plain list, NO lead-in sentence: photo ID · SSN · active checking account with routing number · recent pay stub or proof of income · proof of {State} address · working phone and email · age 18+.

**How 1F Works** — first sentence exact: `1F Cash Advance is a loan connector and financial marketplace, not a direct lender.` Then: we do not fund/approve/set rates; we match to lenders licensed in {State} and allowed to operate there. Three bullets — see Locked wording §8 for the exact "(not 1F Cash Advance)" phrasing in bullet 3.

---

## 3. Office block

Inserted after How 1F Works. One card per address. Opening is always 8:00 AM; closing time per the user's data.

```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>Our {City} Offices</h2>
    <p style="max-width:760px">Prefer to apply in person or ask a question face to face? These 1F Cash Advance locations serve {City}.</p>
    <div class="office-grid">
      <div class="office-card">
        <p class="office-addr">{street}<br>{City}, {ST} {zip}</p>
        <p class="office-hours">Open today 8:00 AM &ndash; {close}</p>
      </div>
      <!-- repeat per address -->
    </div>
  </div>
</section>
```
Use singular "Office" and "This 1F Cash Advance location serves" when there is exactly one address. No schema on this block (FinancialService schema stays on the Boulder HQ). CSS for `.office-grid`/`.office-card`/`.office-addr`/`.office-hours` is in the template shell; add it before `</style>` if missing.

---

## 4. Authors block

Always include, at the end (after city links). Three cards: Latoria Williams (CEO, bio + creds + profile link), Marsha Welch (Edited by), Michael Lefler (Reviewed by — his line names the city's county/parish income series, so swap {Parish}). Full HTML in `assets/page-template.html`.

---

## 5. Unique blocks (written per city — never templated)

**Can You Get a Payday Loan in {City}?** — concentrated answer.
- First paragraph: direct "Yes"/"No" + the base numbers (max amount, term, fee %, APR) — worded DIFFERENTLY from sibling cities (same facts, different sentence shape, so pages are not twins).
- Second paragraph: ONE local angle in 1–2 sentences (the city's distinctive economic fact), then a light, helpful nudge (borrow what fits the gap; verify the lender with the regulator). No water, no "City's angle is…" template, no prompt-echo "Yes, as a regulated…".

**Borrowing and Debt in {City} — statistics.**
- 3 stat-cards + a small income table (city / county / state) from verified Census/official data.
- One neutral `src-note` line naming the source and one plain contextual fact. **No water paragraph after it.**

**FAQ — {City} Borrowers Ask.**
- 3 questions, each USEFUL on its own and DISTINCT from sibling cities (do not reuse the same questions across cities). Good angles: what if I can't repay on time (extended payment plan), how to verify a lender's license, whether to borrow the full max, military/student/storm specifics where relevant.
- Short, real answers (2–3 sentences) that actually answer the question.
- Page copy and FAQPage schema kept in exact sync.

**City links** — list of the other cities in the state that exist in the set (no self-link).

---

## 6. Tone rules

Helpful and factual, never alarming or lecturing. 1F helps people get a loan.
- BANNED: "lands hardest", "bites hardest", "hurts most", "makes the due date risky", blunt "No."/"Rarely." openers to advice questions, "no cushion", "little financial slack", "honest reading", "awkward moment".
- PREFER: "it helps to match the loan to a payday you can count on", "borrowing what fits the gap keeps the fee down", "it can work if the timing fits".
- Keep the connector/quality positioning (trusted help, licensed & vetted lenders) in Hero and How 1F Works.

---

## 7. Number & theme rules

- Every dollar figure and every percentage: **≤2 occurrences** on the page. Canonical homes = Can-You-Get intro + Law table. Remove from stat-card labels and FAQ (rephrase to words like "a set percentage", "Max loan", "Percent fee").
- Every theme/argument explained **≤2 times**.
- **No water blocks** after statistics or after the Law table / representative example. Only the table, its disclaimers, and at most a functional link.
- After any deletion, re-scan — removing a paragraph can push a term or number above 2 elsewhere.
- Watch for **accidental duplicated phrases** from find-replace (e.g. "the same statewide, the same statewide"). Always re-read edited FAQ answers.

---

## 8. Locked wording — the copywriter's final corrections

These are the color-coded final versions from the approved template. Apply exactly; earlier drafts had different wording.

- **How 1F Works, bullet 3:** `<strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.` — the "(not 1F Cash Advance)" is required (was "that lender, not 1F,").
- **How 1F Works, bullet 2:** `<strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {State}, not to a single desk.`
- **Other Ways — H2:** `Other Ways to Cover an Emergency in {City}` (NOT "Cover a Shortfall").
- **Other Ways — credit union card heading:** `Credit union Payday Alternative Loans` (NOT "Credit union small dollar loans"). Body: `Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {City} area.`
- **Products / Payday (LA):** `A small loan against your next paycheck. You get cash now and pay it all back in one payment on payday, within 30 days under Louisiana law. The fee is a percent of the loan.`
- **Products / Installment (LA):** `A larger loan you pay back in monthly payments, not all at once. It is unsecured and has a set end date. If you need a bigger amount or more time, this is often cheaper than a payday loan.`

Note on the representative example: the approved template still shows the old $117/$121 wording, but the max rose to $740, so the correct fee is ≈ $124. Use the updated `Representative example: a top-end payday loan carries a finance charge of about $124, spread across a 14-day term. These are illustrative figures at the current limits, not quoted offers.` and flag the discrepancy to the user (factual accuracy on a YMYL page beats matching a stale template line).

---

## 9. Verification

Run `references/checklist.md` before presenting every page.
