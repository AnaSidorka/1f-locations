# Indiana — verified figures and state notes

Индиана — рабочий payday-штат. Продукт называется **small loan** и живёт в главе
IC 24-4.5-7 (часть Uniform Consumer Credit Code). Регулятор — **Indiana Department of
Financial Institutions (DFI)**, https://www.in.gov/dfi/, тел. (800) 382-4880.

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11).

## Verified figures

Источник: текст Indiana Code, глава 24-4.5-7, прочитан 2026-09-10 через зеркало статутов
(codes.findlaw.com, помечено «current as of January 01, 2026»). Собственную брошюру
регулятора прочитать не удалось: хост `in.gov` отдавал `ECONNREFUSED`, `iga.in.gov` —
пустую JS-оболочку, `law.justia.com` — 403.

| Item | Verified value | Cite |
|---|---|---|
| Governing law | Small loans, IC 24-4.5-7, часть Uniform Consumer Credit Code | — |
| Сколько можно занять | Новый заём вместе с комиссией плюс любые другие непогашенные small loans у любого кредитора — **не более 20% валового месячного дохода** | 24-4.5-7-402 |
| Установленный законом потолок | Совокупный остаток **$550** без учёта комиссий; порог **индексируется** по IC 24-4.5-1-106 от базы октября 2006 | 24-4.5-7-404, 24-4.5-7-201 |
| Минимальный срок | Заём **не может быть выдан на срок менее 14 дней** | 24-4.5-7-401 |
| Комиссия, ступени | **15%** от первых $250 · **13%** от части свыше $250 до $400 · **10%** от части свыше $400 до порога | 24-4.5-7-201 |
| Один заём за раз | У одного кредитора нельзя быть должником более чем по одному договору; выдавать нельзя, если у заёмщика уже два и более small loans у любых кредиторов | 24-4.5-7-404 |
| Расширенный план платежей | После первого займа и трёх подряд следующих кредитор **обязан предложить** план: **четыре равные части** минимум за **60 дней**, **без дополнительной платы**; отговаривать заёмщика от плана запрещено | 24-4.5-7-401 |
| После пятого подряд | После пятого подряд займа новый нельзя брать **семь дней** с даты полного погашения пятого | 24-4.5-7-401 |
| Санкция за нарушение | Нарушитель теряет право получать проценты и комиссии и отвечает статутными убытками **$2,000** за нарушение | 24-4.5-7-409 |

## NOT verified — do not publish

- **Текущая проиндексированная величина потолка (предположительно $825).** Закон задаёт
  **$550** и индексирует его; актуальное значение публикует DFI. Брошюру регулятора
  прочитать не удалось. **Не писать ни $550 как действующий максимум, ни $825 как
  проверенный.** На страницах используется формулировка «закон задаёт $550 и индексирует
  его», а связывающим пределом называется тест «20% месячного дохода».
  Это ровно та ошибка, что живёт в эталоне Ковингтона с его `$350 in statute`.
- **Период индексации.** Не установлен. По P0-3 его надо определить и перепроверять.
- **HB 1582 (2025)** — всплыл в выдаче рядом с главой о small loans, содержание не смотрел.
- Любой рабочий пример в долларах: ступенчатая комиссия и индексируемый порог требуют
  фиксированной суммы и срока, которые не согласованы. Представительного примера нет.

## Ловушка: Индиана расколота по часовым поясам

Правило полос отсечки в page-spec §2 задано **по штатам**, и на Индиане оно ломается: часть
округов живёт в Eastern Time, часть — в Central. Для наших трёх городов:

| Город | Округ | Часовой пояс | `{{CUTOFF}}` по правилу полос |
|---|---|---|---|
| Evansville | Vanderburgh | **Central** | `11:30 am` |
| Hammond | Lake | **Central** | `11:30 am` |
| Lafayette | Tippecanoe | **Eastern** | `12:30 pm` |

То есть внутри одного штата значение `{{CUTOFF}}` различается. Таблица §2, где полосы
перечислены списком штатов, этот случай не покрывает. Правильная формулировка правила —
«полоса определяется часовым поясом города», а не штата. Требует решения пользователя.

## Verified income series (SAIPE via FRED, read 2026-09-10)

Это единственная часть файла, проверенная у источника: заголовки всех серий сверены
на fred.stlouisfed.org.

Indiana state median household income: 2020 $60,794 · 2021 $62,723 · 2022 $66,768 ·
2023 $69,458 · **2024 $71,958** (series MHIIN18000A052NCEN).

| County (city) | 2020 | 2021 | 2022 | 2023 | 2024 | growth | vs state 2024 |
|---|---|---|---|---|---|---|---|
| Vanderburgh (Evansville) | 49,482 | 53,795 | 57,997 | 60,923 | **63,717** | +28.8% | −$8,241 |
| Lake (Hammond) | 59,158 | 61,468 | 66,169 | 69,182 | **73,228** | +23.8% | +$1,270 |
| Tippecanoe (Lafayette) | 52,806 | 55,192 | 56,088 | 61,681 | **68,036** | +28.8% | −$3,922 |

Series: MHIIN18163A052NCEN (Vanderburgh), MHIIN18089A052NCEN (Lake),
MHIIN18157A052NCEN (Tippecanoe). 2024 — рекорд каждой серии, все три росли каждый год.

Округа у трёх городов **разные**, так что проблемы одинакового блока статистики,
как у Aurora/Littleton и Las Vegas/Henderson, здесь не будет.

## Indiana city parameters

| City | County | region label | primary ZIP | cutoff |
|---|---|---|---|---|
| Evansville | Vanderburgh County | — предложить | — из адресов | `11:30 am` (Central) |
| Hammond | Lake County | — предложить | — из адресов | `11:30 am` (Central) |
| Lafayette | Tippecanoe County | — предложить | — из адресов | `12:30 pm` (Eastern) |
| Greenfield | Hancock County | — предложить | 46140 | `12:30 pm` (Eastern) |

Серии FRED для Greenfield: доход округа `MHIIN18059A052NCEN`, нагрузка `DP04ACS018059`.

## Distinct local angles (черновик, к использованию после проверки цифр)
- Evansville — округ держался ниже медианы штата во все годы ряда, при этом рос каждый год.

**Формулируй привязки без ссылок на другие страницы набора (P4-8).** Список ниже — внутренняя заметка о том, какой ракурс уже занят. В тексте страницы сравнение идёт только со штатом, со своим округом и с собственной историей города по годам.
- Hammond — округ большую часть ряда шёл под медианой штата и перешагнул её только в 2024,
  с узким запасом.
- Lafayette — округ вдвое сократил своё отставание от медианы штата с 2020 года; крупное
  студенческое население занижает записанную медиану.

## Ready state blocks (change only {{City}}/{{County}})

### Loan Products (IN) — exactly 2 cards
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>Indiana calls it a small loan. What you can borrow is measured against your monthly earnings rather than set at a flat figure, and the charge is worked out in tiers on the amount. Ask what the whole thing costs in dollars before you sign.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a>
      </div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan repaid on a schedule instead of in one payment, with a fixed end date. If you need more time or a bigger amount, this usually costs less than taking one short-term loan after another.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a>
      </div>
    </div>
  </div>
</section>
```

### Indiana Law at a Glance — 8 rows
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>Indiana Law at a Glance</h2>
    <p>These are the small loan rules for all of Indiana, including {{City}}. Full legal detail is in the <a href="https://1firstcashadvance.org/loans-by-state/in/">Indiana state guide</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>Indiana position</th></tr>
      <tr><td>Governing law</td><td>Small loans under the Uniform Consumer Credit Code, IC 24-4.5-7, overseen by the Department of Financial Institutions</td></tr>
      <tr><td>How much you can borrow</td><td>Your new loan with its charge, plus any other small loans you already owe, must stay under 20% of your monthly gross income</td></tr>
      <tr><td>Statutory ceiling</td><td>The code sets a combined balance limit of $550 and adjusts that figure upward for inflation</td></tr>
      <tr><td>Minimum term</td><td>A small loan may not be written for less than 14 days</td></tr>
      <tr><td>Finance charge</td><td>15% of the first $250, then 13% of the part above that up to $400, then 10% of the part above $400</td></tr>
      <tr><td>One at a time</td><td>You may hold only one agreement with the same lender, and no lender may add a third small loan on top of two you already owe</td></tr>
      <tr><td>Extended payment plan</td><td>After a first loan and three consecutive ones, the lender must offer four equal installments over at least sixty days at no extra cost</td></tr>
      <tr><td>After five in a row</td><td>Once a fifth consecutive loan is paid off, you must wait seven days before taking another</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">These are the legal limits, not quoted offers. The statutory ceiling is adjusted for inflation, so ask the lender for the figure in force and for your own cost in dollars.</p>
  </div>
</section>
```

### Other Ways to Cover an Emergency (IN)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below a payday loan.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call a {{County}} community action agency. Ask about the state Energy Assistance Program and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
```

### Borrow Carefully (IN) — 4 universal bullets, no $ figure
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Qualifying for more is not a reason to take more, and the charge climbs with the amount.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you are heading for a fourth loan in a row, ask about the payment plan instead.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any short-term loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="https://www.in.gov/dfi/">Indiana Department of Financial Institutions</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```

## Долг и жилищная нагрузка (для таблицы §5c, тянуть заново на каждой сборке)

Долг на душу по Индиане, NY Fed Consumer Credit Panel, Q4:
2020 $40,770 · 2021 $42,470 · 2022 $45,860 · 2023 $46,870 · **2024 $48,020**

Доля домохозяйств, отдающих 30%+ дохода на жильё (FRED, ACS 5-year, 2024):
Vanderburgh 29.2% (`DP04ACS018163`) · Lake 28.7% (`DP04ACS018089`) · Tippecanoe 35.2% (`DP04ACS018157`)
