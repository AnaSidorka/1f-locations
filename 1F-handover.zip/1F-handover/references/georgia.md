# Georgia — verified figures and ready state blocks

**H1-режим: третья форма** — `Payday loan alternatives in {{City}}, {{State}}` (P3-11):
payday в Джорджии **строго запрещён**, а не вытеснен другим продуктом. Can-You-Get
открывается словом **No**.

**Отсечка из шага 3 блока Apply убрана.** В таблице полос P2-12 Джорджии нет, а выдумывать
значение нельзя. SKILL.md прямо разрешает: «Если в штате нет выдачи в тот же день, время
отсечки из шага 3 убирается совсем».

## Verified legal figures

Открыто 16 сентября 2026:

- Регулятор, страница о payday: https://dbf.georgia.gov/payday-lending
- Правила по installment-займам, глава 80-14-5: http://rules.sos.ga.gov/gac/80-14-5
- Регулятор: **Georgia Department of Banking and Finance**, https://dbf.georgia.gov/

| Item | Verified value | Откуда |
|---|---|---|
| Payday lending | **Illegal.** Дословно: «Payday lending **is illegal in Georgia**. O.C.G.A. § 16-17-2» | DBF |
| Что разрешено вместо | потребительский installment-заём **$3,000 или менее**, Georgia Installment Loan Act | DBF |
| Лицензия | обязательна у Департамента, кроме освобождённых лиц | DBF |
| Первый платёж | не позднее **45 дней** с выдачи | Rule 80-14-5 |
| Единовременный заём | срок возврата не более **90 дней** | Rule 80-14-5 |
| Просрочка | **$10** или **5¢ за каждый $1** платежа, что больше | Rule 80-14-5 |
| Последний платёж | не может превышать остальные более чем на **$1** | Rule 80-14-5 |
| Куда жаловаться | county solicitor или district attorney, Департамент, федеральные CFPB и FTC | DBF |

### NOT verified — do not publish

- **Потолок ставки и APR по installment-займу.** Правила 80-14-5 сами ставок не задают,
  а отсылают к O.C.G.A. §7-3-11, §7-3-14, §7-3-17. Текст этих секций в сессии **не читался**:
  официальный кодекс Джорджии живёт на advance.lexis.com и не открывается, зеркало
  `ga.elaws.us` ответило 503. Пока цифры нет — на страницу не идёт ни ставка, ни APR,
  ни представительный пример в долларах.
- Любая цифра «APR payday в Джорджии». Продукта здесь нет, значит и ставки нет.
- Диапазон «$100 to $500» со страницы DBF — это **описание того, как payday выглядит вообще**,
  а не разрешённый в Джорджии лимит. Как лимит не подавать.

### Ловушка

**Запрет — уголовная норма, а не отсутствие лицензии.** O.C.G.A. §16-17-2 лежит в Title 16,
это уголовный кодекс, и DBF отправляет пострадавших к прокурору округа. Формулировка
«payday lenders are not licensed here» смягчает факт и неверна по сути. Пиши «prohibited»
или «illegal», и не обещай, что заём можно получить «у лицензированного payday-кредитора» —
таких в штате нет.

## Georgia city parameters

ZIP и региональную привязку подтверждать при сборке (P1-2). Округ нужен для серий FRED.

| City | County | region label | ZIP | cutoff |
|---|---|---|---|---|
| Athens | Clarke County | northeast Georgia | — | нет |
| Atlanta | Fulton County | metro Atlanta | — | нет |
| Augusta | Richmond County | the CSRA | — | нет |
| Decatur | DeKalb County | metro Atlanta | — | нет |
| LaGrange | Troup County | west Georgia | — | нет |
| Rome | Floyd County | northwest Georgia | — | нет |
| Warner Robins | Houston County | middle Georgia | — | нет |

Серии FRED: доход округа `MHIGA13<FIPS>A052NCEN`, нагрузка `DP04ACS013<FIPS>`,
медиана штата `MHIGA13000A052NCEN`.

**Decatur — омоним:** есть Decatur в Джорджии (DeKalb County) и Decatur в Иллинойсе.
Не перепутать при сборке (см. `cities-99.md`).
**Atlanta и Decatur — соседи в metro Atlanta, в разных округах.** Следи, чтобы ¶2 и FAQ
не стали близнецами (P4-6), и не сравнивай их между собой (P4-8).

## Ready state blocks (change only {{City}}/{{County}})

### Loan Products (GA) — exactly 2 cards, payday отсутствует
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>The legal route in Georgia. You repay in monthly payments over a set schedule rather than in one go, and the lender has to hold a state license. Ask for the annual percentage rate and the total cost of credit in dollars before you sign.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Personal Loans</h3>
        <p>For a larger or longer need, a personal loan spreads repayment further and is priced on your credit and income. Compare the total cost in dollars against an installment loan rather than comparing monthly payments alone.</p>
        <a href="https://1firstcashadvance.org/personal-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Personal Loans &rarr;</a></div>
    </div>
  </div>
</section>
```

### Georgia Law at a Glance — 8 rows, one § mark, no dollar example
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>Georgia Law at a Glance</h2>
    <p>These are the small-loan rules for all of Georgia, including {{City}}. In plain terms: what is banned, what is allowed instead, and who to tell if someone breaks the rule. Full detail is on the <a href="https://dbf.georgia.gov/payday-lending">Department of Banking and Finance page</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>Georgia position</th></tr>
      <tr><td>Payday lending</td><td>Illegal under O.C.G.A. § 16-17-2, and enforced as a criminal matter</td></tr>
      <tr><td>Allowed instead</td><td>A consumer installment loan of $3,000 or less under the Georgia Installment Loan Act</td></tr>
      <tr><td>License</td><td>The lender must hold a state license unless it is exempt</td></tr>
      <tr><td>First payment</td><td>Due no later than 45 days after the loan is made</td></tr>
      <tr><td>Single-payment loans</td><td>The repayment period may not run past 90 days</td></tr>
      <tr><td>Late charge</td><td>$10, or five cents for each dollar of the installment, whichever is greater</td></tr>
      <tr><td>Final payment</td><td>May not exceed the other payments by more than $1</td></tr>
      <tr><td>Where to report it</td><td>Your county solicitor or district attorney, the Department, or the federal CFPB</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Rates and fees on a licensed loan are set by statute and appear in your contract. Ask for the annual percentage rate and the total cost in dollars before you sign anything.</p>
  </div>
</section>
```

### Other Ways to Cover an Emergency (GA)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history rather than a credit score alone.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call your {{County}} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
```

### Borrow Carefully (GA) — 4 bullets, no $ figure
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Check the license before anything else.</strong> A lender offering a payday loan in Georgia is offering something the law forbids, and that is the clearest signal to walk away there is.</li>
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Cost rises with the amount, and qualifying for more is not a reason to take more.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the payment schedule in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any small loan.</li>
      </ul>
      <p style="margin-bottom:0">To check a license or report an illegal loan, contact the <a href="https://dbf.georgia.gov/">Georgia Department of Banking and Finance</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```

## Заголовок блока офисов (решение владельца, 16 сентября 2026)

H2 блока офисов на страницах Джорджии читается
**`Where to get payday loan alternatives in {{City}}`**, а не форма по умолчанию.

Причина: гейт (`validate.py:65`) требует буквальную подстроку `Where to get payday loan`,
и на странице, где payday назван незаконным, форма по умолчанию обещала бы читателю
запрещённый продукт. Расширение сохраняет подстроку и снимает обещание. Правило внесено
в P3-5; штаты второй формы (CO, OH) продолжают использовать форму по умолчанию.
