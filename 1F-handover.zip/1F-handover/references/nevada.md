# Nevada — verified figures and state notes

Nevada **is** a working payday state. Deferred deposit loans are legal, licensed and actively
made under NRS Chapter 604A. Unlike Colorado and Ohio, no replacement product is needed:
write the blocks to the payday shape, closest to the Louisiana form.

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11).

Regulator: **Financial Institutions Division**, Nevada Department of Business and Industry —
https://fid.nv.gov

## Verified figures

Source: Nevada Revised Statutes Chapter 604A, statutory text read 2026-09-10.

| Item | Verified value | Cite |
|---|---|---|
| Governing law | Deferred Deposit Loans, High-Interest Loans, Title Loans and Check-Cashing Services, NRS Chapter 604A | — |
| Maximum deferred deposit loan | Must not exceed **25 percent of the customer's expected gross monthly income** when the loan is made | 604A.5017 |
| Original term | Must not exceed **35 days** | 604A.501 |
| Extension ceiling | A licensee may not extend repayment, renewal, refinancing or consolidation beyond **90 days** after origination | 604A.501 |
| High-interest loan — definition | A loan charging an APR of **more than 40 percent**; excludes deferred deposit, refund anticipation and title loans | 604A.0703 |
| High-interest loan — payment limit | Any required **monthly payment** must not exceed **25 percent** of expected gross monthly income | 604A.5045 |
| High-interest loan — term | Must not exceed **35 days**, or up to **90 days** if it amortises fully in installments, allows no extension and carries no balloon payment | 604A.5037 |
| Repayment plan after default | Written offer within **15 days** of default, open for at least **30 days**; the plan runs at least **90 days** from default; **no** additional interest and **no** origination, set-up, collection, transaction, negotiation, handling, processing, late or default fees. An optional initial payment may not exceed 20 percent of the amount due | 604A.5027 |
| State database | The Commissioner maintains a database of deferred deposit, title and high-interest loans; licensees must query it before lending and record loan type, principal, fees, APR, finance charges, default and repayment-plan dates | 604A.303 |

**Про ставку.** Глава 604A ограничивает **размер займа и срок**, а не ставку: сама категория
«high-interest loan» определена как заём дороже 40% годовых, то есть закон допускает такие
ставки, а не запрещает их. Пиши именно так — «закон ограничивает размер и срок, а не ставку».
Не пиши «в Неваде нет потолка ставки» как утверждение о всей главе: это отрицание, которое
я не подтверждал построчным чтением всех секций.

## NOT verified — do not publish

- **A.B. 444 (2025) и потолок 40% годовых для главы 675.** Поисковая выдача упоминает, что
  положения A.B. 444 вступают в силу 1 октября 2025 и что для займов по главе 675 APR
  не превышает 40%. Текст самого билля получить не удалось (leg.state.nv.us отдаёт 403).
  Глава 675 — это installment loans, то есть вторая карточка Products. Пока не подтверждено
  по тексту билля, никаких цифр по главе 675 на странице.
- **«675 and 604A Regulations 2025» с сайта FID** — это файл с заголовком
  `DRAFT PROPOSED REGULATION`, датированный 12 марта 2025 и посвящённый двойному
  лицензированию. Черновик, не действующая норма. Не источник.
- **Ставки «менее 200% / более 200% годовых»** для подвидов high-interest loan из пересказа
  поисковика. В прочитанных секциях этих порогов нет.
- **Grace period** и правила по title loans — не читались, на страницах не появляются.

## Ловушки, специфичные для Невады

- **Счётчик цитирований гейта не видит `NRS`.** Регулярка знает `§`, `C.R.S.` и `R.S. <цифра>`;
  форма `NRS 604A.5017` невидима, как и `ORC` у Огайо. Лимит «≤2 метки» держи вручную.
- **`25%` встречается в таблице закона дважды** — в строке максимума займа и в строке платежа
  по high-interest loan. Бюджет §7a на этом исчерпан: если `25%` нужен в Can-You-Get,
  в одной из строк таблицы пиши `25 percent` словами — регулярка `\d+(?:\.\d+)?%` слова
  не считает.
- **Не путай два продукта.** Deferred deposit loan и high-interest loan — разные категории
  с разными лимитами. Ограничение «25% дохода» относится к **сумме** первого и к **месячному
  платежу** второго. Смешаешь — получишь фактическую ошибку.

## Nevada city parameters

| City | County | region label | primary ZIP | cutoff |
|---|---|---|---|---|
| Las Vegas | Clark County | the Las Vegas valley | 89102 | 9:30 am |
| Henderson | Clark County | the southeast valley | 89014 | 9:30 am |
| North Las Vegas | Clark County | the north Las Vegas valley | 89030 | 9:30 am |
| Reno | Washoe County | northern Nevada | 89502 | 9:30 am |

Отсечка `9:30 am` выведена по правилу полос: Невада в Pacific Time, как Калифорния.

**Занятые округа.** Las Vegas, Henderson и North Las Vegas — все трое в Clark County,
поэтому их блоки статистики по §5c содержат одни и те же числа (различаются ракурсом
прозы и FAQ, P4-6). Спецификация правило для этого случая по-прежнему не даёт.

## Verified income series (SAIPE via FRED, read 2026-09-10)

Nevada state median household income: 2020 $64,608 · 2021 $66,194 · 2022 $72,348 ·
2023 $76,332 · **2024 $81,129** (series MHINV32000A052NCEN).

| County (cities) | 2020 | 2021 | 2022 | 2023 | 2024 | growth | vs state 2024 |
|---|---|---|---|---|---|---|---|
| Clark (Las Vegas, Henderson) | 62,496 | 63,735 | 70,838 | 75,103 | **80,047** | +28.1% | −$1,082 |
| Washoe (Reno) | 75,232 | 76,123 | 80,245 | 84,282 | **91,178** | +21.2% | +$10,049 |

Series: MHINV32003A052NCEN (Clark), MHINV32031A052NCEN (Washoe). Titles confirmed at
fred.stlouisfed.org. 2024 is the record high of both series, and both rose in every year.

Clark sits only $1,082 under the state median — the narrowest gap in any prepared state.
Avoid language suggesting Clark is a low-income county; it is essentially at the state level.

## Distinct local angles (keep new cities distinct from these)
- Las Vegas — округ рос каждый год ряда, +28.1% за четыре года, и подошёл к медиане штата
  на расстояние около тысячи долларов.

**Формулируй привязки без ссылок на другие страницы набора (P4-8).** Список ниже — внутренняя заметка о том, какой ракурс уже занят. В тексте страницы сравнение идёт только со штатом, со своим округом и с собственной историей города по годам.
- Henderson — тот же округ Clark; страница держится на том, что окружная медиана покрывает
  очень широкий разброс домохозяйств. В тексте Лас-Вегас не упоминается.
- Reno — округ держится выше медианы штата во все годы ряда, и отрыв широкий.

## Ready state blocks (change only {{City}}/{{County}})

### Loan Products (NV) — exactly 2 cards
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A single-payment advance against your next paycheck. Nevada ties the amount you may borrow to your income and holds the original term to about a month. The whole balance falls due at once, so line the due date up with a payday you can count on.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a>
      </div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan repaid on a schedule instead of in one lump sum, with a fixed end date. If you need more time or a bigger amount, this usually works out cheaper than pushing a short-term loan forward again and again.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a>
      </div>
    </div>
  </div>
</section>
```

### Nevada Law at a Glance — 8 rows, no citation marks the gate can see
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>Nevada Law at a Glance</h2>
    <p>These are the payday rules for all of Nevada, including {{City}}. Full legal detail is in the <a href="https://1firstcashadvance.org/loans-by-state/payday-loans-nevada/">Nevada state guide</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>Nevada position</th></tr>
      <tr><td>Governing law</td><td>Deferred deposit, high-interest and title loans under NRS Chapter 604A, overseen by the Financial Institutions Division</td></tr>
      <tr><td>Maximum loan</td><td>No more than 25% of your expected gross monthly income at the time the loan is made</td></tr>
      <tr><td>Original term</td><td>No more than 35 days</td></tr>
      <tr><td>Extensions</td><td>Repayment cannot be pushed beyond 90 days from the day the loan was made</td></tr>
      <tr><td>High-interest loans</td><td>A separate category, defined as charging more than 40% a year, whose monthly payment cannot exceed 25 percent of expected gross monthly income</td></tr>
      <tr><td>Rate</td><td>The chapter limits how much you can borrow and for how long rather than setting a maximum rate</td></tr>
      <tr><td>Repayment plan</td><td>After a default the lender must offer a plan running at least 90 days, with no added interest and no extra fees</td></tr>
      <tr><td>State database</td><td>Lenders must check a state database before making the loan and record the loan in it</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">These are the legal limits, not quoted offers. Your own charge and due date come from the lender and appear in the loan agreement.</p>
  </div>
</section>
```

### Other Ways to Cover an Emergency (NV)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below a payday loan.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call a {{County}} community action agency. Ask about the state Energy Assistance Program and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
```

### Borrow Carefully (NV) — 4 universal bullets, no $ figure
```html
<section class="section">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Qualifying for more is not a reason to take more, and every extra dollar raises what you owe back.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you cannot pay on time, ask about the repayment plan rather than taking another loan.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="https://fid.nv.gov">Nevada Financial Institutions Division</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```

## Долг и жилищная нагрузка (для таблицы §5c, тянуть заново на каждой сборке)

Долг на душу по Неваде, NY Fed Consumer Credit Panel, Q4:
2020 $57,130 · 2021 $61,150 · 2022 $66,020 · 2023 $68,040 · **2024 $68,550**

Доля домохозяйств, отдающих 30%+ дохода на жильё (FRED, ACS 5-year, 2024):
Clark 39.1% (`DP04ACS032003`) · Washoe 33.8% (`DP04ACS032031`)
