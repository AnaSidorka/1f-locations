#!/usr/bin/env python3
"""Static site generator for the Texas city loan-guide sites (separate brands, not part of the 1F set).

Usage: python3 build_site.py baytown|lufkin
"""
import importlib, json, os, sys, html as H
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import site_assets as A


def layout(site, page):
    on_attr = ' class="on"'
    nav = "".join(
        f'<a href="{h}"{on_attr if h == page["file"] else ""}>{label}{badge}</a>' for h, label, badge in site["nav"])
    tick = "".join(f"<span>&#9733; {t}</span>" for t in site["ticker"]) * 2
    lds = [{"@context": "https://schema.org", "@type": "WebPage", "name": page["title"], "description": page["desc"],
            "inLanguage": "en-US", "dateModified": site["iso_date"]}] + page.get("jsonld", [])
    ld = "".join(f'<script type="application/ld+json">{json.dumps(d, ensure_ascii=False)}</script>\n' for d in lds)
    footer_links = " &middot; ".join(f'<a href="{h}">{label}</a>' for h, label, _ in site["nav"])
    swags = '<img src="assets/bunting.svg" alt="">' * 5
    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{H.escape(page["title"])} | {site["name"]}</title>
<meta name="description" content="{H.escape(page["desc"])}">
<meta property="og:type" content="article"><meta property="og:site_name" content="{site["name"]}">
<meta property="og:title" content="{H.escape(page["title"])}"><meta property="og:description" content="{H.escape(page["desc"])}">
{site.get("head_extra", "")}<link rel="stylesheet" href="style.css">
{ld}</head><body>
<div class="page">
<div class="topbar"><span>{site["topbar"]}</span><span><span class="blinky">&#9733;</span> Updated {site["updated"]}</span></div>
<header class="banner">
<img class="flag" src="assets/flag-tx.svg" alt="Texas flag waving" width="130" height="90">
<div class="brand"><a class="logo" href="index.html"><span class="st">&#9733;</span> {site["name"]} <span class="st">&#9733;</span></a>
<p class="tagline">{site["tagline"]}</p></div>
<img class="flag" src="assets/flag-us.svg" alt="United States flag waving" width="130" height="81">
</header>
<div class="swags" aria-hidden="true">{swags}</div>
<nav class="menu">{nav}</nav>
<div class="ticker" role="region" aria-label="Key facts"><div class="ticker-track">{tick}</div></div>
<div class="layout">
<main>
{page["html"]}
</main>
<aside>
{site["sidebar"]}
</aside>
</div>
<footer>
{site["footer_art"]}
<div class="fin">
<p>{footer_links}</p>
<p>General information only, not legal or financial advice. Laws and city ordinances change; check the linked sources before you borrow. Last updated {site["updated"]}.</p>
</div>
<div class="rwb"></div>
</footer>
</div>
</body></html>
"""


def build(name):
    mod = importlib.import_module(f"site_{name}")
    site = mod.SITE
    out = site["out"]
    os.makedirs(os.path.join(out, "assets"), exist_ok=True)
    assets = A.SKETCH_ASSETS if site.get("style") == "sketch" else A.ASSETS
    for fn in site["assets"]:
        open(os.path.join(out, "assets", fn), "w", encoding="utf-8").write(assets[fn]())
    open(os.path.join(out, "style.css"), "w", encoding="utf-8").write((site.get("css") or A.CSS) + site.get("css_extra", ""))
    for page in mod.PAGES:
        html = layout(site, page)
        open(os.path.join(out, page["file"]), "w", encoding="utf-8").write(html)
        print("wrote", page["file"], len(html))


if __name__ == "__main__":
    build(sys.argv[1] if len(sys.argv) > 1 else "baytown")
