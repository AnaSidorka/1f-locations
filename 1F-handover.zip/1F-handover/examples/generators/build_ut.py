#!/usr/bin/env python3
"""Build the Salt Lake City, Utah page (spec v3) into builds/2026-09-21-ut/."""
import html, json, os, re, sys

ROOT = "/Users/bamer/Downloads/VS CODE/1F Locations"
OUT = os.path.join(ROOT, "builds/2026-09-21-ut")
BASE = os.path.join(ROOT, "builds/Alabama Final/dothan-al-loans-NEW.html")

STATE, ST, SFIPS = "Utah", "UT", "49"
DATE, DATE_ISO, CUTOFF = "September 21, 2026", "2026-09-21", "10:30 am"
DEBT = {2020: 65360, 2021: 71900, 2022: 79240, 2023: 80240, 2024: 80820}
STATE_MHI_2024 = 96398
STATE_GUIDE = "https://1firstcashadvance.org/loans-by-state/utah/"

UTCODE = "https://le.utah.gov/xcode/Title7/Chapter23/7-23.html"
UTDFI = "https://dfi.utah.gov/"

GAP_SRC_LABEL = f"Census SAIPE for {STATE} via FRED"
H1_TMPL = "Payday Loans in {city}, {STATE}"
OFFICE_H2_TMPL = "Where to get payday loan {city}"
PRODUCTS = """      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A small advance against a personal check you write today. The lender holds the check until the date in your agreement, and you repay the full amount in one payment. It is built for a short gap between paychecks.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in monthly payments, not all at once. It is usually unsecured and has a set end date. If you need a bigger amount or more time, this is often cheaper than a payday loan.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>"""

CARD1 = ('<div class="stat-card"><div class="num gold">Ten-week clock</div><div class="lbl">Interest on this loan runs for a fixed stretch of weeks and then stops by law</div>'
         '<div class="src">Source: <a href="' + UTCODE + '">Utah Code 7-23-401, Utah Legislature</a></div></div>')
CARD2 = ('<div class="stat-card"><div class="num navy">Posted in dollars</div><div class="lbl">The schedule of interest and fees must hang in the office stated as dollar amounts</div>'
         '<div class="src">Source: <a href="' + UTCODE + '">Utah Code 7-23-401, Utah Legislature</a></div></div>')
CARD3 = ('<div class="stat-card"><div class="num navy">Plan on request</div><div class="lbl">A borrower may move the balance onto an extended payment plan once in a twelve-month period</div>'
         '<div class="src">Source: <a href="' + UTCODE + '">Utah Code 7-23-403, Utah Legislature</a></div></div>')
CARD6 = ('<div class="stat-card"><div class="num navy">Void if unregistered</div><div class="lbl">A loan from a lender that skipped state registration cannot be collected at all</div>'
         '<div class="src">Source: <a href="' + UTCODE + '">Utah Code 7-23-201, Utah Legislature</a></div></div>')

LAW_INTRO = ('The rules are in <a href="' + UTCODE + '">Utah Code chapter 7-23</a>, and the '
             '<a href="' + UTDFI + '">Utah Department of Financial Institutions</a> registers the lenders and takes complaints.')
LAW_ROWS = """      <tr><td>Governing law</td><td>Check Cashing and Deferred Deposit Lending Registration Act, Utah Code 7-23, administered by the Department of Financial Institutions</td></tr>
      <tr><td>Interest window</td><td>No further interest may be collected once 10 weeks have passed from the day the loan was executed</td></tr>
      <tr><td>Rollovers</td><td>Only when you ask for one, and never so that repayment falls past that same ten-week mark</td></tr>
      <tr><td>A second loan</td><td>Cannot be used the same day to stretch the combined terms past ten weeks of consecutive interest</td></tr>
      <tr><td>Partial payments</td><td>Allowed any time before maturity, in amounts of $5 or more, with no extra charge</td></tr>
      <tr><td>Cancelling</td><td>Rescind by 5 p.m. on the next business day and owe nothing for it</td></tr>
      <tr><td>Payment plan</td><td>Once in twelve months on request, and after ten weeks of interest the lender must grant one: four equal payments or more</td></tr>
      <tr><td>Unregistered lender</td><td>The loan is void, and no principal, interest or fees may be collected from you</td></tr>"""
LAW_FINE = ('Utah does not publish a representative price for these loans. What the law does require is that the schedule of interest and fees hangs in the office '
            'in dollar amounts, that a lender walks you through the rate and the due date out loud, and that the plan described above carries no interest or fees of any kind.')
STATS_FINE = ('Utah limits how long interest may run rather than testing your income, so the cost depends on the weeks you hold the loan and not on local earnings.')
BC_FIRST = ('<li><strong>Know the ten-week mark.</strong> Interest stops there, and at that point the lender has to give you a payment plan if you ask. '
            'Put the date in your calendar the day you borrow.</li>')
REG_LINE = ('To check that a lender is registered or to file a complaint, contact the <a href="' + UTDFI + '">Utah Department of Financial Institutions</a> or the federal CFPB.')
UTILITY_CARD = ('<div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or heating bill, call your {county} community action agency. '
                'Ask about energy bill assistance and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>')

CITIES = [
 dict(city="Salt Lake City", county="Salt Lake County", fips="035",
      mhi={2020: 79294, 2021: 80676, 2022: 91713, 2023: 94013, 2024: 99008},
      offices=[("1465 State St #9", "84115", "5:30 PM"), ("1338 S Foothill Dr #195", "84108", "7:00 PM"),
               ("1645 W 700 N K", "84116", "6:00 PM"), ("130 W 2100 S Expy", "84115", "6:00 PM"),
               ("2120 S State St", "84115", "8:00 PM"), ("2716 S State St", "84115", "6:00 PM"),
               ("243 E 3300 S", "84115", "9:00 PM"), ("1296 E 3300 S", "84106", "8:00 PM"),
               ("757 E 3300 S", "84106", "6:00 PM"), ("981 E 3300 S", "84106", "8:00 PM"),
               ("3514 W 3500 S", "84119", "8:00 PM"), ("4083 S Redwood Rd", "84123", "6:00 PM")],
      p1="Yes. Utah registers these lenders and runs the loan on a clock rather than a rate ceiling: interest stops ten weeks after the day you sign, a rollover cannot carry you past that mark, and you may cancel by 5 p.m. the next business day.",
      p2="Salt Lake County income rose in every year since 2020 and ended 2024 a little above the state median. The ten-week clock is the figure that governs the cost here, so the question to answer before signing is whether your pay clears the balance inside that window, not whether the county had a good year.",
      lbl4="Median household income in Salt Lake County in 2024, the latest year in the table below",
      growth="County income grew about twenty-five percent across these five years, roughly in step with state debt per person.",
      housing="Nearly three in ten households here",
      faq=[("What happens ten weeks after I borrow?",
            "Interest stops. The lender may not collect further interest on the balance once ten weeks have passed from the day the loan was executed, and cannot roll the loan over in a way that pushes repayment beyond that point. You may also ask for a payment plan then."),
           ("How does the extended payment plan work?",
            "You ask, once in any twelve months, and the lender sets it up. The balance is split into four equal payments or more, running at least sixty days from the day the plan starts, and the lender may not add interest or any fee to it, whatever the fee is called."),
           ("How fast could the money reach my account?",
            "If a lender approves you and the application is finalized by 10:30 am local time on a weekday, funds can arrive the same day. Later applications, weekends and bank holidays move funding to the next business day, and same-day deposit is not available to every customer.")]),
]
def slug(c):
    return c.lower().replace(" ", "-") + f"-{ST.lower()}-loans"


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build(c):
    base = open(BASE, encoding="utf-8").read()
    head = base[:base.find("</head>")]
    city, county = c["city"], c["county"]
    h1 = H1_TMPL.format(city=city, STATE=STATE)
    title = f"{h1} | 1F Cash Advance"
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)
    assert "<!-- skill-version: v2 -->" in head
    fred_c = f"https://fred.stlouisfed.org/series/MHI{ST}{SFIPS}{c['fips']}A052NCEN"
    fred_s = f"https://fred.stlouisfed.org/series/MHI{ST}{SFIPS}000A052NCEN"
    dp04 = f"https://fred.stlouisfed.org/series/DP04ACS0{SFIPS}{c['fips']}"
    m24 = c["mhi"][2024]
    if "gap_card" in c:
        gap_txt, gap_lbl = c["gap_card"]
        gap_src = fred_c
    else:
        gap = STATE_MHI_2024 - m24
        gap_txt = f"{money(abs(gap))} {'below' if gap > 0 else 'above'}"
        gap_lbl = f"How far {county} sat {'under' if gap > 0 else 'above'} the {STATE} median in 2024"
        gap_src = fred_s

    # Hero (global, fixed) — copied from base, city/state swapped
    hs = base.find('<div class="topbar">'); he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he]
    hero = hero.replace("Payday Loans in Dothan, Alabama", h1).replace("licensed Alabama lender", f"licensed {STATE} lender")
    hero = hero.replace("Updated: September 3, 2026", f"Updated: {DATE}")
    assert "Dothan" not in hero and "Alabama" not in hero

    offices = "".join(
        f'<div class="office-card">\n<p class="office-addr">{html.escape(st)}<br>{city}, {ST} {z}</p>\n'
        f'<p class="office-hours">' + ("Open 24 hours" if close == "24" else f"Open today 8:00 AM &ndash; {close}") + '</p>\n</div>'
        for st, z, close in c["offices"])

    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(c['mhi'][y])}</td><td>{money(DEBT[y])}</td><td>{money(round(c['mhi'][y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))

    others = [x["city"] for x in CITIES if x["city"] != city]
    links = " &middot; ".join(f'<a href="https://1firstcashadvance.org/{slug(o)}/">{o}</a>' for o in others)

    office_h2 = OFFICE_H2_TMPL.format(city=city)
    utility_card = UTILITY_CARD.format(county=county)
    src_lead = globals().get("SRC_LEAD", "County income")
    tbl_cap = globals().get("TBL_CAP", f"{county} median household income and {STATE} household debt, 2020 to 2024")
    debt_col = globals().get("DEBT_COL", f"{STATE} debt per person")
    if others:
        links_h2 = f"1F Cash Advance in Other {STATE} Cities"
        links_intro = f"The same {STATE} rules apply statewide. See how they play out where you live:"
    else:
        links_h2 = globals().get("LINKS_H2", f"1F Cash Advance Across {STATE}")
        links_intro = f"The same {STATE} rules apply statewide, in every town and county."
        links = f'<a href="{STATE_GUIDE}">{STATE} payday loan rules &rarr;</a>'

    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in c["faq"])

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {city} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {city}</h2>
    <div class="prod-grid">
{PRODUCTS}
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>{office_h2}</h2>
    <div class="office-grid">
{offices}
</div>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {city}?</h2>
    <p>{c['p1']}</p>
    <p style="margin-top:14px">{c['p2']}</p>
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {city}: What the Numbers Show</h2>
<div class="stat-grid">
{CARD1}
{CARD2}
{CARD3}
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">{c['lbl4']}</div><div class="src">Source: <a href="{fred_c}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{gap_txt}</div><div class="lbl">{gap_lbl}</div><div class="src">Source: <a href="{gap_src}">{GAP_SRC_LABEL}</a></div></div>
{CARD6}</div>
<p class="tbl-cap">{tbl_cap}</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{debt_col}</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">{src_lead} comes from <a href="{fred_c}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column comes from the <a href="https://www.newyorkfed.org/microeconomics/databank.html">New York Fed Consumer Credit Panel</a>. {c['growth']} <a href="{dp04}">{c['housing']}</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. {STATS_FINE} The last column is a calculation, not a published figure: monthly county income after the standard housing share. It describes a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>These are the payday rules for all of {STATE}, including {city}. In plain terms: how much you can get, what it costs, and what happens if you cannot pay on time. {LAW_INTRO}</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
{LAW_ROWS}
    </table>
    <p class="fine" style="margin-top:12px">{LAW_FINE}</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {city}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {city} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below payday.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      {utility_card}
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        {BC_FIRST}
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you see a problem coming, talk to the lender before the date, not after it.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">{REG_LINE}</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{city} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>{links_h2}</h2>
    <p style="max-width:760px">{links_intro}</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
"""
    # Authors (global) — copied from base, county swapped
    a_s = base.rfind("<section", 0, base.find("Who wrote this")); a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e].replace("Houston County", county)
    assert "Dothan" not in authors and "Alabama" not in authors

    url = f"https://1firstcashadvance.org/{slug(city)}/"
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": url, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": STATE_GUIDE}, {"@type": "ListItem", "position": 4, "name": city}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": {"@type": "Person", "name": "Latoria Williams"}, "editor": {"@type": "Person", "name": "Marsha Welch"}, "reviewedBy": {"@type": "Person", "name": "Michael Lefler"}, "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Payday loan matching in {city}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{city}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    for c in CITIES:
        if only and c["city"] not in only:
            continue
        p = os.path.join(OUT, slug(c["city"]) + "-NEW.html")
        open(p, "w", encoding="utf-8").write(build(c))
        print("wrote", p)


if __name__ == "__main__":
    main()
