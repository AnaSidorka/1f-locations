# Oregon — verified figures and ready state blocks

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11). Payday легален и жёстко
ограничен. Заголовок офисов — форма по умолчанию. Can-You-Get открывается словом **Yes**.
Отсечка шага 3 — **9:30 am** (тихоокеанский пояс, полоса CA/WA/OR).

## Источники — открыты 19 сентября 2026

**Сайт легислатуры `oregonlegislature.gov` не отвечает** (соединение висит), поэтому текст ORS 725A
не читался и на него нет ссылок. Всё ниже — со страниц регулятора **Division of Financial Regulation**,
они открываются.

| Документ | URL |
|---|---|
| DFR, Payday loans | https://dfr.oregon.gov/financial/loans/personal/payday/Pages/index.aspx |
| DFR, Personal loans (обзор) | https://dfr.oregon.gov/financial/loans/personal/Pages/index.aspx |
| DFR, Licensed payday and title lenders | https://dfr.oregon.gov/financial/loans/personal/payday/Pages/licensed-payday-and-title-lenders.aspx |

## Verified figures

| Item | Verified value | Cite |
|---|---|---|
| Срок | **не меньше 31 дня** и **не больше 60** | DFR, Payday loans |
| Проценты | не больше **36%** годовых | DFR |
| Origination fee | разовая, **10%** суммы займа, **максимум $30** на новый заём | DFR |
| Максимальный APR | **153.77%** — при максимальной ставке и максимальном сборе | DFR |
| Продления | **не больше двух**; после двух заём и проценты гасятся полностью | DFR |
| Таблица предельной цены | заём **$100** → сбор и проценты **$13.06**, всего **$113.06**; $200 → $26.12; $300 → $39.17 | DFR |
| Договор | письменный, с раскрытием сборов, ставки, дат платежей и последствий просрочки и дефолта | DFR |
| Лицензия | обязательна всем payday- и title-кредиторам, **включая онлайн**; легальных онлайн-кредиторов немного | DFR |
| Племенные кредиторы | работают вне закона штата; **племена Орегона в payday сейчас не участвуют**; жалобы — в FTC и CFPB | DFR |

### NOT verified — do not publish
- Текст ORS 725A и любые детали, которых нет на страницах DFR (сайт легислатуры недоступен).
- Число лицензиатов и статистика выдачи.
- Правила title и pawn loans — отдельные страницы, не читались.

## Oregon city parameters

| City | County | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Portland | Multnomah County | MHIOR41051A052NCEN | DP04ACS041051 | 9:30 am |

Медиана штата: `MHIOR41000A052NCEN`. Долг на душу: NY Fed, лист `total`, строка `OR`.

**Ловушка адресов.** Почтовый «Portland, OR» и соседние города: ZIP 97005 — **Beaverton**
(Washington County), 97304 — **Salem** (Polk County). Проверять геокодером.

## Ready state blocks

Форма — как у Миссисипи (первая форма): Products = Payday Loans + Installment Loans.
Блок 14 — форма одиночного города: `1F Cash Advance Across Oregon` + ссылка на страницу штата.

### Шесть стат-карточек — правовые (1–3, 6)
| # | `.num` | Источник |
|---|---|---|
| 1 | `Term floor` | DFR |
| 2 | `Fee plus interest` | DFR |
| 3 | `Capped APR` | DFR |
| 6 | `Two renewals` | DFR |

## Distinct local angles
- Portland / Multnomah County — доход рос каждый год с 2020, в 2024 на $5,526 выше медианы штата;
  жилищная нагрузка **38.9%** — самая высокая среди округов набора; рост за пять лет ~21% против ~16%
  у долга на душу (долг штата снижался в 2023).
