---
name: 1f-page-builder
description: "Orchestrate full production of 1F Cash Advance city loan pages (1firstcashadvance.org) for any US city/state, self-contained in one file: request office addresses, verify the state's law/figures live from the official regulator each run (no bundled files, no baked-in state), build layout and copy through agents against the strict three-layer spec (global/state/city blocks), run the office audit stack (AI-fingerprint, Google-update/E-E-A-T, financial editorial), apply the fixes, then run the pre-delivery checklist and 1f-page-validator on the finished page. Use to create, rebuild, batch-fix, or add offices/figures to any 1F city page. Trigger on 'сделай страницу для [город]', 'новый город', 'добавь адреса офисов', '1F city page', 'payday page for [city]', or any 1F city/state work. Always ask for office addresses first. Never invents addresses, statistics, legal figures, or cutoffs; caps every loan-law number and theme at twice; stops with STATE LAYER NOT DEFINED when figures cannot be verified."
---

# 1F Page Builder v4 (single-file, live state layer)

## Purpose
Build or revise 1F Cash Advance city loan pages for any U.S. city/state using a strict three-layer architecture and the full production checklist.

This skill is universal and self-contained in this one file. There are no bundled reference or asset files, and no state is baked in as an example or fallback. Every state layer is verified live each run. Section T holds the generic (state-neutral) HTML shape of the state-locked blocks.

## Source-of-truth hierarchy
1. This SKILL.md defines universal structure, global locked copy, city-block requirements, validation requirements, and production process.
2. The state layer (law, products, cutoff, regulator, figures) is verified LIVE from the official state regulator/statute each run and held in-session. No `references/*.md` files. Section T is the state-neutral HTML shape a state layer must fill.
3. User-provided office addresses/hours define the office block.
4. Official primary sources define city statistics and legal facts.

Never silently borrow wording, cutoff times, law, regulator details, product limits, APR, fees, or lender rules from another state.

---

# A. Production pipeline (agent-driven orchestration)

This skill owns the entire run, not only the spec. When the user asks to create, rebuild, or fix a city page, execute this pipeline end to end. Sections 0 through 25 are the source of truth that every agent and every check follows. Run independent agents in parallel; give each agent this SKILL.md and the state layer verified for this run as its brief.

## Phase 0. Intake and addresses
1. Confirm City, State, ST, primary ZIP, county/parish, and page URL slug.
2. Ask the user for office addresses before any assembly. For each office collect: street address, ZIP, and closing time (opening is 8:00 AM unless the user explicitly overrides). Accept an explicit `no offices for this city` to skip the office block.
3. Clean obvious address errors and flag them to the user. A common one is the house number duplicated into the ZIP column; when a `ZIP` is not a plausible 5-digit code for that city, correct it only when supported and flag it, otherwise remove it.
4. Verify the state layer for this run (section 20) before assembly. If the regulator figures cannot be verified, stop and report `STATE LAYER NOT DEFINED`.
Do not start production until addresses (or an explicit skip) and the verified state layer are both in hand.

## Phase 1. Build layout and copy through agents
Dispatch agents to produce the page against this spec:
- Research agent: verify state law/regulator figures LIVE (official regulator/statute) and gather city statistics from official primary sources (Census ACS / QuickFacts). Return every figure with a clickable primary-source link. No invented numbers.
- City-copy agent: write the city-specific blocks (Can You Get, Borrowing and Debt, FAQ, Other Cities links) to the exact section rules, distinct from sibling pages. Global and state locked blocks are inserted verbatim from this spec and the verified state layer; agents never rewrite locked copy.
- Assembly agent: assemble the page in the required order (section 0), insert the global locked blocks, apply the state-locked blocks, place the office block, recalculate the zebra programmatically, and build and sync the 6 JSON-LD blocks (section 21).

## Phase 2. Run audits
Run the office audit stack on the assembled draft, via agents, in parallel:
- `ai-text-fingerprint`: scan for AI-generation markers and flag every passage to humanize.
- `master-content-auditor`: Google-update compliance, QRG E-E-A-T scoring with YMYL weighting, and senior editorial review.
- `financial-editor-investopedia`: native US English, current-relevance, and US legal/regulatory (YMYL lending) compliance.
Collect all findings into one issue list with severity and exact block/location.

## Phase 3. Apply audit fixes
Apply the audit findings back into the page. Rewrite flagged passages to remove AI markers and meet the E-E-A-T, editorial, and legal standards while staying inside the locked wording, the tone rules (section 18), and the dedup rules (section 19). A fix must never reintroduce a banned tone phrase, a third product card, cross-state figures, or a number/theme past the 2-occurrence cap. Re-run the relevant auditor on any block that changed materially.

## Phase 4. Apply the strict spec to the finished page and deliver
Only after production and audit fixes:
1. Run the full section 23 pre-delivery checklist.
2. Run the `1f-page-validator` pass on the finished page (RESULT: PASS/FAIL and READY / NOT READY TO PUBLISH, with Critical / Major / Minor / Not-verifiable counts and the issue table).
3. Fix every Critical and every Major issue, then re-validate.
4. Deliver only a page that is READY TO PUBLISH (0 Critical, 0 Major), together with the validator report.

---

# 0. Required page order

Use this exact top-to-bottom order:

1. topbar (NMLS)
2. Hero
3. How to Apply
4. Loan Products
5. What You Need to Qualify
6. How 1F Cash Advance Works
7. Where to get payday loan {City} — offices
8. Can You Get a Payday Loan in {City}?
9. Borrowing and Debt in {City}
10. {State} Law at a Glance
11. Other Ways to Cover an Emergency in {City}
12. Borrow Carefully
13. {City} Borrowers Ask — FAQ
14. 1F Cash Advance in Other {State} Cities
15. About the Authors

After Hero, section backgrounds must alternate strictly between `section` and `section alt`. Recalculate zebra programmatically after every insert/delete/move.

Apply H2 never contains ZIP. ZIP belongs only in office addresses.

---

# 0.1 Three content layers

## Global locked blocks
Same for all cities/states except permitted placeholders:
- Hero
- How to Apply
- What You Need to Qualify
- How 1F Cash Advance Works
- topbar structure
- Authors structure

## State-locked blocks
Same for all sibling cities in one state, taken from the verified state layer:
- Loan Products
- {State} Law at a Glance
- Other Ways to Cover an Emergency
- Borrow Carefully
- Apply funding/cutoff variant
- regulator / state-guide details

## City-specific blocks
Must be written for each city while preserving the required structure:
- offices
- Can You Get a Payday Loan in {City}?
- Borrowing and Debt in {City}
- FAQ
- Other {State} Cities links
- local angle / county-or-parish reference where required

---

# 1. Company positioning

Required positioning:
`1F Cash Advance is a loan connector and financial marketplace, not a direct lender.`

Rules:
- Keep `not a direct lender` in How 1F Cash Advance Works, not in Hero.
- Present 1F as a trusted connector/marketplace that routes requests to licensed lenders authorized in the state.
- Do not describe 1F as the lender, approver, rate-setter, or funder.

---

# 2. Topbar

Required text:
`Licensed loan connector · NMLS ID 1814281`

Do not use unverified/state-specific claims such as `Serving {State} residents online since 2019` in the topbar.
`since 2019` may appear only inside the approved Why Trust Us? badge copy.

---

# 3. Hero — globally locked

H1:
`Payday Loans in {City}, {State}`

Subheading:
`Apply online in minutes, from your phone.`

Bullets, exact wording and order:
- `5-minute request, fast lender decision`
- `Soft credit check to prequalify`
- `Same-day funding available on weekday approvals`

Hero card must retain:
- `Check your rate`
- application CTA
- consent line linking Terms / Rates / Privacy Policy / Disclaimer

Hero foot must retain:
- `Why Trust Us?`
- `Fact-Checked`
- updated date
- Written by Latoria Williams
- Edited by Marsha Welch
- Reviewed by Michael Lefler

Do not add regulator text or `not a direct lender` positioning to hero-foot.

---

# 4. How to Apply — global structure + state funding variant

H2:
`How to Apply from {City}`

No ZIP or state abbreviation in this H2.

Step 1 title:
`Fill out the online form`

Step 1 body:
`The application is open 24/7 and takes about five minutes.`

Step 2 title:
`Get a decision`

Step 2 body:
`We check your details and pass them to lenders licensed in {State}, usually within the hour during business hours.`

Step 3 title:
`Receive the funds`

The exact Step 3 body and fine print come from the verified state layer for this run.

## Standard same-day state variant
Use only when the state layer explicitly enables same-day cutoff:

`Approved funds go straight to your bank account. Same-day cutoff: {StateCutoff} local time.*`

`*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.`

## Ban/installment-state variant
Use when the state layer explicitly disables cutoff/same-day wording:

`Approved funds are deposited to your bank account, often within one business day.`

Fine print:
`Funding time depends on your bank. Approval is not guaranteed and depends on verification of your income and application details.`

## Cutoff source
The cutoff value, or the no-cutoff / ban status, comes only from the verified state layer for this run (section 20). Never invent a cutoff and never carry one over from another state.

---

# 5. Loan Products — state locked, exactly 2 cards

Exactly two product cards:
1. Payday Loans / Short-Term Loans as appropriate to the state's legal product
2. Installment Loans

Never add a third card.
Remove/forbid cards such as:
- Credit Union PALs
- Auto title loans
- Title loans

PAL belongs only in Other Ways.

Remove `div class="max"` chips.

Payday/short-term description requirements:
- state-specific
- explain the actual product mechanics
- include relevant state limit/term/cost method or prohibition status as appropriate
- concise, about 30 words where feasible
- not a statute-name placeholder

Installment description requirements:
- state-specific
- tied to the applicable state installment/consumer-finance framework when defined in the state layer
- not generic filler
- concise, about 30 words where feasible

Required icons:
- payday: `ico-wallet2.svg`
- installment: `ico-calender.svg`
- class `.prod-ic`

Explore links remain.

All legal/product wording and figures come from the state layer verified live this run (section 20).

---

# 6. What You Need to Qualify — globally locked

H2:
`What You Need to Qualify`

No intro paragraph before the list.

Exact bullet wording/order:
- Government-issued photo ID
- Social Security number
- Active checking account with a routing number
- Recent pay stub or other proof of income
- Proof of your {State} address
- Working phone number and email
- Age 18 or older

Do not add hard-inquiry/TransUnion or other side notes after the list.

---

# 7. How 1F Cash Advance Works — globally locked

H2:
`How 1F Cash Advance Works`

Intro, exact after placeholders:
`1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {State} and allowed to operate there.`

Bullets:
- **You submit one request.** A single online form, free to use, with a soft check that does not affect your credit score.
- **We route it to licensed lenders.** Your details go to lenders authorized to operate in {State}, not to a single desk.
- **The lender decides.** If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.

Closing:
`Because the lender sets the terms, always read the rate and total cost in the offer before you accept.`

Do not merge this with How to Apply.

---

# 8. Office block — city specific

Before assembly, obtain office addresses from the user/source. Never invent office addresses.

H2 exactly:
`Where to get payday loan {City}`

Rules:
- no intro paragraph
- immediately show office grid/list
- never rename to `Our {City} Offices`
- never add `Prefer to apply in person...`
- one card per verified address
- format: street address + `{City}, {ST} {ZIP}` + `Open today 8:00 AM – {CloseTime}`
- opening time is 8:00 AM unless user data explicitly supersedes
- no office schema; Organization/FinancialService remain tied to Boulder HQ
- verify obvious address/ZIP anomalies before publishing; correct only when supported, otherwise remove/flag

---

# 9. Can You Get a Payday Loan in {City}? — city specific

H2:
`Can You Get a Payday Loan in {City}?`

Paragraph 1:
- direct answer in the first word/phrase: `Yes`, `No`, or `Not the old kind` for ban/reformed states
- include the essential state figures/mechanics needed to answer the question: amount limit, term, fee/rate/APR as applicable
- do not turn it into a copy of the Law table

Paragraph 2:
- exactly one useful local angle in 1–2 sentences
- add one helpful borrower action such as borrowing only what fits or verifying the lender

Prohibited:
- `{City}'s angle is...`
- `metro county`
- echo phrasing such as `Yes, as a regulated...`
- repetitive rule-table narration

Sibling city pages should present paragraph 1 differently even when legal figures are the same.

---

# 10. Borrowing and Debt in {City} — city specific

H2:
`Borrowing and Debt in {City}: What the Numbers Show`

Required:
- exactly 3 stat cards
- exactly 1 meaningful comparison table
- city data, not county data presented as city data
- one short neutral source/context line
- clickable primary-source links
- no water after statistics

Preferred card metrics:
- city median household income
- state median household income OR city per-capita income depending the state/template
- city poverty rate

Preferred consistent metric set within one state.

Geography rules:
- normal case: City / County-or-Metro / State only when all three are genuinely distinct and useful
- independent cities: do not fabricate a county row; use City / Metro / State when metro is meaningful, otherwise City / State
- never use labels such as `same geography` or `independent city` as a substitute for a meaningful comparison

Do not use commute/travel time as a core metric unless there is a specific financial reason.

Sources:
- Census ACS / QuickFacts or another official primary source
- source links must be clickable

Do not add `The takeaway`, `The honest reading`, or similar commentary after the block.

---

# 11. {State} Law at a Glance — state locked

Use the verified state layer for all sibling cities. Follow the state-neutral HTML shape in section T.

Required:
- state-specific intro
- law table
- representative example when applicable
- required disclaimers/fine print
- current verified figures
- regulator/state-guide source link(s)

After the table/example, no explanatory essay or city-specific commentary.

Forbidden after-law extras:
- `Want the full law?`
- `Why the law change is the story in {City}`
- `The honest reading...`
- duplicated state-guide pitch

Maximum allowed extra is one functional source/state-guide/regulator line.

Representative examples must use current values, not stale figures.

---

# 12. Other Ways to Cover an Emergency in {City} — state locked structure

H2 exactly:
`Other Ways to Cover an Emergency in {City}`

Exactly 4 cards:
1. `Credit union Payday Alternative Loans`
2. `Bank small-dollar programs`
3. `Employer and paycheck advances`
4. `Utility and assistance programs`

Bank card is mandatory.
Do not add a lender-license-check card here.

PAL card should explain federal credit union PALs.
Utility card may use city/parish/county placeholders only when supported.

---

# 13. Borrow Carefully — state locked structure

Exactly 4 bullets in `.resp-list` with these lead-ins:
1. `Borrow the minimum, not the maximum.`
2. `Price the loan in dollars, not percentages.`
3. `Protect the repayment date.`
4. `Borrow for one-time gaps only.`

These bullets are universal borrower principles, not a second law summary.
State-specific payment-plan wording may appear only where supported by the verified state layer.

Required final line pattern:
`To verify a lender or file a complaint, contact the {StateRegulator} or the federal CFPB.`

---

# 14. FAQ — city specific

H2:
`{City} Borrowers Ask`

Exactly 3 questions.

Each answer:
- useful on its own
- 2–3 sentences
- under 60 words
- city/state relevant
- not a duplicate of the Law table

Questions should differ between sibling cities where practical.
Good local angles include payment plans, licensing, borrowing the maximum, military/student/storm/local context when genuinely relevant.

Visible FAQ and FAQPage JSON-LD must match exactly in question and answer text after HTML normalization.

---

# 15. Other {State} Cities — city specific interlinking

H2:
`1F Cash Advance in Other {State} Cities`

Rules:
- links only to real sibling city pages in the current state set
- no self-link
- city URL format: `/{city-slug}-{st-lower}-loans/`
- do not put all city pages in the main menu; menu uses state hubs `/loans-by-state/{st-lower}/`

---

# 16. Authors — global structure

Place after city-links.

Exactly 3 author cards:
1. Latoria Williams — Written by · CEO; approved bio/credentials/link
2. Marsha Welch — Edited by
3. Michael Lefler — Reviewed by; reviewer copy may reference the verified county/parish/city geography as defined for the page

Preserve verified author identities and profile links.

---

# 17. Remove obsolete Store blocks

Delete blocks such as:
- `There Is No 1F Storefront...`
- `Your 1F Cash Advance Store in...`
- `Visit Our {City} Store`

Do not attach FinancialService/Organization schema to city office cards. Keep Boulder HQ in Organization/FinancialService data.

---

# 18. Tone

Tone must be helpful, factual, calm, borrower-oriented, and non-lecturing.

Avoid alarmist/punitive wording including:
- `lands hardest`
- `bites hardest`
- `hurts most`
- `makes the due date risky`
- `no cushion`
- `little financial slack`
- `honest reading`
- `awkward moment`

Avoid categorical claims such as:
- `most expensive option`
- `will beat a payday loan every time`
- `the cheapest ... for most people`

Prefer conditional wording such as:
- `it helps to...`
- `borrowing what fits the gap keeps the fee down`
- `is usually cheaper`

---

# 19. Number/topic deduplication

Page-wide rule:
- each monetary amount: maximum 2 occurrences
- each percentage/APR figure: maximum 2 occurrences
- canonical locations are normally Can You Get + Law table
- each argument/theme should be explained no more than twice

Statistics are exempt only when the figure is a city-data metric rather than a loan-law/product figure; do not repeat loan-law numbers in stat cards/FAQ unless required.

After deleting/replacing copy, rescan the full page for accidental duplicates and find/replace artifacts.

---

# 20. State layer — live verification each run (no bundled files, no baked-in state)

The state layer is built fresh for the run, not read from a file and never carried over from another state. For the target state:
1. Verify current figures at the official regulator/statute: governing law, max loan amount, fee/rate method, APR, term, rollovers, refinancing, payment plan, credit reporting, and the Apply cutoff (or the ban / installment-only status).
2. Return each figure with a clickable official source link. Record the refresh window for any inflation-adjusted or date-sensitive figure.
3. Hold the verified layer in-session and build every state-locked block (Products, Law at a Glance, Other Ways, Borrow Carefully, Apply funding variant) from it, filling the state-neutral HTML templates in section T.
4. If figures cannot be verified from an official source, stop state-dependent drafting and report `STATE LAYER NOT DEFINED`.

Never invent office addresses, city statistics, legal figures, lender names, regulator details, or cutoff times. Remove unsupported figures rather than guessing.

---

# 21. Schema and technical requirements

Exactly 6 JSON-LD blocks/types:
1. Organization
2. WebPage
3. BreadcrumbList
4. FAQPage
5. Article
6. Service

Rules:
- Organization/FinancialService data remains Boulder HQ, not city office locations
- FAQPage built from the same exact question/answer strings as visible FAQ
- no stale city/state/URL values
- balanced HTML tags
- placeholders use `{{...}}` syntax in drafts
- final assembled page must contain zero unresolved `{{`
- date format: `Month D, YYYY`
- cutoff format: `H:MM am` / `H:MM pm` lowercase
- Parish uses full form where applicable
- required CSS classes remain available: `.hero-ticks`, `.trust-badge`, `.hero-foot`, `.byline-mini`, `.prod-ic`, `.resp-list`
- required fonts/styles must be present in the page template rather than assumed from WordPress inheritance

---

# 22. Production process

Work state-by-state.
For every state, verify the state layer first (section 20).

For every city page:
1. identify city/state
2. verify the state layer live
3. obtain/verify office addresses before assembly
4. assemble global locked blocks
5. apply state-locked blocks
6. write city-specific blocks to spec
7. recalculate zebra programmatically
8. build/sync schema
9. run the full automated checklist
10. fix every Critical/Major issue before delivery

Do not copy old city-specific blocks unchanged. Rewrite Can You Get / stats / FAQ to the current spec.

---

# 23. Mandatory automated pre-delivery checklist

A page is not ready until all applicable checks pass:

## Structure
- [ ] exact block order
- [ ] strict zebra after Hero
- [ ] ZIP absent from Apply H2
- [ ] office block follows How 1F Works
- [ ] Authors last after city-links

## Global blocks
- [ ] topbar exact NMLS positioning
- [ ] Hero locked content/card/trust/byline intact
- [ ] How to Apply exact state funding variant
- [ ] Qualify exact list, no intro/after-note
- [ ] How 1F exact copy

## State blocks
- [ ] state layer verified live this run
- [ ] Products exactly 2 cards
- [ ] no `.max` chips
- [ ] correct product icons/Explore links
- [ ] Law current and state-consistent
- [ ] no after-law water/duplicate CTA
- [ ] Other Ways exactly 4 required cards including Bank
- [ ] Borrow Carefully exactly 4 required lead-ins

## City blocks
- [ ] office addresses verified, no intro paragraph
- [ ] Can You Get starts with direct answer
- [ ] no `metro county`
- [ ] exactly 3 stat cards + 1 meaningful table
- [ ] statistics are city data, with official clickable sources
- [ ] no water after stats
- [ ] FAQ exactly 3 questions
- [ ] each FAQ answer <60 words and 2–3 sentences
- [ ] FAQ differs appropriately from sibling pages
- [ ] city-links contain no self-link and only real sibling pages

## Dedup/tone/facts
- [ ] every loan-law dollar amount <=2 occurrences
- [ ] every loan-law percentage/APR <=2 occurrences
- [ ] no major theme explained >2 times
- [ ] no banned alarmist/categorical tone phrases
- [ ] no unsupported figures
- [ ] no cross-state leakage

## Schema/technical
- [ ] exactly 6 JSON-LD types
- [ ] FAQ visible copy == FAQPage copy
- [ ] Organization/FinancialService remains Boulder HQ
- [ ] no unresolved `{{`
- [ ] balanced tags
- [ ] required CSS classes/fonts present
- [ ] no obsolete Store block

---

# T. State-block HTML templates (state-neutral)

Fill these with the verified state layer for the run. Every `{...}` is a placeholder to replace with verified copy/figures. `section` / `section alt` classes are placeholders too: recompute the zebra per section 0 after assembly.

## Loan Products
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {City}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>{Payday or Short-Term Loans, per state product}</h3>
        <p>{state-specific payday/short-term description per section 5: mechanics + relevant limit/term/cost method or prohibition status, ~30 words}</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>{state-specific installment description per section 5, ~30 words}</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
```

## {State} Law at a Glance
Adapt rows to the verified law. For a ban/reformed state, the direct answer and rows reflect the prohibition or the installment-only route.
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{State} Law at a Glance</h2>
    <p>{state-specific intro: the payday rules for all of {State}, including {City}; link to the {State} state guide at /loans-by-state/payday-loans-{state-slug}/}</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{State} position</th></tr>
      <tr><td>Governing law</td><td>{verified governing law + regulator}</td></tr>
      <tr><td>Maximum loan</td><td>{verified maximum}</td></tr>
      <tr><td>Fee</td><td>{verified fee/rate method}</td></tr>
      <tr><td>Rate</td><td>{verified APR}</td></tr>
      <tr><td>Term</td><td>{verified term + rollover rule}</td></tr>
      <tr><td>Refinancing</td><td>{verified refinancing rule}</td></tr>
      <tr><td>Payment plan</td><td>{verified payment-plan rule}</td></tr>
      <tr><td>Credit reporting</td><td>{verified credit-reporting rule}</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example: {current-value example}. These are illustrative figures at the current limits, not quoted offers.</p>
  </div>
</section>
```

## Other Ways to Cover an Emergency
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {City}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>{federal credit union PAL explainer, member requirement, {City} area}</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>{bank small-dollar explainer}</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>{earned-wage / paycheck-advance explainer}</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>{utility / LIHEAP explainer; {County-or-Parish} community action agency}</p></div>
    </div>
  </div>
</section>
```

## Borrow Carefully
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> {short body}</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> {short body}</li>
        <li><strong>Protect the repayment date.</strong> {short body; mention the state payment-plan option only where the verified layer supports it}</li>
        <li><strong>Borrow for one-time gaps only.</strong> {short body}</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="{StateRegulator URL}">{StateRegulator}</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```