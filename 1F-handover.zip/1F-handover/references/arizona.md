# Arizona — verified figures and ready state blocks

**H1-режим: третья форма** — `Payday loan alternatives in {{City}}, {{State}}` (P3-11; Аризона указана
в таблице форм §2 спецификации). Заголовок офисов — `Where to get payday loan alternatives in {{City}}`.
Can-You-Get открывается словом **No**.

**Отсечка шага 3 — 10:30 am** (решение владельца 17 сентября 2026, внесено в P2-12, §2 спеки и чек-лист).

## Источники — открыты 17 сентября 2026

Сайт регулятора **Arizona Department of Insurance and Financial Institutions (DIFI)** — `difi.az.gov` —
закрыт Cloudflare (403, в том числе FAQ «What happened to the payday lender DIFI used to license?»).
Пресс-релиз генпрокурора 2010 года об отмене payday — 404. **Всё ниже — из официального текста
Arizona Revised Statutes на azleg.gov.** На страницах регулятор DIFI называется без ссылки.

| Документ | URL |
|---|---|
| ARS 6-601 Definitions | https://www.azleg.gov/ars/6/00601.htm |
| ARS 6-602 Exemptions | https://www.azleg.gov/ars/6/00602.htm |
| ARS 6-603 License | https://www.azleg.gov/ars/6/00603.htm |
| ARS 6-613 Restrictions; voidable loans | https://www.azleg.gov/ars/6/00613.htm |
| ARS 6-632 Finance charges | https://www.azleg.gov/ars/6/00632.htm |
| ARS 6-635 Other allowable fees | https://www.azleg.gov/ars/6/00635.htm |
| ARS 6-636 Insurance securing loan | https://www.azleg.gov/ars/6/00636.htm |
| Генпрокурор, жалоба потребителя | https://www.azag.gov/complaints/consumer |

## Verified figures

| Item | Verified value | ARS |
|---|---|---|
| Consumer lender loans | consumer loans, consumer revolving loans, home equity revolving loans — **payday среди них нет** | 6-601(6) |
| Consumer loan | закрытый заём **$10,000 или меньше** (считается только principal) | 6-601(7) |
| Лицензия | нужна любому consumer lender, **в Аризоне или в другом штате** | 6-603(A) |
| Исключены | банки, savings banks, trust companies, S&L, credit unions, страховые — если их займы регулирует другой закон | 6-602(A)(1) |
| Ставка, заём ≤ $3,000 | consumer loan rate **36%** | 6-632(A)(1) |
| Ставка, заём > $3,000 | **36%** на первые **$3,000**, **24%** сверх — или смешанная ставка | 6-632(A)(2) |
| Origination fee | не больше **5%** закрытого займа и не больше **$150**; нельзя при рефинансе в течение года после прошлого сбора | 6-635(A)(4) |
| Просрочка | **5%** платежа, не оплаченного в течение **7 дней** после срока | 6-635(A)(1) |
| Взыскание | судебные издержки; разумные attorney fees, если заём передан внешнему юристу | 6-635(A)(7),(8) |
| Страховка | опциональна (кроме страховки залога); отказ не повод отказать в займе; отмена в течение **30 дней** с полным возвратом премии | 6-636(B) |
| Переплата | кроме случайной или добросовестной ошибки: заём ≤ **$5,000** — voidable, без права взыскать principal, charges, fees; > $5,000 — без права на finance charges | 6-613(A) |
| Без лицензии | заём **void**, нельзя взыскать principal, charges, fees | 6-613(B) |

### NOT verified — do not publish

- **Истечение закона о deferred presentment 30 июня 2010** — ни DIFI, ни генпрокурор не открылись.
  Не писать «illegal since 2010», «banned». Формулировки — через определение consumer lender loans и потолки.
- Жалобы и проверка лицензии на сайте DIFI — сайт закрыт.

## Arizona city parameters

| City | County | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Mesa | Maricopa County | MHIAZ04013A052NCEN | DP04ACS004013 | 10:30 am |
| Phoenix | Maricopa County | MHIAZ04013A052NCEN | DP04ACS004013 | 10:30 am |
| Tucson | Pima County | MHIAZ04019A052NCEN | DP04ACS004019 | 10:30 am |

Медиана штата: `MHIAZ04000A052NCEN`. Долг на душу: NY Fed, лист `total`, строка `AZ`.

**Mesa и Phoenix — один округ.** Таблицы на двух страницах совпадают; ¶2, подпись карточки дохода
и `src-note` писать разными углами; не сравнивать города между собой (P4-8).

## Ready state blocks

Форма — как у New Mexico (третья форма, Installment + Personal Loans).

### Arizona Law at a Glance — 8 rows из 8, две метки `§`
Вхождения: `$10,000`, `36%`, `$3,000`, `24%` — по 1 в таблице (второе может взять ¶1);
`5%` — 2 (запас 0); `$150`, `$5,000` — по 1.
```html
<tr><td>Payday loans</td><td>Not a type of loan the consumer lender law authorizes; licensed lenders make consumer loans and revolving loans</td></tr>
<tr><td>License</td><td>Required for any consumer lender, whether located in Arizona or another state, under §6-603</td></tr>
<tr><td>Loan size</td><td>Consumer loans of $10,000 or less</td></tr>
<tr><td>Rate cap</td><td>36% a year on the first $3,000, and 24% on any amount above that</td></tr>
<tr><td>Origination fee</td><td>Up to 5% of the loan and no more than $150, and not again on a refinance within a year</td></tr>
<tr><td>Late charge</td><td>5% of an installment still unpaid seven days after its due date</td></tr>
<tr><td>Overcharges</td><td>On a loan of $5,000 or less, the lender loses the right to collect any principal, charges or fees</td></tr>
<tr><td>Unlicensed lenders</td><td>A loan from a lender that needed a license and lacked one is void under §6-613</td></tr>
```

### Шесть стат-карточек — правовые (1–3, 6)
| # | `.num` | Источник |
|---|---|---|
| 1 | `Consumer loans` | ARS 6-601 |
| 2 | `State ceiling` | ARS 6-601 |
| 3 | `Capped by size` | ARS 6-632 |
| 6 | `Void if unlicensed` | ARS 6-613 |

Borrow Carefully: «To check a license, contact the Arizona Department of Insurance and Financial Institutions;
to report a lender, file a complaint with the Arizona Attorney General (ссылка) or the federal CFPB.»

## Distinct local angles (из таблицы SAIPE)
- Mesa / Maricopa — рост каждый год, выше медианы штата.
- Phoenix / Maricopa — рост 2024 года примерно вдвое меньше скачка 2022 года.
- Tucson / Pima — рост каждый год, ниже медианы штата на $9,411.
