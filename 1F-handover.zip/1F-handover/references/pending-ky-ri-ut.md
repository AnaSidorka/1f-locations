# KY / RI / UT — заготовка сборки (ждём текст закона)

Статус на 21 сентября 2026: сайты законов не открываются из среды сборки
(`apps.legislature.ky.gov`, `webserver.rilegislature.gov`, `le.utah.gov` — TCP-таймаут;
`dbr.ri.gov`, `dfi.utah.gov` — 403). Владелец решил: **ссылки на официальные URL ставим без захода**
(исключение только для этих трёх штатов), а **текст закона присылает владелец** — из него берутся
все цифры. Пока текста нет, страницы не собираются (P0-1).

Адреса уже проверены геокодером Census, данные ниже тянулись 21 сентября — **при сборке обновить** (P0-2a).

## Что нужно получить от владельца

| Штат | Нормы, которые нужны дословно |
|---|---|
| Kentucky | KRS 286.9: предельная сумма и число одновременных сделок, сбор (за обналичивание и за отсрочку), срок, продления, база данных, права заёмщика при просрочке |
| Rhode Island | RIGL 19-14.4: предельная сумма чека, сбор, минимальный срок, число продлений, право на отказ/план, запреты |
| Utah | Utah Code 7-23: срок займа и предел продлений, extended payment plan, раскрытия, запреты, последствия нарушения. Отдельно — **судьба SB 329 (2025)**: принят или нет |

## Ссылки для страниц (ставятся без захода, по решению владельца)

- Kentucky: `https://apps.legislature.ky.gov/law/statutes/chapter.aspx?id=38375` (KRS 286.9),
  регулятор — Kentucky Department of Financial Institutions, `https://kfi.ky.gov/`
- Rhode Island: `https://webserver.rilegislature.gov/Statutes/TITLE19/19-14.4/INDEX.htm`,
  регулятор — Rhode Island Department of Business Regulation, `https://dbr.ri.gov/`
- Utah: `https://le.utah.gov/xcode/Title7/Chapter23/7-23.html`,
  регулятор — Utah Department of Financial Institutions, `https://dfi.utah.gov/`

## Города, округа и параметры

| Город | Округ | SAIPE | Housing | cutoff | H1 |
|---|---|---|---|---|---|
| Lexington | Fayette County | MHIKY21067A052NCEN | DP04ACS021067 | 12:30 pm | зависит от закона |
| Warwick | Kent County | MHIRI44003A052NCEN | DP04ACS044003 | 12:30 pm | зависит от закона |
| Salt Lake City | Salt Lake County | MHIUT49035A052NCEN | DP04ACS049035 | 10:30 am | зависит от закона |

Медианы штатов: `MHIKY21000A052NCEN`, `MHIRI44000A052NCEN`, `MHIUT49000A052NCEN`.
Долг на душу: NY Fed, лист `total`, строки `KY`, `RI`, `UT`.

## Данные на 21 сентября 2026 (обновить при сборке)

- **Fayette County:** 2020 60215 · 2021 61269 · 2022 63667 · 2023 67320 · 2024 71046.
  Медиана KY 2024 — 64481 → разрыв **$6,565 above**. Жилищная нагрузка 32.1%.
- **Kent County (RI):** 2020 82413 · 2021 74282 · 2022 84230 · 2023 89914 · 2024 91417.
  Медиана RI 2024 — 83250 → разрыв **$8,167 above**. Жилищная нагрузка 32.2%.
  Особенность: провал 2021 года, затем три года роста; медиана штата в 2024 снизилась.
- **Salt Lake County:** 2020 79294 · 2021 80676 · 2022 91713 · 2023 94013 · 2024 99008.
  Медиана UT 2024 — 96398 → разрыв **$2,610 above**. Жилищная нагрузка 29.8%.

## Адреса (проверены геокодером)

**Lexington (5, все в Lexington-Fayette):** 1301 Winchester Rd Ste 77 (40505) 6 PM · 1328 Versailles Rd (40504) 6 PM ·
212 E New Circle Rd (40505) 7 PM · 565 E New Circle Rd #10 (40505) 5:30 PM · 671 N Broadway (40508) 5:30 PM.

**Warwick (2):** 775 Bald Hill Rd (02886) 6 PM · 400 Warwick Ave Ste. 2 (02888) 6 PM.
Сняты: 500 Dyer Ave (Cranston), 325 Armistice Blvd (Pawtucket), 1700 Diamond Hill Rd (Woonsocket),
628 Metacom Ave Unit 14 (02885 Warren, адрес не находится).

**Salt Lake City (12 из 14):** в черте города — 1465 State St #9 (84115) 5:30 PM · 1338 S Foothill Dr #195 (84108) 7 PM ·
1645 W 700 N K (84116) 6 PM · 130 W 2100 S Expy (84115) 6 PM. Почтовый SLC, физически другой муниципалитет
округа (оставить с пометкой) — 2120 S State St (84115) 8 PM, 2716 S State St (84115) 6 PM, 243 E 3300 S (84115) 9 PM
(South Salt Lake); 1296 E 3300 S (84106) 8 PM, 757 E 3300 S (84106) 6 PM, 981 E 3300 S (84106) 8 PM (Millcreek);
3514 W 3500 S (84119) 8 PM, 4083 S Redwood Rd (84123) 6 PM (West Valley City).
Сняты: 7045 State St (84047 — Midvale), 10486 S Redwood Rd (South Jordan, 84095).
