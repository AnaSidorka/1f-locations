# Louisiana — verified figures and ready state blocks

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11): payday разрешён и выдаётся.

## Verified legal figures (source: LA Office of Financial Institutions + legis.la.gov, Act 510 / HB 582)

- Governing law: Deferred Presentment and Small Loan Act, R.S. 9:3578, overseen by OFI.
- Statutory maximum deferred presentment: **$700**.
- Current inflation-adjusted maximum: **$740** (period **Sept 1 2026 – Aug 31 2027**). Small loan cap **$370**.
  - Prior period (Sept 2025–Aug 2026) was **$720 / $360** — historical only.
  - **Re-verify ~Sep 1 each year** at ofi.la.gov (new inflation figure supersedes).
- Fee: **16.75%** of the check face; the old $45 dollar cap was **removed** by Act 510 (effective Aug 1 2025).
- APR: **~437%** on a two-week loan at the statutory base (this base is unchanged by the inflation bump).
- Term: up to 30 days; rollovers prohibited.
- Refinancing: allowed only on payment of 25% of principal plus fees each time.
- Extended payment plan: right exists (R.S. 9:3578.4.1); no new loan until repaid.
- Credit reporting: lenders may not report negative payday info to the bureaus.
- Representative example fee: **≈ $124** (16.75% of $740). (Do not use the stale $117/$121.)
- Cutoff for Apply step: **11:30 am**.

## Louisiana city parameters (for Other Ways {{region}} + Apply parish + Authors {{Parish}} + primary ZIP)

| City | Parish | region label | ZIP |
|---|---|---|---|
| Alexandria | Rapides Parish | central Louisiana | 71301 |
| Covington | St. Tammany Parish | the north shore | 70433 |
| Houma | Terrebonne Parish | the Houma-Thibodaux area | 70360 |
| Shreveport | Caddo Parish | northwest Louisiana | 71101 |
| Bossier City | Bossier Parish | the Shreveport-Bossier area | 71111 |
| Lake Charles | Calcasieu Parish | the Lake Charles area | 70601 |
| Monroe | Ouachita Parish | northeast Louisiana | 71201 |
| Ruston | Lincoln Parish | north-central Louisiana | 71270 |
| Opelousas | St. Landry Parish | Acadiana | 70570 |
| Slidell | St. Tammany Parish | the north shore | 70458 |

## Ready state blocks (change only {{City}}/{{region}})

### Loan Products (LA)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A small loan against your next paycheck. You get cash now and pay it all back in one payment on payday, within 30 days under Louisiana law. The fee is a percent of the loan.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in monthly payments, not all at once. It is unsecured and has a set end date. If you need a bigger amount or more time, this is often cheaper than a payday loan.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
```

### Louisiana Law at a Glance
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>Louisiana Law at a Glance</h2>
    <p>These are the payday rules for all of Louisiana, including {{City}}. In plain terms: how much you can get, what it costs, and what happens if you cannot pay on time. Full legal detail is in the <a href="https://1firstcashadvance.org/loans-by-state/louisiana/">Louisiana state guide</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>Louisiana position</th></tr>
      <tr><td>Governing law</td><td>Deferred Presentment and Small Loan Act, R.S. 9:3578, overseen by OFI</td></tr>
      <tr><td>Maximum loan</td><td>$700 by statute, and $740 under the current inflation-adjusted figure</td></tr>
      <tr><td>Fee</td><td>16.75% of the check face, with the old cap now removed</td></tr>
      <tr><td>Rate</td><td>About 437% APR on a two-week loan at the new top end</td></tr>
      <tr><td>Term</td><td>Up to 30 days, with rollovers prohibited</td></tr>
      <tr><td>Refinancing</td><td>Allowed only if you pay 25% of principal plus fees each time</td></tr>
      <tr><td>Payment plan</td><td>Extended plan available, with no new loan until it is repaid</td></tr>
      <tr><td>Credit reporting</td><td>Lenders may not report negative payday information to the bureaus</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example: a top-end payday loan carries a finance charge of about $124, spread across a 14-day term. These are illustrative figures at the current limits, not quoted offers.</p>
  </div>
</section>
```

### Other Ways to Cover an Emergency (LA)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below payday.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call your {{Parish}} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
```

### Borrow Carefully (LA)
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. With the fee cap gone, every extra dollar raises the charge, and approval for more is not a reason to take more.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you cannot repay on time, ask for the extended payment plan rather than refinancing.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="https://ofi.la.gov/">Louisiana Office of Financial Institutions</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```

## Distinct local angles used (keep new cities distinct from these)
- Alexandria — Rapides income varies through the year.
- Covington — St. Tammany is wealthy, so many qualify for the full max.
- Houma — Terrebonne income moves with oil & gas; old figures still online.
- Shreveport — largest NW city, income below the state median.
- Bossier City — Barksdale AFB; military-lending angle in FAQ.
- Monroe — NE commercial hub, income below median.
- Ruston — Louisiana Tech; student population lowers recorded median.
- Opelousas — Acadiana, income below median.
- Slidell — New Orleans commuter suburb; storm-recovery costs.
