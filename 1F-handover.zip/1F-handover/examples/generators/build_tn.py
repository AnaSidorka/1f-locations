#!/usr/bin/env python3
"""Build the five Tennessee city pages (spec v3) into builds/2026-09-17-tn/."""
import html, json, os, re, sys

ROOT = "/workspace"
OUT = os.path.join(ROOT, "builds/2026-09-17-tn")
BASE = os.path.join(ROOT, "builds/Alabama Final/dothan-al-loans-NEW.html")

STATE, ST = "Tennessee", "TN"
DATE, DATE_ISO, CUTOFF = "September 17, 2026", "2026-09-17", "11:30 am"
DEBT = {2020: 44080, 2021: 46900, 2022: 51160, 2023: 53270, 2024: 54720}
STATE_MHI_2024 = 72007

NOTICE = "https://www.tn.gov/content/dam/tn/financialinstitutions/documents/consumer_alert_deferred_presentment_law_change-internet_revised.pdf"
COMPLAINT = "https://www.tn.gov/tdfi/tdfi-how-do-i/file-a-complaint.html"


def hrs(close):
    return f"Open today 8:00 AM &ndash; {close}" if close else "Opens 8:00 AM &middot; call ahead for closing"


CITIES = [
 dict(city="Clarksville", county="Montgomery County", fips="125",
      mhi={2020: 60779, 2021: 63593, 2022: 67478, 2023: 74701, 2024: 78956},
      offices=[("2721 Fort Campbell Blvd", "37042", hrs("6:00 PM")), ("501 Heritage Pointe Dr", "37042", hrs("6:00 PM")),
               ("2170 Wilma Rudolph Blvd", "37040", hrs("6:00 PM")), ("1987 Madison St", "37043", hrs("6:00 PM")),
               ("3281 Fort Campbell Blvd C", "37042", hrs("5:00 PM")), ("989 S Riverside Dr", "37040", hrs("5:30 PM"))],
      p1="Yes. Tennessee lets a licensed lender hold checks worth up to $500 in total, fee included, for as long as 31 days. The fee can reach 15% of the check, which on a two-week loan works out to about 460% APR.",
      p2="Montgomery County income rose in every year shown below, jumping most in 2023, and finished 2024 above the state median. A county average climbing that fast can hide a paycheck that did not, and a payday check is due in full on one date, so time it to pay you already receive.",
      lbl4="Median household income in Montgomery County in 2024, the latest year in the table below",
      growth="County income grew about thirty percent in five years, ahead of about twenty-four for state debt per person.",
      housing="About three in ten households here",
      faq=[("Can an online payday lender lend to me in Tennessee?",
            "Only with a Tennessee license. The Department of Financial Institutions says a lender that gets a consumer located in the state to sign up online, by phone or by fax is doing business here and must be licensed. Check the lender's license before you share your bank details."),
           ("My loan contract says another state's law applies. Does it?",
            "Not for a Tennessee payday loan. A clause that applies another state's law, sends disputes to another state or country, fixes where a case must be heard, or waives the Deferred Presentment Services Act is void. The Tennessee rules still govern the loan."),
           ("How fast could the money reach my account?",
            "If a lender approves you and the application is finalized by 11:30 am local time on a weekday, funds can arrive the same day. Later applications, weekends and bank holidays move funding to the next business day, and same-day deposit is not available to every customer.")]),
 dict(city="Dyersburg", county="Dyer County", fips="045",
      mhi={2020: 50906, 2021: 51499, 2022: 53715, 2023: 57548, 2024: 63008},
      offices=[("2391 Lake Rd", "38024", hrs("5:30 PM")), ("1823 St John Ave", "38024", hrs("5:30 PM"))],
      p1="Yes. The most you can have out is $500 in checks, and because the fee sits inside that figure, the cash tops out near $425. Fees run up to 15% of the check and terms up to 31 days, about 460% APR over two weeks.",
      p2="Dyer County income rose in each year since 2020, with the largest gain coming in 2024, yet it still sat $8,999 under the state median. A fresh raise can make a full repayment look easier than it is, so check the due date against what your budget covers after regular bills, not against the latest increase.",
      lbl4="Median household income in Dyer County in 2024, the most recent year of county data shown below",
      growth="County income grew about twenty-four percent in five years, roughly in step with state debt per person.",
      housing="About one in four households here",
      faq=[("What happens if my check bounces?",
            "The lender can take you to civil court, but it can collect only the face amount of the check and the court costs it actually paid. It cannot add other fees or attorney's fees, and you cannot be convicted under the state's worthless check law over that check."),
           ("How do I check a lender or make a complaint?",
            "Call the Department of Financial Institutions at 1-800-778-4215 or email its Consumer Resources Section. Complaints go through the Department's online form, where you can attach documents, and an examiner reviews each one, usually sending it to the company for a response."),
           ("What should I have ready before I apply?",
            "A photo ID, your Social Security number, a checking account with its routing number and a recent pay stub or other proof of income. You also need proof of a Tennessee address, a working phone and email, and to be at least 18.")]),
 dict(city="Murfreesboro", county="Rutherford County", fips="149",
      mhi={2020: 73980, 2021: 77942, 2022: 77320, 2023: 81987, 2024: 90118},
      offices=[("1660 Middle Tennessee Blvd G", "37130", hrs("6:00 PM")), ("3138 S Church St D", "37127", hrs(None)),
               ("1139 NW Broad St #101A", "37129", hrs("5:30 PM")), ("151 W Northfield Blvd", "37129", hrs("5:30 PM")),
               ("2805 Old Fort Pkwy K", "37128", hrs("5:00 PM")), ("1708 Memorial Blvd", "37129", hrs("6:00 PM")),
               ("133 S Front St", "37130", hrs("5:30 PM"))],
      p1="Yes, under Tennessee's Deferred Presentment Services Act: a fee of no more than 15% of the check's face amount, repayment within 31 days, and a $500 ceiling on all your outstanding checks. Two weeks at the top fee comes to about 460% APR.",
      p2="Rutherford County income slipped in 2022 before two strong years left it $18,111 above the state median in 2024. A dip like 2022 can come back, and Tennessee does not allow a payday loan to be renewed, so if a lean month would leave the check short, borrow less or wait.",
      lbl4="Median household income in Rutherford County in 2024, the highest of the five years in the table below",
      growth="County income grew about twenty-two percent in five years, a little behind state debt per person.",
      housing="Nearly three in ten households here",
      faq=[("Can I have more than one payday loan at a time?",
            "Yes, within limits. One lender can hold no more than two of your checks at once, you can have no more than three loans out in all, and the checks together cannot pass the state's dollar ceiling. A lender that goes over those limits is breaking state law."),
           ("What other small loans are licensed in Tennessee?",
            "The Department of Financial Institutions also licenses flexible credit lenders. A flex loan is an open-end line of credit that may be secured or unsecured, has no fixed end date, and can be paid off early in whole or in part without a penalty."),
           ("Does 1F Cash Advance lend the money?",
            "It does not. 1F Cash Advance is a loan connector: it passes one request to licensed lenders, and the lender that makes an offer sets the terms and funds the loan. Your agreement will name that lender, and that is the company the Tennessee rules on this page apply to.")]),
 dict(city="Nashville", county="Davidson County", fips="037",
      mhi={2020: 64418, 2021: 65463, 2022: 72561, 2023: 80216, 2024: 80803},
      offices=[("3606 Gallatin Pike", "37216", hrs("7:00 PM")), ("1819 Broadway", "37203", hrs("9:00 PM")),
               ("4653 Nolensville Pike", "37211", hrs("6:00 PM")), ("4811 Nolensville Pike", "37211", hrs("6:00 PM")),
               ("800 Jefferson St", "37208", hrs("6:00 PM")), ("6410 Charlotte Pike #103", "37209", hrs("6:00 PM")),
               ("2845 Lebanon Pike", "37214", hrs("6:00 PM")), ("100 Oceanside Dr", "37204", hrs("6:00 PM")),
               ("326 Harding Pl #102", "37211", hrs("6:00 PM")), ("176 Thompson Ln G-3", "37211", hrs("5:30 PM")),
               ("555 Marriott Dr Ste 315", "37214", hrs("8:00 PM"))],
      p1="Yes. Payday lending is licensed in Tennessee, with three hard limits: $500 in outstanding checks, a fee capped at 15% of each check, and no more than 31 days to repay. A two-week loan at that fee equals about 460% APR.",
      p2="Davidson County income climbed through 2023 and then barely moved in 2024. When earnings stall after a run of gains, budgets built on the old trend come up short, so size the check to what this year's pay leaves after rent and fixed bills, not to the growth of past years.",
      lbl4="Median household income in Davidson County in 2024, the highest level in the table below",
      growth="County income rose about twenty-five percent in five years, close to state debt per person.",
      housing="More than a third of households here",
      faq=[("Can I roll my payday loan over into a new one?",
            "Tennessee does not allow it. A payday loan cannot be renewed or folded into a new one, and a loan made that way is void and cannot be enforced. If you cannot repay on the due date, talk to the lender before that date about what it can do."),
           ("What happens after I file a complaint with the state?",
            "An examiner in the Department of Financial Institutions reviews it and may contact you for more information. In most cases the complaint goes to the company for a response. The Department cannot act as your attorney or step into a case already in court."),
           ("Can I apply from my phone?",
            "Yes. The request form works on a phone, stays open around the clock and takes about five minutes. Keep your pay stub and bank details handy, since the lender verifies your income and application details before deciding.")]),
 dict(city="Paris", county="Henry County", fips="079",
      mhi={2020: 41598, 2021: 45980, 2022: 51194, 2023: 52064, 2024: 54189},
      offices=[("1137 E Wood St", "38242", hrs("5:00 PM")), ("1107 Mineral Wells Ave", "38242", hrs("4:30 PM")),
               ("905 E Wood St", "38242", hrs("6:00 PM")), ("1150 Mineral Wells Ave Ste 140", "38242", hrs("5:30 PM"))],
      p1="Yes. Write a check for up to $500 and the lender may keep up to 15% of it as its fee, holding the check for up to 31 days. Stretched across a year, a two-week loan at that fee is about 460% APR.",
      p2="Henry County income grew in every year shown below but still finished 2024 some $17,818 under the state median. On a budget that far below the state's typical household, the full check coming due on one date is the real test, so borrow only what a single paycheck can clear with bills paid.",
      lbl4="Median household income in Henry County in 2024, the latest figure in the table below",
      growth="County income grew about thirty percent across these five years, faster than state debt per person.",
      housing="Just over one in five households here",
      faq=[("Does the lender have to show me every fee before I sign?",
            "Yes. State rules require a disclosure form before any payday transaction that lists each fee and cost that will or could be charged, along with the total. Read it before you sign, and keep a copy with your agreement."),
           ("Does an electronic payment authorization count as a check?",
            "It does. Since 2012 Tennessee's payday law has treated any authorization for an electronic payment the same way as a paper check, so the same limits on fees, terms and renewals apply when you give a lender access to your bank account."),
           ("Does it cost anything to apply through 1F Cash Advance?",
            "The request form is free to use, and prequalifying runs a soft check that does not affect your credit score. Any charges come from the lender whose offer you accept, so read the rate and total cost in that offer before you agree.")]),
]


def slug(c):
    return c.lower().replace(" ", "-") + "-tn-loans"


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build(c):
    base = open(BASE, encoding="utf-8").read()
    head = base[:base.find("</head>")]
    city, county = c["city"], c["county"]
    h1 = f"Payday Loans in {city}, {STATE}"
    title = f"{h1} | 1F Cash Advance"
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)
    assert "<!-- skill-version: v2 -->" in head
    fred_c = f"https://fred.stlouisfed.org/series/MHITN47{c['fips']}A052NCEN"
    fred_s = "https://fred.stlouisfed.org/series/MHITN47000A052NCEN"
    dp04 = f"https://fred.stlouisfed.org/series/DP04ACS047{c['fips']}"
    m24 = c["mhi"][2024]
    gap = STATE_MHI_2024 - m24
    gap_txt = f"{money(abs(gap))} {'below' if gap > 0 else 'above'}"
    gap_lbl = f"How far {county} sat {'under' if gap > 0 else 'above'} the {STATE} median in 2024"

    # Hero (global, fixed) — copied from base, city/state swapped
    hs = base.find('<div class="topbar">'); he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he]
    hero = hero.replace("Payday Loans in Dothan, Alabama", h1).replace("licensed Alabama lender", f"licensed {STATE} lender")
    hero = hero.replace("Updated: September 3, 2026", f"Updated: {DATE}")
    assert "Dothan" not in hero and "Alabama" not in hero

    offices = "".join(
        f'<div class="office-card">\n<p class="office-addr">{html.escape(st)}<br>{city}, {ST} {z}</p>\n'
        f'<p class="office-hours">{hours}</p>\n</div>'
        for st, z, hours in c["offices"])

    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(c['mhi'][y])}</td><td>{money(DEBT[y])}</td><td>{money(round(c['mhi'][y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))

    others = [x["city"] for x in CITIES if x["city"] != city]
    links = " &middot; ".join(f'<a href="https://1firstcashadvance.org/{slug(o)}/">{o}</a>' for o in others)

    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in c["faq"])

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {city} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {city}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A small advance against a personal check you write today. The lender holds the check until the date in your agreement, and you repay the full amount in one payment. It is built for a short gap between paychecks.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in monthly payments, not all at once. It is usually unsecured and has a set end date. If you need a bigger amount or more time, this is often cheaper than a payday loan.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>Where to get payday loan {city}</h2>
    <div class="office-grid">
{offices}
</div>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {city}?</h2>
    <p>{c['p1']}</p>
    <p style="margin-top:14px">{c['p2']}</p>
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {city}: What the Numbers Show</h2>
<div class="stat-grid">
<div class="stat-card"><div class="num gold">Max check</div><div class="lbl">Every check you have out, fee included, counts toward one ceiling set in state law</div><div class="src">Source: <a href="{NOTICE}">Tennessee Department of Financial Institutions consumer notice</a></div></div>
<div class="stat-card"><div class="num navy">Percent of the check</div><div class="lbl">The fee is a share of the check's face amount, not of the cash you walk out with</div><div class="src">Source: <a href="{NOTICE}">Tennessee Department of Financial Institutions consumer notice</a></div></div>
<div class="stat-card"><div class="num navy">Triple-digit</div><div class="lbl">The APR a two-week loan reaches at the state's maximum fee, whatever your income</div><div class="src">Source: <a href="{NOTICE}">Tennessee Department of Financial Institutions consumer notice</a></div></div>
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">{c['lbl4']}</div><div class="src">Source: <a href="{fred_c}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{gap_txt}</div><div class="lbl">{gap_lbl}</div><div class="src">Source: <a href="{fred_s}">Census SAIPE for Tennessee via FRED</a></div></div>
<div class="stat-card"><div class="num navy">No conviction</div><div class="lbl">A borrower cannot be convicted under the state's worthless check law over a payday check</div><div class="src">Source: <a href="{NOTICE}">Tennessee Department of Financial Institutions consumer notice</a></div></div></div>
<p class="tbl-cap">{county} median household income and {STATE} household debt, 2020 to 2024</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{STATE} debt per person</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">County income comes from <a href="{fred_c}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column comes from the <a href="https://www.newyorkfed.org/microeconomics/databank.html">New York Fed Consumer Credit Panel</a>. {c['growth']} <a href="{dp04}">{c['housing']}</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. {STATE} sets a flat ceiling instead of an income test, so the amount does not change with local earnings. The last column is a calculation, not a published figure: monthly county income after the standard housing share. It describes a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>These are the payday rules for all of {STATE}, including {city}. In plain terms: how much you can get, what it costs, and what happens if you cannot pay on time. Full detail is in the <a href="{NOTICE}">Department of Financial Institutions consumer notice</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
      <tr><td>Governing law</td><td>Deferred Presentment Services Act, Tenn. Code Ann. §45-17-101 and following, overseen by the Department of Financial Institutions</td></tr>
      <tr><td>Checks outstanding</td><td>No more than $500 in total face value, with no more than two checks at one lender or three in all</td></tr>
      <tr><td>Fee</td><td>Up to 15% of the check's face amount</td></tr>
      <tr><td>Term</td><td>Up to 31 days</td></tr>
      <tr><td>Renewal</td><td>Not allowed; a renewed or consolidated loan is void and cannot be enforced</td></tr>
      <tr><td>Returned check</td><td>The lender may sue only for the face amount and court costs, with no other fees or attorney's fees</td></tr>
      <tr><td>Worthless check law</td><td>A borrower cannot be convicted under the state's criminal worthless check law</td></tr>
      <tr><td>Online lenders</td><td>Need a Tennessee license to lend to you while you are in the state</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example: a check written at the top of the state limit carries a fee of up to $75, leaving about $425 in cash, and over 14 days that works out to about 460% APR. These are illustrative figures at the current limits, not quoted offers.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {city}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {city} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below payday.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call your {county} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. The fee grows with the amount advanced, so every extra dollar raises the charge.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you see a problem coming, talk to the lender before the date, not after it.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="{COMPLAINT}">Tennessee Department of Financial Institutions</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{city} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>1F Cash Advance in Other {STATE} Cities</h2>
    <p style="max-width:760px">The same {STATE} rules apply statewide. See how they play out where you live:</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
"""
    # Authors (global) — copied from base, county swapped
    a_s = base.rfind("<section", 0, base.find("Who wrote this")); a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e].replace("Houston County", county)
    assert "Dothan" not in authors and "Alabama" not in authors

    url = f"https://1firstcashadvance.org/{slug(city)}/"
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": url, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": "https://1firstcashadvance.org/loans-by-state/tennessee/"}, {"@type": "ListItem", "position": 4, "name": city}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": {"@type": "Person", "name": "Latoria Williams"}, "editor": {"@type": "Person", "name": "Marsha Welch"}, "reviewedBy": {"@type": "Person", "name": "Michael Lefler"}, "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Payday loan matching in {city}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{city}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    for c in CITIES:
        if only and c["city"] not in only:
            continue
        p = os.path.join(OUT, slug(c["city"]) + "-NEW.html")
        open(p, "w", encoding="utf-8").write(build(c))
        print("wrote", p)


if __name__ == "__main__":
    main()
