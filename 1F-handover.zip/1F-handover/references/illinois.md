# Illinois — verified figures and ready state blocks

**H1-режим: вторая форма** — `Short-term loans in {{City}}, {{State}}` (P3-11). Payday не запрещён:
IDFPR по-прежнему лицензирует кредиторов по Payday Loan Reform Act. Но с 23 марта 2021 года
Predatory Loan Prevention Act ограничил все такие займы 36% APR, и почти все дорогие payday-
кредиторы сдали лицензии — это случай Колорадо, а не Джорджии. Заголовок офисов — форма
по умолчанию `Where to get payday loan {{City}}` (P3-5). Can-You-Get открывается словом **Not**.
Отсечка шага 3 — **11:30 am** (полоса LA/TN/AL/IL/TX/MS в P2-12).

## Источники — все открыты 16 сентября 2026

Статуты на `ilga.gov` недоступны (соединение отклоняется) — текст PLPA (815 ILCS 123) и PLRA
(815 ILCS 122) в сессии **не читался**. Всё ниже — со страниц регулятора и генпрокурора.

| Документ | URL | Что даёт |
|---|---|---|
| IDFPR, Consumer Credit Section | https://idfpr.illinois.gov/about/brochures/dfibrochures/consumer-credit.html | 36% APR на займы PLRA и CILA (Public Act 101-0658); CILA до $40,000; займы без лицензии; старые займы; title-залог; телефоны секции |
| IDFPR, Initiatives | https://idfpr.illinois.gov/initiatives.html | «almost every high-cost payday and automobile title lender has surrendered their Illinois license» |
| IDFPR, Consumer Credit (лицензии) | https://idfpr.illinois.gov/dfi/ccd/ccd-main.html | payday-лицензии PLRA выдаются и продлеваются; поиск лицензиатов |
| IDFPR, пресс-релиз о PLPA (30 апр 2021) | https://www.illinois.gov/content/dam/soi/en/web/illinois/iisnewsattachments/23232-idfpr-releases-consumer-frequently-asked-questions-about-the-predatory-loan-prevention-act.pdf | займы выше 36% void; список покрытых займов; интернет и телефон; исключения (банки, credit unions…); куда жаловаться |
| IDFPR, жалобы | https://idfpr.illinois.gov/admin/complaints.html | онлайн-жалоба |
| IDFPR, проверка лицензии | https://idfpr.illinois.gov/checklicense.html | license look-up |
| Генпрокурор, Finance and Credit | https://illinoisattorneygeneral.gov/consumer-protection/finance-and-credit/ | 36% «inclusive of all charges and fees»; горячие линии |
| Генпрокурор, Predatory Lending fact sheet | https://illinoisattorneygeneral.gov/Page-Attachments/PredatoryLoans.pdf | APR по определению Military Lending Act; тревожные признаки; loan flipping; prepayment penalties, balloon payments |

Регуляторы: **Illinois Department of Financial and Professional Regulation (IDFPR), Division of
Financial Institutions, Consumer Credit Section**; **Illinois Attorney General** — защита потребителей.

## Verified figures

| Item | Verified value | Откуда |
|---|---|---|
| Потолок | **36% APR** на все покрытые потребительские займы, включая PLRA (payday) и CILA (installment), с **23 марта 2021** (Public Act 101-0658) | IDFPR CC; AG |
| Что входит в APR | «inclusive of all charges and fees»; определение APR из Military Lending Act | AG page; AG fact sheet |
| Выше потолка | займ **void**: заёмщик не обязан платить, кредитор не может взыскивать principal, fees, interest | IDFPR release 2021; AG fact sheet («illegal except in very narrow circumstances») |
| Займы до 23.03.2021 | выше 36% — **всё равно нужно вернуть** | IDFPR CC (Q&A) |
| Покрытые виды | payday, pawn, installment, title, wage advance products, retail installment contracts, buy-here-pay-here, motor vehicle retail installment contracts, car loans, income share agreements | IDFPR release 2021 |
| Каналы | «made in Illinois using any medium, including the internet and telephone» | IDFPR release 2021 |
| Не применяется | к коммерческим займам и к займам банков, savings banks, S&L, credit unions, страховых | IDFPR release 2021 |
| Payday-кредиторы | лицензия PLRA существует («Payday Lenders make short term loans»); почти все дорогие payday и title сдали лицензии | IDFPR CC; ccd-main; Initiatives |
| Installment | лицензиаты CILA — займы **до $40,000** | IDFPR CC |
| Без лицензии | если кредитор обязан иметь лицензию и её нет, заёмщик **может не возвращать** заём | IDFPR CC |
| Title-залог | при security interest кредитор может забрать машину при дефолте | IDFPR CC (Q&A) |
| Телефоны | IDFPR Consumer Credit: **312-814-5145** (Chicago), **217-785-4244** (Springfield); AG: **1-800-386-5438** (Chicago), **1-800-243-0618** (Springfield), **1-800-243-0607** (Carbondale) | IDFPR CC; AG page |

### NOT verified — do not publish

- **Лимиты Payday Loan Reform Act**: $1,000 или 25% валового месячного дохода, срок 13–45 дней,
  перерыв 7 дней после 45 дней в долгу, база займов. Текст закона не открывался (ilga.gov
  недоступен). Внутренний гид их печатает — на городские страницы они **не идут**.
  Отсюда и строка под таблицей статистики: **не писать** «flat ceiling instead of an income test» —
  у payday-займа по PLRA, по всей видимости, есть тест по доходу, а проверить его нельзя.
- NSF-сбор $25 (из внутреннего гида) — не подтверждён у регулятора.
- Число лицензиатов и суммы штрафов из отчётов IDFPR — не открывались.

### Внутренний гид

https://1firstcashadvance.org/loans-by-state/illinois/ («Illinois Installment Loans | Payday Loans |
1F Cash Advance», обновлён August 14, 2026) совпадает с регулятором по 36% и void, но добавляет
непроверенные лимиты PLRA. В блоке закона ссылка ведёт на страницу IDFPR.

### Ловушки

1. **Не «payday запрещён».** Закон его не запрещает, запрещена цена выше 36%. Пиши «Not the
   high-cost kind», а не «illegal».
2. **Void — только для займов с 23 марта 2021.** Старые займы нужно возвращать.
3. **Банки и credit unions — вне PLPA.** Не пиши, что потолок действует «на любой заём».

## Illinois city parameters

Округа подтверждены заголовками серий FRED 16 сентября 2026.

| City | County | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Belleville | St. Clair County | MHIIL17163A052NCEN | DP04ACS017163 | 11:30 am |
| Champaign | Champaign County | MHIIL17019A052NCEN | DP04ACS017019 | 11:30 am |
| Decatur | Macon County | MHIIL17115A052NCEN | DP04ACS017115 | 11:30 am |
| Peoria | Peoria County | MHIIL17143A052NCEN | DP04ACS017143 | 11:30 am |
| Rockford | Winnebago County | MHIIL17201A052NCEN | DP04ACS017201 | 11:30 am |
| Springfield | Sangamon County | MHIIL17167A052NCEN | DP04ACS017167 | 11:30 am |

Медиана штата: `MHIIL17000A052NCEN`. Долг на душу: NY Fed area report, лист `total`, строка `IL`.

- **Rockford** заходит в Ogle County (Census 2020 place-by-county), но все офисы — в Winnebago.
  Ряд — Winnebago County. Долей населения не утверждать.
- **Decatur — омоним:** Decatur, IL (Macon County) ≠ Decatur, GA (DeKalb County). Слаг
  `decatur-il-loans`.
- **ZIP 61610** — Creve Coeur (Tazewell County), не Peoria.

## Ready state blocks (change only {{City}}/{{County}})

### Loan Products (IL) — exactly 2 cards
Ссылка каждой карточки дословно `Explore Now &rarr;`, без повтора названия продукта (§1d, P3-12). Сумм и ставки в карточках нет —
бюджет `$40,000` и `36%` израсходован ¶1 и таблицей закона.
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Short-Term Loans</h3>
        <p>A smaller loan for a short gap, made by a lender licensed in Illinois. The schedule is set when you sign, so ask for each payment date and the total cost in dollars before you agree.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>For a bigger need, an installment loan spreads repayment over a longer schedule with fixed payments. Ask for the total cost of credit in dollars and compare that figure across offers.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a></div>
    </div>
  </div>
</section>
```

### Illinois Law at a Glance — 8 rows из 8, ноль меток `§`
Вхождения: `36%` и `$40,000` — по 1 (второе — в ¶1 Can-You-Get, запас 0).
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>Illinois Law at a Glance</h2>
    <p>These are the small-loan rules for all of Illinois, including {{City}}. Full detail is on the <a href="https://idfpr.illinois.gov/about/brochures/dfibrochures/consumer-credit.html">Department of Financial and Professional Regulation consumer credit page</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>Illinois position</th></tr>
      <tr><td>Rate cap</td><td>36% APR on most consumer loans, including payday, title and installment loans, since March 23, 2021</td></tr>
      <tr><td>What the rate includes</td><td>Fees and charges, measured under the broad Military Lending Act definition</td></tr>
      <tr><td>Loans above the cap</td><td>Void: the lender cannot collect principal, fees or interest on a covered loan made after March 23, 2021</td></tr>
      <tr><td>Loans made earlier</td><td>Loans taken out before March 23, 2021 still have to be repaid</td></tr>
      <tr><td>Payday lenders</td><td>Still licensed under the Payday Loan Reform Act, though almost every high-cost payday lender has surrendered its license</td></tr>
      <tr><td>Installment loans</td><td>Licensed consumer installment lenders make loans of up to $40,000</td></tr>
      <tr><td>Unlicensed lenders</td><td>Borrowers may not have to repay a lender that needed a license and did not hold one</td></tr>
      <tr><td>Where to report it</td><td>The Department of Financial and Professional Regulation or the Attorney General's consumer hotline</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">The cap is a ceiling, not a price: a licensed lender may charge less, so ask for the APR and the total cost in dollars before you sign.</p>
  </div>
</section>
```

### Other Ways to Cover an Emergency (IL)
Форма NC: PAL (§8 дословно) / Bank small-dollar / Employer / Utility с `{{County}}` и LIHEAP.

### Borrow Carefully (IL)
Форма NC; закрывающая ссылка — https://idfpr.illinois.gov/admin/complaints.html
(«Illinois Department of Financial and Professional Regulation»).

### Шесть стат-карточек — правовые (1–3, 6) одинаковы по штату
| # | `.num` | Источник |
|---|---|---|
| 1 | `Licenses handed back` | IDFPR Initiatives |
| 2 | `Fees count` | AG fact sheet |
| 3 | `Rate-capped` | IDFPR Consumer Credit Section |
| 6 | `Void above the cap` | IDFPR PLPA release 2021 |

### Строка под таблицей статистики (п. 2 из §5c)
`Illinois limits what a covered loan can cost, and the lender still decides how much to offer,
so the rate cap alone does not tell you what fits your budget.` — ни «flat ceiling», ни «income
test»: для IL не проверено ни то, ни другое.

## Distinct local angles (из таблицы SAIPE)
- Belleville / St. Clair — спад в 2023, самый большой годовой рост в 2024.
- Champaign / Champaign — спад в 2021, в 2024 чуть ниже 2020.
- Decatur / Macon — резкий спад в 2021, затем три года роста.
- Peoria / Peoria — скачок в 2022, спад в 2023, максимум в 2024.
- Rockford / Winnebago — рост каждый год.
- Springfield / Sangamon — небольшой спад в 2023, максимум в 2024, ближе всех к медиане штата.
