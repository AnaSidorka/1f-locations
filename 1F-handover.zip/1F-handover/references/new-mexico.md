# New Mexico — verified figures and ready state blocks

**H1-режим: третья форма** — `Payday loan alternatives in {{City}}, {{State}}` (P3-11), **решение
владельца 17 сентября 2026**. Заголовок офисов — `Where to get payday loan alternatives in {{City}}`.
Can-You-Get открывается словом **No**.

**Отсечка шага 3 — 10:30 am** (решение владельца 17 сентября 2026, внесено в P2-12, §2 спеки и чек-лист).

## Источники — открыты 17 сентября 2026

Сайт легислатуры `nmlegis.gov` (HB 347 2017, HB 132 2023) отдаёт 403, сайт генпрокурора `nmag.gov` —
Cloudflare. Текст Small Loan Act в сессии **не читался**. Цифры — от регулятора и из официального
административного кодекса.

| Документ | URL | Что даёт |
|---|---|---|
| FID, Small Loan Companies | https://www.rld.nm.gov/financial-institutions/who-we-regulate/small-loan-companies/ | займы до $10,000; лицензия; банки и credit unions исключены; продукты; определение installment loan |
| FID, FAQs (Small Loan Company) | https://www.rld.nm.gov/financial-institutions/about-us/faqs/ | NM-APR 36% / 36% + 5%; с 01.01.2023; TIL-APR vs NM-APR; tribal и offshore; жалобы |
| 12.18.3 NMAC — обязательная брошюра | https://www.srca.nm.gov/parts/title12/12.018.0003.html | брошюра у входа, термины, лимиты NM-APR |
| 12.18.4 NMAC — обязательная вывеска (ред. 29.03.2023) | https://www.srca.nm.gov/parts/title12/12.018.0004.html | вывеска с APR и всеми сборами, в офисе и на сайте; контакт для жалоб; FID (505) 476-4885 |
| FID, File a Complaint | https://www.rld.nm.gov/financial-institutions/file-a-complaint/ | форма жалобы |

Регулятор: **New Mexico Regulation and Licensing Department, Financial Institutions Division (FID)**.

## Verified figures

| Item | Verified value | Откуда |
|---|---|---|
| Кого лицензирует | small loan companies — займы **$10,000 или меньше**; лицензия ежегодная; New Mexico Small Loan Act of 1955, §58-15-1 et seq. | FID SLC |
| Исключены | банки и credit unions — от требований Small Loan Act | FID SLC |
| Продукты лицензиатов | short-term installment loans, refund anticipation loans, small dollar business loans | FID SLC |
| Installment loan | до $10,000, **не меньше четырёх** примерно равных платежей, первоначальный срок **не меньше 120 дней**; RAL — не installment | FID SLC (§58-15-2(F)) |
| NM-APR, заём больше $500 и до $10,000 | не больше **36%** | FID FAQ; 12.18.3/12.18.4 NMAC |
| NM-APR, заём $500 или меньше | **36%** плюс сбор до **5%** основного долга, **не чаще раза в 12 месяцев** | там же |
| С какой даты | для займов с **1 января 2023** | FID FAQ |
| Два APR | TIL-APR по федеральному закону и NM-APR, который может включать дополнительные сборы | FID FAQ; NMAC |
| Условия | окончательные условия и APR — при подаче заявки, по заявке и кредитной информации; не все получают минимальную ставку | FID FAQ; 12.18.4.8 |
| Tribal и offshore | иностранные компании и Native American lenders на землях племён **не подпадают** под эти законы | FID FAQ |
| Брошюра | в каждой точке, стойка у главного входа, всегда заполнена | 12.18.3.8 |
| Вывеска | в каждой точке: APR и **список всех сборов**, контакт для жалоб в компании, контакты FID; то же — ссылкой на сайте, в соцсетях и приложениях | 12.18.4.8 |
| Жалобы | форма FID; телефон **(505) 476-4885**; FID не регулирует federally chartered банки, S&L и credit unions | 12.18.4.8; FID FAQ |

### NOT verified — do not publish

- **Что payday исключён из закона** (HB 347, 2017) — первоисточник не открылся. На страницах форма 3
  по решению владельца, но формулировки опираются на проверенное: лицензиаты выдают installment,
  RAL и бизнес-займы; действует потолок NM-APR. Не писать «illegal» и «banned by law».
- Текст HB 132 (2023) и штрафы за нарушения.
- Late fee «5%, не больше $10» из внутреннего гида.

### Внутренний гид — ссылку не ставить

https://1firstcashadvance.org/loans-by-state/new-mexico/ («Installment Loans in New Mexico», обновлён
September 8, 2026) верно даёт 36% с 1 января 2023 для займов до $10,000, но описывает payday как заём
«repayment is made in a single lump sum… best when you need fast access to cash» — это противоречит
определению installment loan и третьей форме страницы; late fee не подтверждён.

## New Mexico city parameters

| City | County | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Albuquerque | Bernalillo County | MHINM35001A052NCEN | DP04ACS035001 | 10:30 am |
| Clovis | Curry County | MHINM35009A052NCEN | DP04ACS035009 | 10:30 am |
| Gallup | McKinley County | MHINM35031A052NCEN | DP04ACS035031 | 10:30 am |
| Las Cruces | Doña Ana County | MHINM35013A052NCEN | DP04ACS035013 | 10:30 am |

Медиана штата: `MHINM35000A052NCEN`. Долг на душу: NY Fed, лист `total`, строка `NM`.
Все четыре города — целиком в одном округе (Census 2020 place-by-county).

## Ready state blocks

Форма — как у North Carolina (третья форма): Products = Installment Loans + Personal Loans.

### New Mexico Law at a Glance — 8 rows из 8, одна метка `§`
Вхождения: `$10,000`, `36%` — по 1 (второе — ¶1); `$500` — 2; `5%` — 1.
```html
<tr><td>Payday loans</td><td>Not among the products licensed small loan companies offer; they make installment, tax refund and small business loans</td></tr>
<tr><td>Small loan license</td><td>Required for loans of $10,000 or less under the Small Loan Act, §58-15-1 and following; banks and credit unions are exempt</td></tr>
<tr><td>Installment loans</td><td>At least four substantially equal payments, with at least 120 days to maturity</td></tr>
<tr><td>Rate cap</td><td>36% NM-APR on loans above $500, for loans made since January 1, 2023</td></tr>
<tr><td>Loans of $500 or less</td><td>The same cap plus a fee of up to 5% of principal, charged no more than once in 12 months</td></tr>
<tr><td>NM-APR</td><td>Can include charges the federal APR leaves out, and both figures must be disclosed</td></tr>
<tr><td>Posted rates and fees</td><td>Each licensed office and lender website must show the APR and a list of all fees</td></tr>
<tr><td>Where to report it</td><td>The Financial Institutions Division, (505) 476-4885</td></tr>
```

### Other Ways — карточка Utility для NM
LIHEAP через community action agency в NM не проверен. Текст:
`If the problem is an electric or gas bill, call the utility and ask about a payment plan and LIHEAP energy assistance for {{County}} households. That is assistance, not a loan. Call before a shutoff.`

### Шесть стат-карточек — правовые (1–3, 6)
| # | `.num` | Источник |
|---|---|---|
| 1 | `Installment instead` | FID Small Loan Companies |
| 2 | `State ceiling` | FID Small Loan Companies |
| 3 | `Capped since 2023` | 12.18.4 NMAC |
| 6 | `Posted in full` | 12.18.4 NMAC |

## Distinct local angles (из таблицы SAIPE)
- Albuquerque / Bernalillo — рост каждый год, выше медианы штата.
- Clovis / Curry — спад в 2021, к уровню 2020 вернулся только в 2023; рост за 5 лет ≈6%.
- Gallup / McKinley — спад в 2023; самый большой разрыв со штатом.
- Las Cruces / Doña Ana — 2021 без изменений, затем три года роста.
