#!/usr/bin/env python3
"""Build the five South Carolina city pages (spec v3) into builds/2026-09-17-sc/."""
import html, json, os, re, sys

ROOT = "/Users/bamer/Downloads/VS CODE/1F Locations"
OUT = os.path.join(ROOT, "builds/2026-09-17-sc")
BASE = os.path.join(ROOT, "builds/Alabama Final/dothan-al-loans-NEW.html")

STATE, ST = "South Carolina", "SC"
DATE, DATE_ISO, CUTOFF = "September 17, 2026", "2026-09-17", "12:30 pm"
DEBT = {2020: 46950, 2021: 49630, 2022: 53410, 2023: 55610, 2024: 56630}
STATE_MHI_2024 = 72507

CODE = "https://www.scstatehouse.gov/code/t34c039.php"


def hrs(close):
    return f"Open today 8:00 AM &ndash; {close}" if close else "Opens 8:00 AM &middot; call ahead for closing"


def ask(q, a):
    return (q, a)


CITIES = [
 dict(city="Anderson", county="Anderson County", fips="007",
      mhi={2020: 52667, 2021: 58951, 2022: 62708, 2023: 64813, 2024: 69775},
      offices=[("1705 N Main St", "29621", hrs("6:00 PM")), ("2705 N Main St Ste D", "29621", hrs(None)),
               ("3300 N Main St G", "29621", hrs("5:30 PM")), ("3310 N Main St", "29621", hrs("6:00 PM"))],
      p1="Yes. A licensed lender here can advance up to $550 against your check, charge a fee of no more than 15% of that amount, and hold the check for up to 31 days, which comes to about 391% APR over two weeks.",
      p2="Anderson County income rose in every year shown below and ended 2024 within $2,732 of the state median. Steady gains can make one payment feel easy, but the state allows only one payday loan at a time, so there is no second advance to lean on if this one falls short; borrow what one paycheck repays.",
      lbl4="Median household income in Anderson County in 2024, the latest year in the table below",
      growth="County income grew about thirty-two percent in five years, ahead of state debt per person.",
      housing="Fewer than one in four households here",
      faq=[ask("What happens if my check bounces?",
               "The lender cannot add a returned-check charge, and South Carolina law says you are not criminally liable for a check written under a payday agreement. The lender can still pursue the balance through civil means, so contact it before the due date if the money will not be there."),
           ask("Can the lender ask for collateral or a co-signer?",
               "A lender licensed for payday advances may not require security for the loan or a guaranty from another person. The advance rests on your own check, so a request for a car title, a co-signer or any other guarantee is a request state law does not allow."),
           ask("How fast could the money reach my account?",
               "If a lender approves you and the application is finalized by 12:30 pm local time on a weekday, funds can arrive the same day. Later applications, weekends and bank holidays move funding to the next business day, and same-day deposit is not available to every customer.")]),
 dict(city="Florence", county="Florence County", fips="041",
      mhi={2020: 47429, 2021: 52062, 2022: 52650, 2023: 56144, 2024: 61320},
      offices=[("2204 2nd Loop Rd G", "29501", hrs("6:00 PM")), ("1359 S Irby St", "29505", hrs("6:00 PM")),
               ("2035 W Lucas St", "29501", hrs("6:00 PM")), ("703 S Irby St", "29501", hrs("6:00 PM"))],
      p1="Yes. South Carolina allows one payday advance at a time, capped at $550 before the fee. The fee tops out at 15% of the amount advanced, the term runs no longer than 31 days, and a two-week loan prices near 391% APR.",
      p2="Florence County income grew in each year after 2020 but still ended 2024 some $11,187 under the state median. On a budget below the state's typical household, paying the whole balance on one date is the hard part, so if that date already looks tight, ask for the extended payment plan before it arrives, not after.",
      lbl4="Median household income in Florence County in 2024, the most recent year of county data shown below",
      growth="County income grew about twenty-nine percent in five years, against about twenty-one for state debt per person.",
      housing="Nearly three in ten households here",
      faq=[ask("Can I take out a new payday loan the same day I repay one?",
               "Not on the same business day. From your eighth loan in a calendar year, you have to wait until the second business day after repaying. Every lender checks a statewide database before approving, so the rule applies even if you go to a different lender."),
           ask("Can I use a counter check from my bank?",
               "A licensed lender cannot accept one. South Carolina law requires the check to carry your name preprinted on its face, so bring a check from your own checkbook, drawn on an open and active account."),
           ask("Does 1F Cash Advance lend the money?",
               "It does not. 1F Cash Advance is a loan connector: it passes one request to licensed lenders, and the lender that makes an offer sets the terms and funds the loan. Your agreement will name that lender, and that is the company the South Carolina rules on this page apply to.")]),
 dict(city="Greenville", county="Greenville County", fips="045",
      mhi={2020: 62475, 2021: 68487, 2022: 71833, 2023: 76281, 2024: 82531},
      offices=[("3280 N Pleasantburg Dr B", "29609", hrs("6:00 PM")), ("119 State Park Rd", "29609", hrs("6:00 PM")),
               ("6304 White Horse Rd Ste B6", "29611", hrs("5:30 PM"))],
      p1="Yes, within tight limits: $550 is the most one advance can be, the fee cannot pass 15% of it, and the check can be held for 31 days at most. Over a two-week term, that fee equals about 391% APR.",
      p2="Greenville County income climbed each year from 2020 to 2024 and finished above the state median, but the advance limit is the same for every borrower. A bigger local paycheck does not unlock a bigger loan, so if you need more than one advance covers, compare an installment loan first.",
      lbl4="Median household income in Greenville County in 2024, the latest figure in the table below",
      growth="County income rose nearly a third over these five years, faster than state debt per person.",
      housing="More than a quarter of households here",
      faq=[ask("How does the extended payment plan work?",
               "Ask for it before the loan is due and sign an amendment to your agreement. You then repay in at least four roughly equal installments, each timed to a day you get paid, with no added interest or fees. You can use it once every 12 months, and you can pay it off early."),
           ask("Why does the lender check a database before approving me?",
               "State law requires every lender to confirm you have no open payday loan and meet the timing rules. The database answers only eligible or ineligible with a reason, and you can ask its operator for a fuller explanation. A lender may charge you half of the check's fee, and the full fee cannot exceed $1."),
           ask("Can I apply from my phone?",
               "Yes. The request form works on a phone, stays open around the clock and takes about five minutes. Keep your pay stub and bank details handy, since the lender verifies your income and application details before deciding.")]),
 dict(city="Greenwood", county="Greenwood County", fips="047",
      mhi={2020: 43711, 2021: 52462, 2022: 49867, 2023: 56726, 2024: 57337},
      offices=[("805J Montague Ave", "29649", hrs(None)), ("220 By-pass 72 NW Ste B", "29649", hrs("5:30 PM")),
               ("504 By-pass 72 NW", "29649", hrs("6:00 PM")), ("564 By-pass 72 NW", "29649", hrs("6:00 PM"))],
      p1="Yes. Payday loans are legal in South Carolina with a $550 ceiling on the advance, a fee of up to 15% charged once, and repayment within 31 days; on a two-week loan the maximum fee works out to roughly 391% APR.",
      p2="Greenwood County income jumped in 2021, fell back in 2022 and then rose again. A swing like that can leave a household short on the exact day a check is due, so line the due date up with a paycheck you are sure of, and use the free cancellation window if the timing looks wrong the next morning.",
      lbl4="Median household income in Greenwood County in 2024, the highest of the five years in the table below",
      growth="County income grew about thirty-one percent in five years, well ahead of state debt per person.",
      housing="Close to three in ten households here",
      faq=[ask("Can the lender change the date on my check?",
               "A licensed lender may not alter or remove the date, and it cannot take a check that is undated or dated for any day other than the day it accepts it. The repayment date belongs in your written agreement instead."),
           ask("What if a lender charged me more than the law allows?",
               "The State Board of Financial Institutions can order the lender to repay unlawful or excessive fees and can fine it up to $1,000 for each violation. Keep your agreement and receipts, since they show the fee in dollars and as an APR, and file a complaint with the Board."),
           ask("What should I have ready before I apply?",
               "A photo ID, your Social Security number, a checking account with its routing number and a recent pay stub or other proof of income. You also need proof of a South Carolina address, a working phone and email, and to be at least 18.")]),
 dict(city="North Augusta", county="Aiken County", fips="003",
      mhi={2020: 57128, 2021: 56711, 2022: 67728, 2023: 67769, 2024: 71314},
      offices=[("109 E Marion Ave", "29841", hrs("6:00 PM")), ("1698 Knox Ave", "29841", hrs("6:00 PM")),
               ("416 E Martintown Rd", "29841", hrs("6:00 PM")), ("416-B E Martintown Rd", "29841", hrs("6:00 PM"))],
      p1="Yes. Think of the state rules as three caps: $550 on the advance itself, 15% of it on the fee, and 31 days on how long the lender holds your check. On a two-week loan the full fee comes to about 391% APR.",
      p2="Aiken County income dipped in 2021, jumped in 2022 and held almost flat in 2023, ending 2024 just $1,193 under the state median. A flat year can follow a good one, and South Carolina allows no renewal if the check comes due short, so size the advance to the pay you have now.",
      lbl4="Median household income in Aiken County in 2024, the highest level in the table below",
      growth="County income grew about twenty-five percent in five years, a little ahead of state debt per person.",
      housing="Just over one in five households here",
      faq=[ask("Can I cancel a payday loan after I sign?",
               "Yes. South Carolina gives you until the close of the following business day to cancel the loan at no cost. If you change your mind, act before that deadline passes."),
           ask("Does the lender have to show its fees up front?",
               "Yes. Every licensed location must post a notice of the fee it charges and file its fees with the State Board of Financial Institutions. Your written agreement must also state the total fee both in dollars and as an annual percentage rate."),
           ask("What else can a payday office sell me?",
               "Very little. A licensed location may offer money orders, postage stamps, utility bill payments with no added fee, wire transfers, fax service, postal box rentals and vending machines, but it may not sell other goods or services on site.")]),
]


def slug(c):
    return c.lower().replace(" ", "-") + "-sc-loans"


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build(c):
    base = open(BASE, encoding="utf-8").read()
    head = base[:base.find("</head>")]
    city, county = c["city"], c["county"]
    h1 = f"Payday Loans in {city}, {STATE}"
    title = f"{h1} | 1F Cash Advance"
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)
    assert "<!-- skill-version: v2 -->" in head
    fred_c = f"https://fred.stlouisfed.org/series/MHISC45{c['fips']}A052NCEN"
    fred_s = "https://fred.stlouisfed.org/series/MHISC45000A052NCEN"
    dp04 = f"https://fred.stlouisfed.org/series/DP04ACS045{c['fips']}"
    m24 = c["mhi"][2024]
    gap = STATE_MHI_2024 - m24
    gap_txt = f"{money(abs(gap))} {'below' if gap > 0 else 'above'}"
    gap_lbl = f"How far {county} sat {'under' if gap > 0 else 'above'} the {STATE} median in 2024"

    # Hero (global, fixed) — copied from base, city/state swapped
    hs = base.find('<div class="topbar">'); he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he]
    hero = hero.replace("Payday Loans in Dothan, Alabama", h1).replace("licensed Alabama lender", f"licensed {STATE} lender")
    hero = hero.replace("Updated: September 3, 2026", f"Updated: {DATE}")
    assert "Dothan" not in hero and "Alabama" not in hero

    offices = "".join(
        f'<div class="office-card">\n<p class="office-addr">{html.escape(st)}<br>{city}, {ST} {z}</p>\n'
        f'<p class="office-hours">{hours}</p>\n</div>'
        for st, z, hours in c["offices"])

    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(c['mhi'][y])}</td><td>{money(DEBT[y])}</td><td>{money(round(c['mhi'][y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))

    others = [x["city"] for x in CITIES if x["city"] != city]
    links = " &middot; ".join(f'<a href="https://1firstcashadvance.org/{slug(o)}/">{o}</a>' for o in others)

    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in c["faq"])

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {city} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {city}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A small advance against a personal check you write today. The lender holds the check until the date in your agreement, and you repay the full amount in one payment. It is built for a short gap between paychecks.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in monthly payments, not all at once. It is usually unsecured and has a set end date. If you need a bigger amount or more time, this is often cheaper than a payday loan.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>Where to get payday loan {city}</h2>
    <div class="office-grid">
{offices}
</div>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {city}?</h2>
    <p>{c['p1']}</p>
    <p style="margin-top:14px">{c['p2']}</p>
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {city}: What the Numbers Show</h2>
<div class="stat-grid">
<div class="stat-card"><div class="num gold">Max advance</div><div class="lbl">One advance at a time, capped by statute, with the fee charged on top of that amount</div><div class="src">Source: <a href="{CODE}">S.C. Code Title 34, Chapter 39</a></div></div>
<div class="stat-card"><div class="num navy">Charged once</div><div class="lbl">The percentage fee can be charged only one time for each written loan agreement</div><div class="src">Source: <a href="{CODE}">S.C. Code Title 34, Chapter 39</a></div></div>
<div class="stat-card"><div class="num navy">Triple-digit</div><div class="lbl">The APR a two-week loan reaches at the state's maximum fee, whatever your income</div><div class="src">Source: <a href="{CODE}">S.C. Code Title 34, Chapter 39</a></div></div>
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">{c['lbl4']}</div><div class="src">Source: <a href="{fred_c}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{gap_txt}</div><div class="lbl">{gap_lbl}</div><div class="src">Source: <a href="{fred_s}">Census SAIPE for South Carolina via FRED</a></div></div>
<div class="stat-card"><div class="num navy">Next-day cancel</div><div class="lbl">You can cancel a new loan at no cost by the close of the following business day</div><div class="src">Source: <a href="{CODE}">S.C. Code Title 34, Chapter 39</a></div></div></div>
<p class="tbl-cap">{county} median household income and {STATE} household debt, 2020 to 2024</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{STATE} debt per person</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">County income comes from <a href="{fred_c}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column comes from the <a href="https://www.newyorkfed.org/microeconomics/databank.html">New York Fed Consumer Credit Panel</a>. {c['growth']} <a href="{dp04}">{c['housing']}</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. {STATE} sets a flat ceiling instead of an income test, so the amount does not change with local earnings. The last column is a calculation, not a published figure: monthly county income after the standard housing share. It describes a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>These are the payday rules for all of {STATE}, including {city}. In plain terms: how much you can get, what it costs, and what happens if you cannot pay on time. Full legal text is in <a href="{CODE}">S.C. Code Title 34, Chapter 39</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
      <tr><td>Governing law</td><td>Deferred Presentment Services Act, S.C. Code §34-39-110 and following, overseen by the State Board of Financial Institutions</td></tr>
      <tr><td>Maximum advance</td><td>$550 at one time, not counting the fee</td></tr>
      <tr><td>Fee</td><td>Up to 15% of the amount advanced, charged once per agreement</td></tr>
      <tr><td>Term</td><td>Up to 31 days</td></tr>
      <tr><td>One loan at a time</td><td>Checked against a statewide database, and no new loan on the day an old one is repaid</td></tr>
      <tr><td>Renewal</td><td>Not allowed, and a loan cannot be paid off with a new check to the same lender</td></tr>
      <tr><td>Returned check</td><td>No returned-check charge and no criminal liability for you; the lender may still collect through civil court</td></tr>
      <tr><td>Trouble repaying</td><td>One extended payment plan every 12 months, in at least four equal installments at no extra cost</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example: an advance at the top of the state limit carries a fee of up to $82.50, which works out to about 391% APR over 14 days. These are illustrative figures at the current limits, not quoted offers.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {city}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {city} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below payday.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call your {county} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. The fee grows with the amount advanced, so every extra dollar raises the charge.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you see a problem coming, talk to the lender before the date, not after it.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the South Carolina State Board of Financial Institutions, Consumer Finance Division, or the federal CFPB.</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{city} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>1F Cash Advance in Other {STATE} Cities</h2>
    <p style="max-width:760px">The same {STATE} rules apply statewide. See how they play out where you live:</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
"""
    # Authors (global) — copied from base, county swapped
    a_s = base.rfind("<section", 0, base.find("Who wrote this")); a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e].replace("Houston County", county)
    assert "Dothan" not in authors and "Alabama" not in authors

    url = f"https://1firstcashadvance.org/{slug(city)}/"
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": url, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": "https://1firstcashadvance.org/loans-by-state/south-carolina/"}, {"@type": "ListItem", "position": 4, "name": city}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": {"@type": "Person", "name": "Latoria Williams"}, "editor": {"@type": "Person", "name": "Marsha Welch"}, "reviewedBy": {"@type": "Person", "name": "Michael Lefler"}, "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Payday loan matching in {city}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{city}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    for c in CITIES:
        if only and c["city"] not in only:
            continue
        p = os.path.join(OUT, slug(c["city"]) + "-NEW.html")
        open(p, "w", encoding="utf-8").write(build(c))
        print("wrote", p)


if __name__ == "__main__":
    main()
