# North Carolina — verified figures and ready state blocks

**H1-режим: третья форма** — `Payday loan alternatives in {{City}}, {{State}}` (P3-11):
payday-кредиторы из штата выведены, законного payday-продукта нет. Can-You-Get открывается
словом **No**. Заголовок офисов — `Where to get payday loan alternatives in {{City}}` (P3-5).

**Отсечка шага 3 блока Apply сохраняется: `12:30 pm`.** В отличие от Джорджии, NC прямо
записан в полосе P2-12 (OH/NC/SC/RI/VA).

## Источники — все открыты 16 сентября 2026

Статуты на `ncleg.gov` / `ncleg.net` (и зеркала Justia, FindLaw) закрыты Cloudflare —
текст G.S. 53-176, 53-281, 24-1.1 в сессии **не читался**. Всё ниже — со страниц регулятора
и генпрокурора, которые открываются.

| Документ | URL | Что даёт |
|---|---|---|
| NCCOB, Consumer Finance FAQ | https://nccob.nc.gov/financial-institutions/consumer-finance/frequently-asked-questions | потолок, срок, ставки, 8%, late fee, deferral, лицензия servicer |
| NCCOB, Consumer Finance | https://nccob.nc.gov/financial-institutions/consumer-finance | «loans of $25,000 or less», «small personal loans» |
| NCCOB, Maximum Rate of Interest | https://nccob.nc.gov/news-research/maximum-rate-interest | 16% на некоторые займы ≤ $25,000 без лицензии CFA, с 1984 |
| NCCOB, жалобы | https://nccob.nc.gov/consumer-information/consumer-inquiries-and-complaint-information | онлайн-форма жалобы |
| NCDOJ, Payday Loans | https://ncdoj.gov/protecting-consumers/credit-and-debt/payday-loans/ | «Payday Lenders: Shut Down In NC», онлайн-риски, отзыв ACH, 1-877-5-NO-SCAM, альтернативы |
| NCDOJ, пресс-релиз 22 фев 2024 | https://ncdoj.gov/attorney-general-stein-fights-to-protect-north-carolinians-from-high-interest-loans/ | «kicked predatory, payday, and car title lenders out of North Carolina years ago»; 33% для лицензиатов |
| NCDOJ, пресс-релиз 27 янв 2020 | https://ncdoj.gov/attorney-general-josh-stein-wins-825000-settlement-against-out-of-state-payday-lender/ | иск к онлайн-кредитору: возвраты и списание займов |

Регуляторы: **North Carolina Office of the Commissioner of Banks (NCCOB)** лицензирует
consumer finance; **North Carolina Department of Justice (Attorney General)** — защита
потребителей и payday.

## Verified figures

### Payday
| Item | Verified value | Откуда |
|---|---|---|
| Статус | payday-кредиторы **выведены из штата** («Shut Down In NC»; «kicked … out of North Carolina years ago») | NCDOJ payday page; release 2024 |
| Онлайн | продолжают находить жителей через интернет; риск сбора несуществующих долгов и преследования коллекторами, в т. ч. нелицензированными или зарубежными | NCDOJ payday page |
| Отзыв списаний | сообщить банку об отмене ACH-списания и письменно или по email уведомить кредитора; крайняя мера — закрыть счёт, сначала открыв новый в другом банке | NCDOJ payday page |
| Работа с кредитором | можно предложить вернуть основную сумму займа | NCDOJ payday page |
| Угрозы арестом или удержанием зарплаты | жалоба генпрокурору, **1-877-5-NO-SCAM** | NCDOJ payday page |
| Иск к онлайн-кредитору (2020) | полные возвраты и списание всех займов жителей NC | NCDOJ release 2020 |
| Car title | тоже выведены из штата | NCDOJ release 2024 |

### Consumer Finance Act (installment) — действующая замена
| Item | Verified value | Откуда |
|---|---|---|
| Кто | лицензиаты NCCOB, займы **$25,000 or less**, не под залог недвижимости | NCCOB CF |
| Срок | от **12** до **96** ежемесячных платежей | CF FAQ (§53-176(a)) |
| Ставка, заём ≤ **$12,000** | смешанная: **33%** на часть до **$4,000**, **24%** на часть $4,000–$8,000, **18%** на остаток | CF FAQ |
| Ставка, заём > $12,000 | **18%** | CF FAQ |
| После срока или решения суда | ставка снижается до **8%** | CF FAQ (§53-173) |
| Late fee | после **10** дней просрочки, если указан в договоре; сейчас не больше **$18** («subject to change»); один на каждый просроченный платёж | CF FAQ (§53-177) |
| Отсрочка платежа | по соглашению; сбор до **1.5%** за каждый отложенный месячный платёж; дата погашения не сдвигается; при нескольких — письменное соглашение | CF FAQ (§53-177(c)) |
| Servicer | с **1 октября 2023** компания, принимающая платежи по займу CFA, обязана иметь лицензию | CF FAQ (SL 2023-61) |
| Освобождены от лицензии | банки, credit unions, trust companies и др. (§53-191) | CF FAQ |
| Без лицензии CFA | **16%** годовых на некоторые займы ≤ $25,000 (§24-1.1(c)), с 1984; такие кредиторы вне надзора NCCOB — вопросы в NCDOJ | NCCOB Max Rate; CF FAQ |

### NOT verified — do not publish

- **Текст G.S. 53-281** (запрет deferred deposit у check cashers) — не открывался. Пиши
  «payday lenders were shut down», а не цитату статута.
- **«18 percent for unlicensed lenders»** из пресс-релиза NCDOJ 2024 — расходится с
  опубликованной регулятором ставкой 16% (§24-1.1(c)). На страницы идёт только 16% NCCOB.
- **Досрочное погашение займа CFA** и штрафы за него — не найдено.
- **Military Lending Act / Fort Liberty** — в сессии не проверялось.
- «$100 to $500» и «390 to 780 percent» со страницы NCDOJ — **описание payday вообще**,
  не лимиты NC. Как лимиты не подавать.

### Расхождение с внутренним гидом — ссылку НЕ ставить

https://1firstcashadvance.org/loans-by-state/north-carolina/ («North Carolina Payday Loan
Alternatives | 1F Cash Advance», обновлён September 8, 2026) пишет «All North Carolina
lenders must adhere to a small loan APR cap of **36%**». Регулятор после SL 2023-61 даёт
**33%** на часть до $4,000. Гид устарел — в блоке закона ссылка ведёт на FAQ NCCOB.

### Ловушки

1. **Минимальный срок — 12 месяцев.** Законная замена payday — это заём минимум на год
   ежемесячных платежей, а не «короткий заём». Не обещай «repay by next payday».
2. **33% — не APR всего займа.** Это ставка на часть баланса до $4,000; выше ставка ниже.
   Пиши «33% a year on the first $4,000».
3. **Бюджет `$4,000`:** ¶1 Can-You-Get + одна строка таблицы. В таблице пиши
   «24% up to $8,000», а не «on the next $4,000».

## North Carolina city parameters

Округа подтверждены заголовками серий FRED 16 сентября 2026.

| City | County | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Charlotte | Mecklenburg County | MHINC37119A052NCEN | DP04ACS037119 | 12:30 pm |
| Durham | Durham County | MHINC37063A052NCEN | DP04ACS037063 | 12:30 pm |
| Fayetteville | Cumberland County | MHINC37051A052NCEN | DP04ACS037051 | 12:30 pm |
| Greenville | Pitt County | MHINC37147A052NCEN | DP04ACS037147 | 12:30 pm |
| Lumberton | Robeson County | MHINC37155A052NCEN | DP04ACS037155 | 12:30 pm |
| Rocky Mount | Nash County | MHINC37127A052NCEN | DP04ACS037127 | 12:30 pm |

Медиана штата: `MHINC37000A052NCEN`. Долг на душу: NY Fed area report, лист `total`, строка `NC`.

**Rocky Mount лежит в двух округах — Nash и Edgecombe** (Census 2020 place-by-county,
`st37_nc_place_by_county2020.txt`). Штатный реестр муниципалитетов NC OSBM
(`municipalities-2020`) называет первым **Nash** — ряд дохода берётся по Nash County.
Не писать, что Nash «содержит большую часть города»: доли населения не проверены.
**Durham** частично заходит в Orange и Wake, основной округ — Durham County.
**Greenville — омоним:** есть Greenville в NC (Pitt County) и в SC.

## Ready state blocks (change only {{City}}/{{County}})

### Loan Products (NC) — exactly 2 cards, payday отсутствует
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>The legal route in North Carolina. You repay in monthly payments on a set schedule rather than in one lump sum, and the lender has to hold a state license. Ask for the total cost of credit in dollars before you sign.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Personal Loans</h3>
        <p>For a larger or longer need, a personal loan spreads repayment further and is priced on your credit and income. Compare the total cost in dollars against an installment loan rather than comparing monthly payments alone.</p>
        <a href="https://1firstcashadvance.org/personal-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Personal Loans &rarr;</a></div>
    </div>
  </div>
</section>
```

### North Carolina Law at a Glance — 8 rows из 8, ноль меток `§`
Вхождения в таблице: `$25,000`, `33%`, `$4,000`, `24%`, `$8,000`, `$18`, `16%` — по 1; `18%` и `$12,000` — по 2
(запас 0). После ¶1 Can-You-Get (`$25,000`, `33%`, `$4,000`) у этих трёх запас тоже 0.
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>North Carolina Law at a Glance</h2>
    <p>These are the small-loan rules for all of North Carolina, including {{City}}. In plain terms: what has been shut down, what is allowed instead, and who to call if a lender breaks the rules. Full detail is in the <a href="https://nccob.nc.gov/financial-institutions/consumer-finance/frequently-asked-questions">Commissioner of Banks consumer finance FAQ</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>North Carolina position</th></tr>
      <tr><td>Payday lending</td><td>Payday lenders were shut down in the state, and the Attorney General pursues online lenders that still reach residents</td></tr>
      <tr><td>Allowed instead</td><td>A consumer finance loan from a lender licensed by the Commissioner of Banks, for amounts up to the state ceiling</td></tr>
      <tr><td>Rate, loans up to $12,000</td><td>33% a year on the first $4,000 of balance, 24% up to $8,000, and 18% above that</td></tr>
      <tr><td>Rate, larger loans</td><td>18% a year on loans over $12,000</td></tr>
      <tr><td>Term</td><td>12 to 96 monthly payments</td></tr>
      <tr><td>Late fee</td><td>Only after a payment is 10 days late, currently capped at $18</td></tr>
      <tr><td>Without a license</td><td>16% a year on certain loans of $25,000 or less</td></tr>
      <tr><td>Where to report it</td><td>The Commissioner of Banks for licensed lenders, or the Attorney General's consumer protection line</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Ask for the annual percentage rate and the total cost in dollars before you sign, and check both against what your budget can carry for every month of the term.</p>
  </div>
</section>
```

### Other Ways to Cover an Emergency (NC)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history rather than a credit score alone.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call your {{County}} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
```

### Borrow Carefully (NC) — 4 универсальных буллета, без $ и фактов штата
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Check the license before anything else.</strong> Ask which state license the lender holds and confirm it with the regulator before you share your bank details.</li>
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. Interest runs on the balance, and qualifying for more is not a reason to take more.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the payment schedule in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any small loan.</li>
      </ul>
      <p style="margin-bottom:0">To check a license or file a complaint, contact the <a href="https://nccob.nc.gov/consumer-information/consumer-inquiries-and-complaint-information">North Carolina Office of the Commissioner of Banks</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```

### Шесть стат-карточек — правовые (1–3, 6) одинаковы по штату
| # | `.num` | lbl | Источник |
|---|---|---|---|
| 1 | `Shut down` | payday-кредиторы выведены из штата (слот «максимум займа», как в GA) | NCDOJ payday page |
| 2 | `State ceiling` | у займа лицензиата есть долларовый потолок в законе | NCCOB Consumer Finance |
| 3 | `Capped by size` | потолок ставки зависит от размера займа (слот APR) | NCCOB CF FAQ |
| 6 | `Lower after maturity` | ставка обязана снизиться после срока или решения суда | NCCOB CF FAQ |

## Distinct local angles (из таблицы SAIPE, не придумывать)
- Charlotte / Mecklenburg — рост каждый год, выше медианы штата.
- Durham / Durham — рост каждый год, выше медианы штата.
- Fayetteville / Cumberland — рост до 2023, спад в 2024, самая высокая жилищная нагрузка набора NC.
- Greenville / Pitt — спад в 2021 и в 2024.
- Lumberton / Robeson — спад в 2021, затем три года роста; самый большой разрыв со штатом.
- Rocky Mount / Nash — спад в 2022, самый сильный рост за пять лет.
