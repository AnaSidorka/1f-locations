# Maryland — verified figures and ready state blocks

**H1-режим: третья форма** — `Payday loan alternatives in {{City}}, {{State}}` (P3-11), то есть
`Payday loan alternatives in Baltimore, Maryland`. Заголовок офисов —
`Where to get payday loan alternatives in Baltimore` (P3-5). Can-You-Get открывается словом **No**.
Отсечка шага 3 — **12:30 pm**: Мэриленд в восточном поясе, та же полоса, что OH/NC/SC/RI/VA/DE (P2-12).

**Почему третья форма.** Регулятор не лицензирует payday как отдельный продукт. Заём до $25,000
нельзя продать дороже ставки, разрешённой штатом, а потолок для малого займа — 2.75% в месяц,
то есть 33% годовых. Двухнедельный аванс при такой цене не существует; легальный путь —
лицензированный installment-кредит.

**Особенность Балтимора.** Baltimore City — одновременно город и окружной эквивалент (FIPS 24510),
поэтому ряд SAIPE здесь буквально городской, а не окружной. Геометка в карточках и подписи
всё равно пишется дословно — `Baltimore City` (P0-2).

## Источники — открыты 1 октября 2026

| Документ | URL |
|---|---|
| OFR, «Payday» Loans: What You Need to Know as a Maryland Consumer | https://www.labor.maryland.gov/finance/consumers/frpaydayloans.shtml |
| OFR, Consumer information (обзор того, что надзирает офис) | https://www.labor.maryland.gov/finance/consumers/ |
| Md. Code, Commercial Law § 12-306 — Interest rates | https://mgaleg.maryland.gov/mgawebsite/Laws/StatuteText?article=gcl&section=12-306&enactments=false |
| Md. Code, Commercial Law § 12-314 — Loans void and unenforceable | https://mgaleg.maryland.gov/mgawebsite/Laws/StatuteText?article=gcl&section=12-314&enactments=false |
| Md. Code, Commercial Law § 15-802 — Dishonored instruments | https://mgaleg.maryland.gov/mgawebsite/Laws/StatuteText?article=gcl&section=15-802&enactments=false |
| Md. Code, Financial Institutions § 12-120 — Check casher fees | https://mgaleg.maryland.gov/mgawebsite/Laws/StatuteText?article=gfi&section=12-120&enactments=false |

## Verified figures

| Item | Verified value | Cite |
|---|---|---|
| Охват потолка | заём **$25,000 или меньше** нельзя продать дороже ставки, разрешённой законом штата | OFR |
| Малый заём, первая часть | **2.75% в месяц** на первые $1,000 займа размером $2,000 или меньше = **33% годовых** | §12-306(a)(6)(i), OFR |
| Малый заём, вторая часть | **2% в месяц** на следующие $1,000 того же займа = **24% годовых** | §12-306(a)(6)(i), OFR |
| Заём больше $2,000 | **2% в месяц** на всю непогашенную сумму = **24% годовых** | §12-306(a)(6)(ii), OFR |
| Просрочка свыше 6 месяцев | **6% простых годовых** после шести месяцев дефолта | §12-306(b) |
| Рефинансирование | можно добавить начисленные проценты, но не более чем за **60 дней** | §12-306(c) |
| Лицензия | большинство потребительских кредиторов обязаны иметь лицензию **Commissioner of Financial Regulation**; проверка — nmlsconsumeraccess.org | OFR |
| Заём без лицензии или выше ставки | заём **$25,000 или меньше** становится **void and unenforceable** | §12-314(b)(1) |
| Что кредитор не получает | «may not receive or retain any principal, interest, fees, or other compensation» | §12-314(b)(2) |
| Что кредитору запрещено | взыскивать прямо или косвенно любую сумму; обращать взыскание на обеспечение; продавать, уступать или передавать заём | §12-314(d) |
| Исправление нарушения | если устранено **до наступления первого платежа** — заём не аннулируется | §12-314(b)(1)(ii) |
| Нарушение Military Lending Act | тоже делает заём ничтожным | §12-314 |
| Чек не оплачен | через 30 дней после уведомления: сумма чека + сбор до **$35** + до **двукратной** суммы чека, но не больше **$1,000** | §15-802(b) |
| Комиссии обнальщика чеков | госчек — 2% или $3; личный чек — 10% или $5; прочее — 4% или $5; разовый членский взнос ≤ $5 | §12-120 |
| Жалобы | Office of Financial Regulation, 410-230-6077 | OFR |

### NOT verified — do not publish
- Md. Code, Financial Institutions § 11-204 прочитан, но он про **места ведения бизнеса**
  лицензиата, а не про саму обязанность лицензии; как источник строки «лицензия обязательна»
  не используется — для неё источником служит страница OFR.
- Статистика рынка, число лицензиатов, APR фактических предложений — OFR их не публикует.
- Формулировки вида «payday banned in Maryland since …»: даты и акт не читались.
- Запрета на чек с будущей датой, аналогичного D.C. §26-319, в прочитанных секциях нет —
  **не утверждать**, что Мэриленд прямо запрещает postdated check.

## Maryland city parameters

| City | Unit | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Baltimore | Baltimore City | MHIMD24510A052NCEN | DP04ACS024510 | 12:30 pm |

Медиана штата — `MHIMD24000A052NCEN`. Долг на душу: NY Fed, лист `total`, строка `MD`.

### Данные, вытянутые 1 октября 2026

| Год | Baltimore City median income | MD debt per person | After housing |
|---|---|---|---|
| 2020 | $51,485 | $72,670 | $3,003 |
| 2021 | $54,068 | $75,460 | $3,154 |
| 2022 | $54,735 | $80,130 | $3,193 |
| 2023 | $58,616 | $80,660 | $3,419 |
| 2024 | $63,451 | $79,760 | $3,701 |

Медиана Мэриленда 2024 — **$102,835**, то есть Baltimore City на **$39,384 ниже**.
Жилищная нагрузка 2024 — **41.7%**. Рост дохода за пять лет ≈ **23%**, долга на душу ≈ **10%**.

## Ready state blocks

Форма — как у District of Columbia и New Mexico (третья форма): Products = Installment Loans +
Personal Loans, заголовок офисов со словом alternatives. Блок 14 — форма одиночного города:
`1F Cash Advance Across Maryland` + ссылка на `/loans-by-state/payday-loans-maryland/`.

### Шесть стат-карточек — правовые (1–3, 6)
| # | `.num` | Источник |
|---|---|---|
| 1 | `Rate ceiling` | §12-306 |
| 2 | `Tiered by loan size` | §12-306 |
| 3 | `Void without a license` | §12-314 |
| 6 | `Nothing to collect` | §12-314 |

Borrow Carefully: OFR назван со ссылкой на страницу регулятора; жалобы — OFR или федеральный CFPB.

## Distinct local angles
- Baltimore / Baltimore City — доход рос каждый год с 2020 и в 2024 всё ещё на **$39,384** ниже
  медианы штата; жилищная нагрузка 41.7% — выше, чем в любом другом городе набора;
  долг на душу по штату снижался в 2024 после пика 2023 года.
