# Сборка 2026-10-01 — исправление ссылок (DE · IA · MO · OR · WA)

Повод: владелец прислал копии страниц с жалобой «кривые тексты».
Копии оказались **скачанными до правок 28 сентября**. На диске текстовые дефекты
уже отсутствовали; реальным оставался один — битые URL.

## Состав папки

Des Moines (IA) · Joplin (MO) · Milford (DE) · Portland (OR) · Seattle (WA) · Vancouver (WA)

## Что исправлено в этой сборке

Слаг раздела штата в хлебных крошках, в блоке 14 и в поле `url` схемы WebPage
приведён к фактическому адресу на сайте (`references/site-urls.md`):

| Штат | Было | Стало |
|---|---|---|
| IA | `/loans-by-state/iowa/` | `/loans-by-state/payday-loans-in-iowa/` |
| DE | `/loans-by-state/delaware/` | `/loans-by-state/payday-loans-delaware/` |
| OR | `/loans-by-state/oregon/` | `/loans-by-state/payday-loans-oregon/` |
| WA | `/loans-by-state/washington/` | `/loans-by-state/payday-loans-washington/` |
| KY | `/loans-by-state/kentucky/` | `/loans-by-state/payday-loans-kentucky/` |
| UT | `/loans-by-state/utah/` | `/loans-by-state/payday-loans-in-utah/` |
| MO, RI | слаг уже верный | без изменений |

URL самой страницы в `WebPage.url` переведён со старой схемы `/<city>-<st>-loans/`
на действующую `/loans-by-state/<state-slug>/<city>/`. Перекрёстные ссылки
Seattle ↔ Vancouver (`/seattle-wa-loans/`, `/vancouver-wa-loans/`) исправлены там же.

**Округ Колумбия — отдельный случай.** Раздела `District of Columbia` на сайте нет
вообще. Ссылка блока 14 переведена на хаб `/loans-by-state/` с текстом
`Payday loan rules in every state`; из `BreadcrumbList` снят несуществующий уровень
штата, осталось Home → Loans by State → Washington.

## Что было исправлено ранее и в присланных копиях ещё видно

- литеральный `{county}` в карточке Utility (DE, IA, MO, OR, DC, KY, RI, UT) —
  причина в `UTILITY_CARD`, вставлявшемся готовой строкой; исправлено `.format(county=county)`;
- тавтологии на странице DC: подпись таблицы, колонка долга, вводное слово строки
  источников и H2 блока 14 — исправлены через `SRC_LEAD` / `TBL_CAP` / `DEBT_COL` / `LINKS_H2`.

## Проверка

`python3 scripts/validate.py <файл> --city "<City>"` → `RESULT: PASS (all 36 rules)`
на всех шести. Вывод сохранён рядом как `validate-<файл>.txt`.
Штамп `<!-- skill-version: v2 -->` присутствует во всех шести (проверено грепом).

## Открытый пункт

Тот же дефект слагов остаётся на **65 страницах** других штатов (AL, AZ, CA, GA, IL,
IN, LA, MS, NC, NM, TN). Владелец 1 октября 2026 ограничил правку присланными файлами.
