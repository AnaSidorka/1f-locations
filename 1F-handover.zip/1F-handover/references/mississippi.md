# Mississippi — verified figures and ready state blocks

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11): payday разрешён
законом и выдаётся лицензиатами (check cashers). Продукт — delayed deposit: заёмщик оставляет
личный чек, кредитор держит его до даты из договора, погашение одним платежом.
Заголовок блока офисов — форма по умолчанию `Where to get payday loan {{City}}` (P3-5).

## Verified legal figures

Все документы открыты 16 сентября 2026. Регулятор — **Mississippi Department of Banking and
Consumer Finance (DBCF)**, раздел Consumer Finance: https://dbcf.ms.gov/consumer-finance/

| Документ | URL | Что даёт |
|---|---|---|
| Consumer pamphlet «Payday Loans in Mississippi» | https://dbcf.ms.gov/wp-content/uploads/2020/06/Check-Cashers-Consumer-Education-Pamphlet-PDF.pdf | максимум, NSF, запрет продления, арест, платёжный план |
| Check Casher Regulations (Part 3 Ch. 3, eff. 12-1-12) | https://dbcf.ms.gov/wp-content/uploads/2020/06/Check-Casher-Regulations-Effective-12-1-12-PDF.pdf | NSF $30, пример APR 521.43%, таблица комиссий |
| Текст Check Cashers Act на сайте DBCF | https://dbcf.ms.gov/wp-content/uploads/2020/06/MS-Check-Cashers-Act-PDF.pdf | §75-67-519: лимиты, сроки, тарифы |
| Memo: Credit Availability maximum, 19 июня 2026 | https://dbcf.ms.gov/wp-content/uploads/2026/06/Credit-Availability-Maximum-Outstanding-Balance-Memo-.July-2026-1.pdf | потолок MCAA **$3,320** с 1 июля 2026 |
| Complaint form | https://dbcf.ms.gov/complaint-form/ | ссылка в Borrow Carefully |
| Список лицензиатов check casher (10 фев 2026) | https://dbcf.ms.gov/wp-content/uploads/2026/02/Check-Casher-List-02102026.pdf | проверка лицензии |

### Delayed deposit (payday) — Mississippi Check Cashers Act, Miss. Code Ann. §75-67-501 et seq.

| Item | Verified value | Откуда |
|---|---|---|
| Максимальный чек | **$500 including the fee**; каждый заёмщик ограничен $500 с комиссией **at any time** | §75-67-519(2), (4)(c); pamphlet |
| Максимум наличными | **$410**: чек $500, комиссия **$90** | pamphlet («writes a $500 check, pays the $90 fee, and receives $410») |
| Комиссия | ≤ **$20 per $100** advanced для чеков ≤ $250; ≤ **$21.95 per $100** для чеков $250.01–$500 | §75-67-519(4); regs schedule |
| Срок | чек ≤ $250 — до **30 дней**; чек > $250 — **28–30 дней** по выбору заёмщика | §75-67-519(1) |
| Продление | **запрещено**: нельзя renew / extend / rollover; заём гасится полностью до нового | §75-67-519(5); regs Rule 3.3 п.5; pamphlet |
| Погашение чеком того же кредитора | запрещено (тот же лицензиат или аффилированное лицо) | §75-67-519(5) |
| Late / collection fee | запрещены | §75-67-519(7) |
| NSF (processing fee) | один раз, до **$30.00**, только если указан в договоре | regs Rule 3.3 п.2; pamphlet |
| Суд | при решении суда — судебные издержки, attorney's fees и присуждённые суммы | pamphlet |
| Арест | **нет**: кредитор не может угрожать уголовным преследованием или применять его; гражданский иск возможен | pamphlet |
| Не могу вернуть | можно **попросить** платёжный план, но кредитор **не обязан** его дать | pamphlet |
| Раскрытие | договор указывает комиссию в долларах **и** как APR | §75-67-519(3); regs Rule 3.3 п.4 |
| Автосписание | договор может разрешить списание со счёта в дату погашения; чек можно выкупить до даты | pamphlet |
| Cutoff for Apply step 3 | **11:30 am** (полоса LA/TN/AL/IL/TX/MS в P2-12, решение владельца 16 сен 2026) | CLAUDE.md |

**Опубликованный регулятором APR.** Правила DBCF (Rule 3.3 п.4) приводят пример:
`$100.00 delayed deposit transaction due in 14 days, when a $120.00 check is held:
$20.00/$100.00 X 365/14 = 521.43 APR`. Это цифра регулятора, не расчёт. Писать её только
с условием: двухнедельный аванс $100 на нижнем тарифе.

### Расчётные величины — помечать как расчёт

- Верхний тариф на максимуме: $90 / $410 × 365 / 14 = **≈572%** за 14 дней. Внутренний гид
  печатает 572.30%. На страницах не используется: хватает цифры регулятора.
- Таблица регулятора: аванс $300 → комиссия $65.85; $400 → $87.80.

### Статус закона — почему payday в Миссисипи действует бессрочно

- **HB 1075 (2021)** снял repealer с переутверждённых разделов Check Cashers Act и Title
  Pledge Act: https://billstatus.ls.state.ms.us/documents/2021/html/HB/1000-1099/HB1075SG.htm
- **HB 547 (2026)** изменил §75-67-517 и §75-67-619 (сбор за оплату картой), в силе с 1 июля 2026:
  https://billstatus.ls.state.ms.us/documents/2026/html/HB/0500-0599/HB0547SG.htm —
  сводка DBCF: https://dbcf.ms.gov/wp-content/uploads/2026/05/Legislative-Update-for-Website.2026-Regular-Session.Revised.pdf
- Текст закона на сайте DBCF помечен «Current through … 2017». Разделы §75-67-519 после
  2017 года не менялись: в списках законопроектов 2022–2026 по check cashers есть только
  сбор за карту (HB 547) и умершие билли о снижении ставок.

### Mississippi Credit Availability Act (installment), Miss. Code Ann. §75-67-601 et seq.

- **Действует до 1 июля 2030**: SB 2495 (2025), одобрен губернатором 12 марта 2025 —
  https://billstatus.ls.state.ms.us/documents/2025/html/SB/2400-2499/SB2495SG.htm
- **Потолок: $3,320 с 1 июля 2026** (memo DBCF от 19 июня 2026). В законе 2025 года стоит
  $3,250, в брошюре MCAA v2.4 (июнь 2025) — тоже $3,250. **$3,250 и $2,500 — исторические,
  на страницах не использовать.** Потолок пересматривается по CPI-U ежегодно к 1 июля —
  перепроверять при каждой сборке после июня.
- Счета ≤ $500 — равные платежи **4–6 месяцев**; > $500 — **6–12 месяцев**.
- Monthly handling fee ≤ **25%** от остатка основного долга в месяц; origination fee 1%
  или $5, что больше; late fee 10% просроченной суммы после 10 рабочих дней.
- Право отказаться (rescind) в течение **одного рабочего дня**; если деньги получены раньше,
  origination fee не возвращается (брошюра MCAA:
  https://dbcf.ms.gov/wp-content/uploads/2025/06/MCAA-Pamphlet-v2.4-06272025.pdf).

### Внутренний гид — ссылку ставить можно

https://1firstcashadvance.org/loans-by-state/mississippi/ (открыт 16 сентября 2026, заголовок
«Mississippi Payday Loans | 1F Cash Advance») печатает $500 с комиссией, $20 и $21.95 per $100,
NSF $30, срок до 30 дней, запрет продлений, APR 521.43% на $100 за 14 дней и $410 → итог $500.
Всё сходится с регулятором.

### NOT verified — do not publish

- **Счёт «across all lenders».** В Миссисипи нет государственной базы займов, а закон говорит
  «each customer … at any time» без слов о всех кредиторах. Не пиши «across all lenders».
- **Несколько займов у одного кредитора.** Брошюра допускает, правила DBCF (Rule 3.3 п.5)
  требуют погасить чек до новой сделки. Противоречие не снято — тему на страницы не выносить.
- Любой «средний APR в Миссисипи» из небанковских источников.
- Период охлаждения между займами — в законе и правилах не найден.

### Ловушки

1. **$500 — это чек вместе с комиссией, а не сумма на руки.** На руки максимум $410.
   «Borrow up to $500» — ошибка.
2. **Потолок MCAA индексируется.** $3,250 из закона 2025 года устарел с 1 июля 2026.
3. **Платёжный план не гарантирован** — в отличие от Алабамы. Не пиши «you are entitled
   to a payment plan».
4. **Бюджет `$100`.** «per $100» съедает вхождения: в ¶1 Can-You-Get — не больше одного `$100`,
   второе уходит в мелкий шрифт. В таблице закона пиши «per hundred dollars».

## Mississippi city parameters

Округа подтверждены заголовками серий FRED 16 сентября 2026.

| City | County | SAIPE series | Housing series | cutoff |
|---|---|---|---|---|
| Columbus | Lowndes County | MHIMS28087A052NCEN | DP04ACS028087 | 11:30 am |
| Corinth | Alcorn County | MHIMS28003A052NCEN | DP04ACS028003 | 11:30 am |
| Greenwood | Leflore County | MHIMS28083A052NCEN | DP04ACS028083 | 11:30 am |
| Gulfport | Harrison County | MHIMS28047A052NCEN | DP04ACS028047 | 11:30 am |
| Laurel | Jones County | MHIMS28067A052NCEN | DP04ACS028067 | 11:30 am |
| Meridian | Lauderdale County | MHIMS28075A052NCEN | DP04ACS028075 | 11:30 am |
| Tupelo | Lee County | MHIMS28081A052NCEN | DP04ACS028081 | 11:30 am |

Медиана штата: `MHIMS28000A052NCEN`. Долг на душу: NY Fed area report, лист `total`, строка `MS`.

## Ready state blocks (change only {{City}}/{{County}})

### Loan Products (MS)
Шаблонное «It is unsecured» заменено на «It is usually unsecured»: заём по MCAA бывает
обеспеченным (§75-67-619(1)), P0-4.
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A small advance against a personal check you write today. The lender holds the check until the date in your agreement, and you repay the full amount in one payment. It is built for a short gap between paychecks.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in monthly payments, not all at once. It is usually unsecured and has a set end date. If you need a bigger amount or more time, this is often cheaper than a payday loan.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Now &rarr;</a></div>
    </div>
  </div>
</section>
```

### Mississippi Law at a Glance
8 строк данных из 8 — запас 0. Две метки `§` из двух (P2-6) — запас 0.
Вхождения: `$500`, `$21.95`, `$20`, `$30`, `$3,320` — по одному; `$250` — два (запас 0).
Мелкий шрифт: `$100`, `521.43%`, `$410`, `$90` — по одному.
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>Mississippi Law at a Glance</h2>
    <p>These are the payday rules for all of Mississippi, including {{City}}. Full legal detail is in the <a href="https://1firstcashadvance.org/loans-by-state/mississippi/">Mississippi state guide</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>Mississippi position</th></tr>
      <tr><td>Governing law</td><td>Mississippi Check Cashers Act, Miss. Code Ann. §75-67-501 and following, overseen by the Department of Banking and Consumer Finance</td></tr>
      <tr><td>Largest check</td><td>$500 including the fee, for each customer at any one time</td></tr>
      <tr><td>Fee</td><td>Up to $20 per hundred dollars advanced on checks of $250 or less, and $21.95 per hundred above that</td></tr>
      <tr><td>Term</td><td>Up to 30 days; a check over $250 is held 28 to 30 days, as you choose</td></tr>
      <tr><td>Renewal</td><td>Not allowed: the loan is paid in full before a new one can start</td></tr>
      <tr><td>Returned check</td><td>One NSF fee of up to $30, and only if the agreement discloses it</td></tr>
      <tr><td>Trouble repaying</td><td>You can ask for a payment plan, but the lender does not have to grant one</td></tr>
      <tr><td>Larger amounts</td><td>A credit availability loan under §75-67-601 and following, up to $3,320 and repaid over 4 to 12 months</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example: the Department's disclosure rule prices a $100 advance due in 14 days at 521.43% APR, and a check at the top of the range leaves about $410 in hand after a fee near $90. These are illustrative figures at the current limits, not quoted offers.</p>
  </div>
</section>
```

### Other Ways to Cover an Emergency (MS)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below payday.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call your {{County}} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
```

### Borrow Carefully (MS)
Долларовых сумм и фактов штата внутри буллетов нет (P2-5).
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. The fee grows with the amount advanced, so every extra dollar raises the charge.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you see a problem coming, talk to the lender before the date, not after it.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="https://dbcf.ms.gov/complaint-form/">Mississippi Department of Banking and Consumer Finance</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```

### Шесть стат-карточек — правовые (1–3, 6) одинаковы по штату
| # | `.num` | Источник |
|---|---|---|
| 1 | `Max check` | DBCF pamphlet |
| 2 | `Two fee tiers` | Check Cashers Act (DBCF PDF) |
| 3 | `Triple-digit` | DBCF Check Casher Regulations |
| 6 | `No arrest` | DBCF pamphlet |

## Distinct local angles (из таблицы SAIPE, не придумывать)
- Columbus / Lowndes — доход рос каждый год с 2020.
- Corinth / Alcorn — провал в 2023, скачок в 2024.
- Greenwood / Leflore — падение в 2021 и 2023, самый большой разрыв со штатом.
- Gulfport / Harrison — рост каждый год, выше медианы штата.
- Laurel / Jones — пик в 2022, ниже него два года подряд.
- Meridian / Lauderdale — провал в 2021, затем три года роста.
- Tupelo / Lee — пик в 2023, спад в 2024, выше медианы штата.
