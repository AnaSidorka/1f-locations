#!/usr/bin/env python3
"""
Печатает версию правил из CLAUDE.md и проверяет, что штамп соответствует содержимому.

    python3 scripts/rules_version.py

Зачем. CLAUDE.md подставляется в контекст один раз, на старте сессии, и после правок
отстаёт. Строка `rules-version` в первой строке файла — дешёвый токен сравнения:
исполнитель сверяет то, что видит в контексте, с тем, что печатает этот скрипт.
Разошлись — работать надо по диску.

Второй случай: правила отредактировали, а штамп обновить забыли. Тогда скрипт
печатает MISMATCH и показывает, какой штамп должен стоять.

Выход: 0 — штамп соответствует, 1 — нет, 2 — штампа нет вовсе.
"""
import hashlib
import re
import sys

CLAUDE = "CLAUDE.md"
STAMP = re.compile(r"^<!-- rules-version: (\S+) -->\s*$")


def body_digest(lines):
    """Хеш содержимого без самой строки штампа."""
    body = "".join(l for l in lines if not STAMP.match(l))
    return hashlib.sha1(body.encode("utf-8")).hexdigest()[:8]


def main():
    try:
        lines = open(CLAUDE, encoding="utf-8").readlines()
    except FileNotFoundError:
        print(f"нет файла {CLAUDE} — запускай из корня проекта")
        sys.exit(2)

    stamped = next((STAMP.match(l).group(1) for l in lines if STAMP.match(l)), None)
    if stamped is None:
        print(f"в {CLAUDE} нет строки rules-version")
        sys.exit(2)

    date_part, _, digest_part = stamped.rpartition("-")
    expected = body_digest(lines)

    print(f"rules-version: {stamped}")
    if digest_part == expected:
        print("OK — штамп соответствует содержимому CLAUDE.md")
        sys.exit(0)

    print(f"MISMATCH — содержимое изменилось, а штамп нет")
    print(f"  в файле:  {digest_part}")
    print(f"  ожидается: {expected}")
    print(f"  поставь первой строкой: <!-- rules-version: {date_part}-{expected} -->")
    sys.exit(1)


if __name__ == "__main__":
    main()
