#!/usr/bin/env python3
"""
1F page validator. Runs the full checklist against a built city page and prints
PASS/FAIL per rule plus a final verdict. Usage:

    python3 validate.py path/to/city-st-loans-NEW.html [--city "Covington"]

Spec v5: the statistics block is 2 numeric stat-cards (median income, gap to state),
one five-year income table and one consolidated source footnote. See references/page-spec.md 5c.

If --city is omitted it is guessed from the <h1>. Exit code 0 = all pass, 1 = any fail.
Every rule maps to a line in references/page-spec.md and references/checklist.md.
"""
import re, sys, json
from collections import Counter

def load(path):
    return open(path, encoding="utf-8").read()

def strip_scripts_styles(h):
    h = re.sub(r"<script.*?</script>", "", h, flags=re.S)
    h = re.sub(r"<style.*?</style>", "", h, flags=re.S)
    return h

def text_of(h):
    return re.sub(r"<[^>]+>", " ", strip_scripts_styles(h))

def section(h, marker):
    i = h.find(marker)
    if i < 0:
        return ""
    s = h.rfind("<section", 0, i)
    e = h.find("</section>", i)
    return h[s:e+10] if s >= 0 and e >= 0 else ""

# H1 varies with the state's product regime -- see references/page-spec.md 2:
#   payday available        -> "Payday Loans in {City}, {State}"
#   short-term replaces it  -> "Short-term loans in {City}, {State}"
#   payday prohibited       -> "Payday loan alternatives in {City}, {State}"
H1_FORMS = r"(?:Payday Loans|Short-term loans|Payday loan alternatives) in"

def guess_city(h):
    m = re.search(r"<h1>" + H1_FORMS + r" ([^,<]+),", h)
    return m.group(1).strip() if m else None

def validate(path, city=None):
    h = load(path)
    if not city:
        city = guess_city(h) or ""
    txt = text_of(h)
    results = []  # (ok, rule, detail)

    def check(ok, rule, detail=""):
        results.append((bool(ok), rule, detail))

    # --- structure / order ---
    h2s = [re.sub(r"<[^>]+>", "", m.group(1)).strip() for m in re.finditer(r"<h2>(.*?)</h2>", h)]
    check("How 1F Cash Advance Works" in h, "How 1F Works block present")
    check("(not 1F Cash Advance)" not in h, "How-1F bullet 3 has no '(not 1F Cash Advance)' (owner decision 2026-10-29)")
    check("Cover an Emergency" in h, "Other Ways H2 = 'Cover an Emergency'")
    check("Credit union Payday Alternative Loans" in h, "CU card heading = 'Payday Alternative Loans'")
    check("NMLS ID 1814281" in h, "Topbar NMLS present")
    check("Storefront" not in h and "1F Cash Advance Store" not in h and "There Is No 1F" not in h,
          "Store block removed")
    check("Where to get payday loan" in h or "Where Can You Get a Payday Loan Nearby?" in h,
          "Office heading = 'Where to get payday loan' or 'Where Can You Get a Payday Loan Nearby?'")
    check("Prefer to apply in person" not in h, "Office intro paragraph removed")

    # --- Can You Get ---
    # Marker includes "in" (H2 = "Can You Get a Payday Loan in {City}?"):
    # the approved office H2 "Where Can You Get a Payday Loan Nearby?" contains the bare substring.
    cyg = section(h, "Can You Get a Payday Loan in")
    cyg_txt = re.sub(r"<[^>]+>", " ", cyg)
    m = re.search(r"</h2>\s*<p>(Yes|No|Not)", cyg)
    check(bool(m), "Can You Get opens with direct Yes/No/Not")
    check("metro county" not in cyg_txt.lower(), "No 'metro county' (city != county)")
    # first paragraph <= 45 words (hard cap)
    fp = re.search(r"</h2>\s*<p[^>]*>(.*?)</p>", cyg, re.S)
    fp_words = len(re.sub(r"<[^>]+>", "", fp.group(1)).split()) if fp else 999
    check(fp_words <= 45, "Can You Get 1st paragraph <=45 words", f"{fp_words} words")

    # --- statistics (v5): exactly 2 numeric stat-cards, no table; series in prose ---
    stats = section(h, "Borrowing and Debt")
    ncards = stats.count("stat-card")
    ntables = stats.count("<table")
    check(ncards == 2, "Statistics = exactly 2 stat-cards (median income + gap to state)", f"{ncards}")
    check(ntables == 0, "Statistics has no table (v5: figures in prose)", f"{ntables}")
    # the city must be named in the block (H2 carries it); geography labels on county-level
    # figures are a manual check -- see page-spec.md 5c
    check(city and city in stats, "Statistics reference the city", city)
    # the prose names the series years (start and end of the span it describes)
    years = sorted(set(re.findall(r"\b(20\d{2})\b", re.sub(r"<[^>]+>", " ", stats))))
    check(len(years) >= 2, "Statistics prose names the series years (v5)", f"{years}")
    # v4: sources live in one consolidated footnote; per-card source lines are gone
    nsrc = stats.count('class="src"')
    check(nsrc == 0 and stats.count("src-note") == 1,
          "Statistics sources consolidated in one footnote",
          f"{nsrc} src lines, {stats.count('src-note')} src-note")

    # --- FAQ: exactly 3, each answer <=60 words, page==schema ---
    faq = section(h, "Borrowers Ask")
    ans = [re.sub(r"<[^>]+>", "", m.group(1)) for m in re.finditer(r'<div class="a">(.*?)</div>', faq, re.S)]
    check(len(ans) == 3, "FAQ = exactly 3 questions", f"{len(ans)}")
    long_ans = [len(a.split()) for a in ans if len(a.split()) > 60]
    check(not long_ans, "FAQ answers each <=60 words", f"long: {long_ans}")
    # schema sync
    page_q = [re.sub(r"<[^>]+>", "", m.group(1)).strip() for m in re.finditer(r"<summary>(.*?)</summary>", faq, re.S)]
    sch_q = []
    for b in re.findall(r'<script type="application/ld\+json">(.*?)</script>', h, re.S):
        try:
            d = json.loads(b)
            if d.get("@type") == "FAQPage":
                sch_q = [q["name"] for q in d["mainEntity"]]
        except Exception:
            pass
    check(page_q == sch_q and len(page_q) == 3, "FAQ page copy == FAQPage schema")

    # --- Borrow Carefully: exactly 4 bullets, universal (no page-specific $ facts) ---
    bc = section(h, "Borrow Carefully")
    nbul = bc.count("<li>")
    check(nbul == 4, "Borrow Carefully = exactly 4 bullets", f"{nbul}")
    bc_txt = re.sub(r"<[^>]+>", " ", bc)
    # universal check: a $ figure inside Borrow Carefully is a page-specific fact (not allowed)
    check(not re.search(r"\$\d", bc_txt), "Borrow Carefully has no page-specific $ facts (universal only)")

    # --- Other Ways: 4 cards incl. bank ---
    ow = section(h, "Other Ways to Cover")
    check(ow.count("alt-card") == 4, "Other Ways = 4 cards", f"{ow.count('alt-card')}")
    check("Bank small-dollar" in h, "Bank small-dollar card present")

    # --- Products: exactly 2 cards, heading/link in sync ---
    i = h.find("Loan Products")
    if i < 0:
        i = h.find("Loan Options")
    prod = h[h.rfind("<section", 0, i):h.find("</section>", i)] if i >= 0 else ""
    nprod = prod.count('<div class="prod-card">')
    check(nprod == 2, "Products = exactly 2 cards", f"{nprod}")

    # --- Law: table present, <=8 rows, no statutory citations in the visible table ---
    law = section(h, "Law at a Glance")
    law_rows = law.count("<tr>")
    check(law_rows and law_rows - 1 <= 8, "Law table <=8 rows", f"{max(law_rows-1,0)} rows")
    law_txt = re.sub(r"<[^>]+>", " ", law)
    # heavy citation markers like "C.R.S.", "§ 5-3.1" or "R.S. 9:" repeated -> overload
    cites = len(re.findall(r"§|C\.R\.S\.|R\.S\.\s*\d", law_txt))
    check(cites <= 2, "Law table not overloaded with statute citations", f"{cites} citation marks")
    # no water paragraph after table
    after = law[law.find("</table>")+8:] if "</table>" in law else ""
    after_ps = re.findall(r"<p[^>]*>(.*?)</p>", after, re.S)
    water = [p for p in after_ps if "class=\"fine\"" not in after and len(re.sub(r"<[^>]+>","",p).split()) > 45]
    check(len(after_ps) <= 1, "No water paragraphs after Law table", f"{len(after_ps)} paras after table")

    # --- ZIP only in offices, not in Apply H2 ---
    # H2 блока Apply: "How to apply from {City} with 1F Cash Advance" (см. page-spec 2).
    # Регистронезависимо, чтобы правило продолжало ловить ZIP при любой форме заголовка.
    check(not re.search(r"How to apply from [^<]+ \d{5}", h, re.I), "ZIP removed from Apply H2")

    # --- tone: no banned phrases ---
    banned = ["lands hardest", "bites hardest", "hurts most", "makes the due date risky",
              "no cushion", "little financial slack", "honest reading", "awkward moment",
              "most expensive option", "will beat a payday loan every time", "the cheapest"]
    hits = [b for b in banned if b in txt.lower()]
    check(not hits, "No banned alarming/absolute phrases", f"{hits}")

    # --- AI marker in author bio ---
    tier1 = ["navigate", "delve", "leverage", "robust", "seamless", "tapestry", "testament"]
    ai_hits = [w for w in tier1 if re.search(r"\b" + w, txt, re.I)]
    check(not ai_hits, "No Tier-1 AI vocabulary", f"{ai_hits}")

    # --- numbers <=2 ---
    money = [x[0] for x in Counter(re.findall(r"\$[\d,]+", txt)).most_common() if x[1] > 2]
    pct = [x[0] for x in Counter(re.findall(r"\d+(?:\.\d+)?%", txt)).most_common() if x[1] > 2]
    check(not money, "Every $ figure <=2 occurrences", f"{money}")
    check(not pct, "Every percentage <=2 occurrences", f"{pct}")

    # --- 6 JSON-LD, valid, correct set ---
    types = []
    valid = True
    for b in re.findall(r'<script type="application/ld\+json">(.*?)</script>', h, re.S):
        try:
            types.append(json.loads(b).get("@type"))
        except Exception:
            valid = False
    want = {"Organization", "WebPage", "BreadcrumbList", "FAQPage", "Article", "Service"}
    check(valid and want.issubset(set(types)), "6 JSON-LD present and valid", f"{types}")

    # --- placeholders resolved ---
    check("{{" not in h, "No unresolved {{placeholders}}")

    # --- balanced tags ---
    bad = [t for t in ["section","div","p","h1","h2","h3","ul","li","table","tr","td","details","summary"]
           if len(re.findall(r"<"+t+r"[ >]", h)) != h.count("</"+t+">")]
    check(not bad, "Balanced tags", f"{bad}")

    # --- offices present ---
    check(h.count('<div class="office-card">') >= 1, "At least one office card")

    # --- Products cards follow the GOLD form: prod-ic icon in every card, no taglines ---
    # Owner rule 2026-10-29: every card opens with <img class="prod-ic"> (as on the Irvine
    # page); tagline divs like <div class="max">Tied to income...</div> are not part of the form.
    nprod_ic = prod.count('<img class="prod-ic"')
    check(nprod == 2 and nprod_ic == nprod, "Every product card has its prod-ic icon (GOLD form)",
          f"{nprod_ic} icons on {nprod} cards")
    check('class="max"' not in prod, "No tagline divs in Products (GOLD form)")

    # --- FAQ ends with the Read All FAQs ghost button (owner rule 2026-10-29) ---
    faq_btn = '<a class="btn ghost" href="https://1firstcashadvance.org/faq/">Read All FAQs</a>' in faq
    check(faq_btn, "FAQ has 'Read All FAQs' button to /faq/")

    # --- no legacy city-page URLs (owner rule 2026-10-29, full-site CSV sweep) ---
    # Live city format is /loans-by-state/{state-slug}/{city}/; every /{city}-{st}-loans/ URL
    # returns 404. The two-letter code list keeps product slugs (no-credit-check-loans etc.) safe.
    legacy = re.findall(r"1firstcashadvance\.org/[a-z0-9-]*-(?:al|ak|az|ar|ca|co|ct|de|fl|ga|hi|id|il|in|ia|ks|ky|la|me|md|ma|mi|mn|ms|mo|mt|ne|nv|nh|nj|nm|ny|nc|nd|oh|ok|or|pa|ri|sc|sd|tn|tx|ut|vt|va|wa|wv|wi|wy|dc)-loans/", h)
    check(not legacy, "No legacy /{city}-{st}-loans/ URLs (404 format)", f"{sorted(set(legacy))[:4]}")

    # --- rev-meta keeps the source link but drops the office location (owner rule 2026-11-02) ---
    metas = re.findall(r'<p class="rev-meta">.*?</p>', h)
    no_office = all(" office" not in m for m in metas)
    with_src = all(("share.google/" in m or "maps.app.goo.gl/" in m) for m in metas)
    check(no_office and with_src, "Review meta: source link kept, no office location",
          f"{len(metas)} cards, office-free: {no_office}, source links: {with_src}")

    # --- map is a Google Maps embed, never Leaflet (owner rule 2026-11-02) ---
    no_leaflet = "leaflet" not in h.lower()
    has_frame = 'class="map-frame"' in h
    gmap = ("<iframe" in h and "output=embed" in h
            and ("maps.google.com/maps" in h or "google.com/maps" in h))
    check(no_leaflet and (not has_frame or gmap), "Map is a Google Maps embed iframe (no Leaflet)",
          f"leaflet-free: {no_leaflet}, map-frame: {has_frame}, google embed: {gmap}")

    # --- nearby-cities line sits under the map (owner rule 2026-11-02) ---
    nearby = "The services are available for the residents of " in h
    check(not has_frame or nearby, "Nearby-cities line under the map", f"present: {nearby}")

    return results

def main():
    args = sys.argv[1:]
    city = None
    if "--city" in args:
        ci = args.index("--city")
        city = args[ci+1]
        args = args[:ci] + args[ci+2:]
    if not args:
        print("usage: validate.py page.html [--city Name]")
        sys.exit(2)
    path = args[0]
    results = validate(path, city)
    fails = [r for r in results if not r[0]]
    for ok, rule, detail in results:
        mark = "PASS" if ok else "FAIL"
        line = f"[{mark}] {rule}"
        if detail and not ok:
            line += f"  -> {detail}"
        print(line)
    print("-" * 50)
    if fails:
        print(f"RESULT: FAIL ({len(fails)} of {len(results)} rules failed)")
        sys.exit(1)
    else:
        print(f"RESULT: PASS (all {len(results)} rules)")
        sys.exit(0)

if __name__ == "__main__":
    main()
