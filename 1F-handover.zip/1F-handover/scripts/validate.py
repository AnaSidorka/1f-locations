#!/usr/bin/env python3
"""
1F page validator. Runs the full checklist against a built city page and prints
PASS/FAIL per rule plus a final verdict. Usage:

    python3 validate.py path/to/city-st-loans-NEW.html [--city "Covington"]

Spec v3: the statistics block is 6 stat-cards (each with a source line) plus one
five-year income table. See references/page-spec.md 5c.

If --city is omitted it is guessed from the <h1>. Exit code 0 = all pass, 1 = any fail.
Every rule maps to a line in references/page-spec.md and references/checklist.md.
"""
import re, sys, json
from collections import Counter

def load(path):
    return open(path, encoding="utf-8").read()

def strip_scripts_styles(h):
    h = re.sub(r"<script.*?</script>", "", h, flags=re.S)
    h = re.sub(r"<style.*?</style>", "", h, flags=re.S)
    return h

def text_of(h):
    return re.sub(r"<[^>]+>", " ", strip_scripts_styles(h))

def section(h, marker):
    i = h.find(marker)
    if i < 0:
        return ""
    s = h.rfind("<section", 0, i)
    e = h.find("</section>", i)
    return h[s:e+10] if s >= 0 and e >= 0 else ""

# H1 varies with the state's product regime -- see references/page-spec.md 2:
#   payday available        -> "Payday Loans in {City}, {State}"
#   short-term replaces it  -> "Short-term loans in {City}, {State}"
#   payday prohibited       -> "Payday loan alternatives in {City}, {State}"
H1_FORMS = r"(?:Payday Loans|Short-term loans|Payday loan alternatives) in"

def guess_city(h):
    m = re.search(r"<h1>" + H1_FORMS + r" ([^,<]+),", h)
    return m.group(1).strip() if m else None

def validate(path, city=None):
    h = load(path)
    if not city:
        city = guess_city(h) or ""
    txt = text_of(h)
    results = []  # (ok, rule, detail)

    def check(ok, rule, detail=""):
        results.append((bool(ok), rule, detail))

    # --- structure / order ---
    h2s = [re.sub(r"<[^>]+>", "", m.group(1)).strip() for m in re.finditer(r"<h2>(.*?)</h2>", h)]
    check("How 1F Cash Advance Works" in h, "How 1F Works block present")
    check("(not 1F Cash Advance)" in h, "How-1F bullet 3 phrasing '(not 1F Cash Advance)'")
    check("Cover an Emergency" in h, "Other Ways H2 = 'Cover an Emergency'")
    check("Credit union Payday Alternative Loans" in h, "CU card heading = 'Payday Alternative Loans'")
    check("NMLS ID 1814281" in h, "Topbar NMLS present")
    check("Storefront" not in h and "1F Cash Advance Store" not in h and "There Is No 1F" not in h,
          "Store block removed")
    check("Where to get payday loan" in h, "Office heading = 'Where to get payday loan'")
    check("Prefer to apply in person" not in h, "Office intro paragraph removed")

    # --- Can You Get ---
    cyg = section(h, "Can You Get a Payday Loan")
    cyg_txt = re.sub(r"<[^>]+>", " ", cyg)
    m = re.search(r"</h2>\s*<p>(Yes|No|Not)", cyg)
    check(bool(m), "Can You Get opens with direct Yes/No/Not")
    check("metro county" not in cyg_txt.lower(), "No 'metro county' (city != county)")
    # first paragraph <= 45 words (hard cap)
    fp = re.search(r"</h2>\s*<p[^>]*>(.*?)</p>", cyg, re.S)
    fp_words = len(re.sub(r"<[^>]+>", "", fp.group(1)).split()) if fp else 999
    check(fp_words <= 45, "Can You Get 1st paragraph <=45 words", f"{fp_words} words")

    # --- statistics (v3): exactly 6 stat-cards + exactly 1 table ---
    stats = section(h, "Borrowing and Debt")
    ncards = stats.count("stat-card")
    ntables = stats.count("<table")
    check(ncards == 6, "Statistics = exactly 6 stat-cards", f"{ncards}")
    check(ntables == 1, "Statistics = exactly 1 table", f"{ntables}")
    # the city must be named in the block (H2 carries it); geography labels on county-level
    # figures are a manual check -- see page-spec.md 5c
    check(city and city in stats, "Statistics reference the city", city)
    # v3: the table is a five-year series, oldest year first
    years = re.findall(r"<tr><td>(\d{4})</td>", stats)
    check(len(years) == 5 and years == sorted(years),
          "Statistics table is a 5-year series, oldest first", f"{years}")
    # v3: every stat-card carries its own source line
    nsrc = stats.count('class="src"')
    check(ncards > 0 and nsrc == ncards,
          "Every stat-card carries a source line", f"{nsrc} source lines for {ncards} cards")

    # --- FAQ: exactly 3, each answer <=60 words, page==schema ---
    faq = section(h, "Borrowers Ask")
    ans = [re.sub(r"<[^>]+>", "", m.group(1)) for m in re.finditer(r'<div class="a">(.*?)</div>', faq, re.S)]
    check(len(ans) == 3, "FAQ = exactly 3 questions", f"{len(ans)}")
    long_ans = [len(a.split()) for a in ans if len(a.split()) > 60]
    check(not long_ans, "FAQ answers each <=60 words", f"long: {long_ans}")
    # schema sync
    page_q = [re.sub(r"<[^>]+>", "", m.group(1)).strip() for m in re.finditer(r"<summary>(.*?)</summary>", faq, re.S)]
    sch_q = []
    for b in re.findall(r'<script type="application/ld\+json">(.*?)</script>', h, re.S):
        try:
            d = json.loads(b)
            if d.get("@type") == "FAQPage":
                sch_q = [q["name"] for q in d["mainEntity"]]
        except Exception:
            pass
    check(page_q == sch_q and len(page_q) == 3, "FAQ page copy == FAQPage schema")

    # --- Borrow Carefully: exactly 4 bullets, universal (no page-specific $ facts) ---
    bc = section(h, "Borrow Carefully")
    nbul = bc.count("<li>")
    check(nbul == 4, "Borrow Carefully = exactly 4 bullets", f"{nbul}")
    bc_txt = re.sub(r"<[^>]+>", " ", bc)
    # universal check: a $ figure inside Borrow Carefully is a page-specific fact (not allowed)
    check(not re.search(r"\$\d", bc_txt), "Borrow Carefully has no page-specific $ facts (universal only)")

    # --- Other Ways: 4 cards incl. bank ---
    ow = section(h, "Other Ways to Cover")
    check(ow.count("alt-card") == 4, "Other Ways = 4 cards", f"{ow.count('alt-card')}")
    check("Bank small-dollar" in h, "Bank small-dollar card present")

    # --- Products: exactly 2 cards, heading/link in sync ---
    i = h.find("Loan Products")
    if i < 0:
        i = h.find("Loan Options")
    prod = h[h.rfind("<section", 0, i):h.find("</section>", i)] if i >= 0 else ""
    nprod = prod.count('<div class="prod-card">')
    check(nprod == 2, "Products = exactly 2 cards", f"{nprod}")

    # --- Law: table present, <=8 rows, no statutory citations in the visible table ---
    law = section(h, "Law at a Glance")
    law_rows = law.count("<tr>")
    check(law_rows and law_rows - 1 <= 8, "Law table <=8 rows", f"{max(law_rows-1,0)} rows")
    law_txt = re.sub(r"<[^>]+>", " ", law)
    # heavy citation markers like "C.R.S.", "§ 5-3.1" or "R.S. 9:" repeated -> overload
    cites = len(re.findall(r"§|C\.R\.S\.|R\.S\.\s*\d", law_txt))
    check(cites <= 2, "Law table not overloaded with statute citations", f"{cites} citation marks")
    # no water paragraph after table
    after = law[law.find("</table>")+8:] if "</table>" in law else ""
    after_ps = re.findall(r"<p[^>]*>(.*?)</p>", after, re.S)
    water = [p for p in after_ps if "class=\"fine\"" not in after and len(re.sub(r"<[^>]+>","",p).split()) > 45]
    check(len(after_ps) <= 1, "No water paragraphs after Law table", f"{len(after_ps)} paras after table")

    # --- ZIP only in offices, not in Apply H2 ---
    # H2 блока Apply: "How to apply from {City} with 1F Cash Advance" (см. page-spec 2).
    # Регистронезависимо, чтобы правило продолжало ловить ZIP при любой форме заголовка.
    check(not re.search(r"How to apply from [^<]+ \d{5}", h, re.I), "ZIP removed from Apply H2")

    # --- tone: no banned phrases ---
    banned = ["lands hardest", "bites hardest", "hurts most", "makes the due date risky",
              "no cushion", "little financial slack", "honest reading", "awkward moment",
              "most expensive option", "will beat a payday loan every time", "the cheapest"]
    hits = [b for b in banned if b in txt.lower()]
    check(not hits, "No banned alarming/absolute phrases", f"{hits}")

    # --- AI marker in author bio ---
    tier1 = ["navigate", "delve", "leverage", "robust", "seamless", "tapestry", "testament"]
    ai_hits = [w for w in tier1 if re.search(r"\b" + w, txt, re.I)]
    check(not ai_hits, "No Tier-1 AI vocabulary", f"{ai_hits}")

    # --- numbers <=2 ---
    money = [x[0] for x in Counter(re.findall(r"\$[\d,]+", txt)).most_common() if x[1] > 2]
    pct = [x[0] for x in Counter(re.findall(r"\d+(?:\.\d+)?%", txt)).most_common() if x[1] > 2]
    check(not money, "Every $ figure <=2 occurrences", f"{money}")
    check(not pct, "Every percentage <=2 occurrences", f"{pct}")

    # --- 6 JSON-LD, valid, correct set ---
    types = []
    valid = True
    for b in re.findall(r'<script type="application/ld\+json">(.*?)</script>', h, re.S):
        try:
            types.append(json.loads(b).get("@type"))
        except Exception:
            valid = False
    want = {"Organization", "WebPage", "BreadcrumbList", "FAQPage", "Article", "Service"}
    check(valid and want.issubset(set(types)), "6 JSON-LD present and valid", f"{types}")

    # --- placeholders resolved ---
    check("{{" not in h, "No unresolved {{placeholders}}")

    # --- balanced tags ---
    bad = [t for t in ["section","div","p","h1","h2","h3","ul","li","table","tr","td","details","summary"]
           if len(re.findall(r"<"+t+r"[ >]", h)) != h.count("</"+t+">")]
    check(not bad, "Balanced tags", f"{bad}")

    # --- offices present ---
    check(h.count('<div class="office-card">') >= 1, "At least one office card")

    return results

def main():
    args = sys.argv[1:]
    city = None
    if "--city" in args:
        ci = args.index("--city")
        city = args[ci+1]
        args = args[:ci] + args[ci+2:]
    if not args:
        print("usage: validate.py page.html [--city Name]")
        sys.exit(2)
    path = args[0]
    results = validate(path, city)
    fails = [r for r in results if not r[0]]
    for ok, rule, detail in results:
        mark = "PASS" if ok else "FAIL"
        line = f"[{mark}] {rule}"
        if detail and not ok:
            line += f"  -> {detail}"
        print(line)
    print("-" * 50)
    if fails:
        print(f"RESULT: FAIL ({len(fails)} of {len(results)} rules failed)")
        sys.exit(1)
    else:
        print(f"RESULT: PASS (all {len(results)} rules)")
        sys.exit(0)

if __name__ == "__main__":
    main()
