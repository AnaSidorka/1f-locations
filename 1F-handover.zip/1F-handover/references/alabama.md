# Alabama — verified figures and ready state blocks

**H1-режим: первая форма** — `Payday Loans in {{City}}, {{State}}` (P3-11): payday разрешён
и выдаётся. Продукт — deferred presentment, один платёж, как в Луизиане.

## Verified legal figures

Источник — обязательное уведомление заёмщику, Приложение A к правилу **155-2-4-.13**
(Alabama State Banking Department, Bureau of Loans), плюс FAQ государственной базы.
Оба документа открыты 16 сентября 2026.

- Notice (PDF): https://banking.alabama.gov/wp-content/uploads/2023/06/155_2_4_13_App_A.pdf
- Database FAQ: https://banking.alabama.gov/bol/statewide-deferred-presentment-database-faq/
- Регулятор: **Alabama State Banking Department, Bureau of Loans** — https://banking.alabama.gov/bol/

| Item | Verified value | Откуда |
|---|---|---|
| Governing law | Deferred Presentment Services Act, Code of Alabama §5-18A; правила — глава 155-2-4 | BOL Regulations |
| Maximum loan | **$500** — предел на заёмщика **суммарно у всех лицензиатов**, не на один заём | Notice |
| Fee | **17.5% of the cash advance**; в пересчёте **$17.50 per $100** | Notice + Database FAQ |
| Other fees | **No other fees may be charged** | Notice |
| Term | не менее **10 дней** и не более **31 дня** | Notice |
| Renewal | продление **один раз**, за дополнительную комиссию | Notice |
| NSF | одноразовая плата до **$30.00** | Notice |
| Court enforcement | судебные издержки и до **15%** от номинала чека | Notice |
| Database | все займы сверяются в государственной базе; плата лицензиата **$2.00** за транзакцию с 1 янв 2025 и **не перекладывается на заёмщика** | Database FAQ |
| No arrest | за чек нельзя арестовать, кроме случая, когда счёт был закрыт **до** дня займа | Notice |
| Cutoff for Apply step 3 | **11:30 am** (полоса AL в P2-12) | CLAUDE.md |

### Расчётные величины — помечать как расчёт, не как публикацию регулятора

В уведомлении таблица APR оставлена **пустой**: её заполняет лицензиат под конкретный заём.
Поэтому APR на странице — вычисление из проверенной ставки, а не цифра регулятора.

- **APR на 14-дневный срок при максимальной комиссии:** 17.5% × 365 / 14 = **≈456%**.
- **APR на предельный 31-дневный срок:** 17.5% × 365 / 31 = **≈206%**. Срок меняет APR вдвое —
  не пиши одно число как «APR в Алабаме».
- **Комиссия при максимуме:** 17.5% от $500 = **$87.50**.

**Расчёт подтверждён внутренним гидом.** Страница
https://1firstcashadvance.org/loans-by-state/alabama/ (открыта 16 сентября 2026, заголовок
«Payday Loans in Alabama | 1F Cash Advance») печатает те же $500, 17.5%, NSF $30, срок 10–31 день
и **APR 456.25%**, а для займа $500 — итог $587.50. Все четыре величины сошлись с уведомлением
регулятора. Поэтому, в отличие от Луизианы, ссылку на внутренний гид ставить **можно**:
там те же числа, что на странице города.

### NOT verified — do not publish

- **Период охлаждения между займами.** В уведомлении его нет. Пока нет цитаты регулятора —
  на страницу не идёт.
- **Число платежей в рассрочке при невозможности погасить.** Уведомление говорит про
  «equal monthly installments at no additional cost», но количество в извлечённом тексте
  не читается. Пиши без числа: «an installment plan at no additional cost».
- Любая цифра «средний APR в Алабаме» из небанковских источников (Pew и подобные).

### Ловушка

**$500 — это потолок на заёмщика по всем лицензиатам сразу, а не на один заём.** Формулировка
«maximum loan of $500» вводит в заблуждение: человек с открытым займом на $300 может взять
не $500, а $200. Пиши «$500 across all lenders at once».

## Alabama city parameters

ZIP и региональную привязку подтверждать по каждому городу при сборке (P1-2).
Округ нужен для серий FRED — имя серии подтверждает округ.

| City | County | region label | ZIP | cutoff |
|---|---|---|---|---|
| Anniston | Calhoun County | — уточнить | — | 11:30 am |
| Birmingham | Jefferson County | — уточнить | — | 11:30 am |
| Dothan | Houston County | — уточнить | — | 11:30 am |
| Eufaula | Barbour County | — уточнить | — | 11:30 am |
| Foley | Baldwin County | — уточнить | — | 11:30 am |
| Huntsville | Madison County | — уточнить | — | 11:30 am |
| Northport | Tuscaloosa County | — уточнить | — | 11:30 am |
| Oneonta | Blount County | — уточнить | — | 11:30 am |

Округа проверять при первой сборке города: заголовок серии `MHIAL01<FIPS округа>A052NCEN`
на fred.stlouisfed.org печатает имя округа — он и есть подтверждение.

## Ready state blocks (change only {{City}}/{{region}}/{{County}})

### Loan Products (AL)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {{City}}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A small advance against your next paycheck. You get cash now and repay it in one payment, on a term Alabama sets between 10 and 31 days. The fee is a percent of the amount advanced.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in monthly payments, not all at once. It is unsecured and has a set end date. If you need a bigger amount or more time, this is often cheaper than a payday loan.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
```

### Alabama Law at a Glance
8 строк данных из 8 — запас 0. Одна метка `§` из двух разрешённых (P2-6).
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>Alabama Law at a Glance</h2>
    <p>These are the payday rules for all of Alabama, including {{City}}. In plain terms: how much you can get, what it costs, and what happens if you cannot pay on time. Full legal detail is in the <a href="https://1firstcashadvance.org/loans-by-state/alabama/">Alabama state guide</a>.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>Alabama position</th></tr>
      <tr><td>Governing law</td><td>Deferred Presentment Services Act, Code of Alabama §5-18A, overseen by the State Banking Department</td></tr>
      <tr><td>Maximum loan</td><td>$500 across all lenders at once, checked against a statewide database</td></tr>
      <tr><td>Fee</td><td>17.5% of the amount advanced, and no other fees are allowed</td></tr>
      <tr><td>Term</td><td>No shorter than 10 days and no longer than 31 days</td></tr>
      <tr><td>Renewal</td><td>One renewal only, on payment of another fee</td></tr>
      <tr><td>Returned check</td><td>A single charge of up to $30</td></tr>
      <tr><td>If it goes to court</td><td>Court costs plus up to 15% of the check face</td></tr>
      <tr><td>Trouble repaying</td><td>An installment plan at no additional cost</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example: at the top of the state limit the fee works out to about $87.50, and on a 14-day term that prices out near 456% APR. These are illustrative figures at the current limits, not quoted offers.</p>
  </div>
</section>
```

### Other Ways to Cover an Emergency (AL)
```html
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {{City}}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {{City}} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below payday.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call your {{County}} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
```

### Borrow Carefully (AL)
Долларовых сумм внутри буллетов нет — это регресс по P2-5.
```html
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Borrow the minimum, not the maximum.</strong> Take the amount that closes the gap. The fee is a percentage, so every extra dollar raises the charge, and the state ceiling counts everything you already owe to other lenders.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you cannot repay on time, ask about the installment plan before agreeing to a renewal.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="https://banking.alabama.gov/bol/">Alabama State Banking Department, Bureau of Loans</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
```

## Distinct local angles (заполнять по мере сборки городов)
- Birmingham — крупнейший город штата, Jefferson County.
- Huntsville — Madison County, аэрокосмический и оборонный работодатель.
- Foley — Baldwin County, побережье, сезонная занятость.
- Остальные пять — угол выбирается из данных прихода при сборке, не придумывается заранее.
