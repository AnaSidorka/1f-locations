#!/usr/bin/env python3
"""Добавляет в готовую страницу два блока, которые есть на живом сайте:
CTA «Ready to Apply from {City}?» и «See All States».

Блоки вставляются вокруг блока городских ссылок: CTA перед ним, список штатов после,
авторы остаются последними. Скрипт идемпотентен — повторный запуск ничего не меняет.

usage: python3 scripts/add_site_blocks.py <file.html> [...]
"""
import re, sys, os

STATE_LINKS = [
    ("Alabama", "alabama"), ("Alaska", "alaska"), ("Arizona", "payday-loans-in-arizona"),
    ("Arkansas", "arkansas"), ("California", "payday-loans-california"), ("Colorado", "payday-loans-colorado"),
    ("Connecticut", "connecticut"), ("Delaware", "payday-loans-delaware"), ("Florida", "payday-loans-florida"),
    ("Georgia", "georgia-loans"), ("Hawaii", "hawaii"), ("Idaho", "payday-loans-in-idaho"),
    ("Illinois", "illinois-loans"), ("Indiana", "in"), ("Iowa", "payday-loans-in-iowa"),
    ("Kansas", "payday-loans-kansas"), ("Kentucky", "payday-loans-kentucky"), ("Louisiana", "la"),
    ("Maine", "maine"), ("Maryland", "payday-loans-maryland"), ("Massachusetts", "payday-loans-in-massachusetts"),
    ("Michigan", "loans-in-michigan-online"), ("Minnesota", "payday-loans-in-minnesota"),
    ("Mississippi", "payday-loans-mississippi"), ("Missouri", "missouri"), ("Montana", "montana"),
    ("Nebraska", "nebraska"), ("Nevada", "payday-loans-nevada"), ("New Hampshire", "new-hampshire"),
    ("New Jersey", "payday-loans-new-jersey"), ("New Mexico", "nm"),
    ("North Carolina", "payday-loans-in-north-carolina"), ("North Dakota", "payday-loans-in-north-dakota"),
    ("Ohio", "ohio"), ("Oklahoma", "oklahoma-loans"), ("Oregon", "payday-loans-oregon"),
    ("Pennsylvania", "loans-in-pennsylvania"), ("Rhode Island", "rhode-island"),
    ("South Carolina", "south-carolina"), ("South Dakota", "south-dakota"),
    ("Tennessee", "payday-loans-tennessee"), ("Texas", "payday-loans-texas"), ("Utah", "payday-loans-in-utah"),
    ("Vermont", "vermont"), ("Virginia", "virginia"), ("Washington", "payday-loans-washington"),
    ("West Virginia", "west-virginia"), ("Wisconsin", "wisconsin"), ("Wyoming", "payday-loans-in-wyoming"),
]

CSS = """.state-links{display:grid;grid-template-columns:repeat(4,1fr);gap:0 24px;margin-top:16px;font-size:15px}
.state-links p{margin:0 0 7px}
@media(max-width:900px){.state-links{grid-template-columns:repeat(2,1fr)}}
"""

BASE = "https://1firstcashadvance.org"


def cta(city):
    return (
        '<section class="section">\n  <div class="wrap" style="max-width:860px;text-align:center">\n'
        f'    <h2>Ready to Apply from {city}?</h2>\n'
        '    <p class="small" style="margin:14px 0 18px">I have read and agree to the '
        f'<a href="{BASE}/terms/">Terms</a>, <a href="{BASE}/rates/">Rates</a>, '
        f'<a href="{BASE}/privacy-policy/">Privacy Policy</a> and <a href="{BASE}/legal-disclaimer/">Disclaimer</a> '
        'before submitting a loan request.</p>\n'
        f'    <a class="btn" href="{BASE}/apply/">Apply Now</a>\n  </div>\n</section>\n'
    )


def states_block():
    cols = [STATE_LINKS[i::4] for i in range(4)]
    inner = "".join(
        '<div class="st-col">' + "".join(f'<p><a href="{BASE}/loans-by-state/{s}/">{n}</a></p>' for n, s in col) + "</div>"
        for col in cols
    )
    return (
        '<section class="section">\n  <div class="wrap">\n'
        '    <p class="eyebrow">Every state we cover</p>\n    <h2>See All States</h2>\n'
        f'    <div class="state-links">{inner}</div>\n  </div>\n</section>\n'
    )


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == "hero":
            continue
        want = "section alt" if i % 2 == 1 else "section"
        if cls != want:
            te = h.find(">", pos)
            idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f" {idm.group(0)}" if idm else "") + ">" + h[te + 1:]
    return h


def process(path):
    t = open(path, encoding="utf-8").read()
    if "See All States" in t:
        return "уже есть"
    city = re.search(r"<h1[^>]*>[^,<]*?in ([^,<]+),", t, re.I)
    city = city.group(1).strip() if city else None
    if not city:
        return "город не распознан"
    anchor = '<section class="section">\n  <div class="wrap">\n    <p class="eyebrow">Across the state</p>'
    if anchor not in t:
        anchor = re.search(r'<section class="[^"]*">\s*<div class="wrap">\s*<p class="eyebrow">Across the state</p>', t)
        if not anchor:
            return "блок городов не найден"
        anchor = anchor.group(0)
    t = t.replace(anchor, cta(city) + anchor, 1)
    end = t.find("</section>", t.find("Across the state")) + len("</section>")
    t = t[:end] + "\n" + states_block() + t[end:]
    if ".state-links{" not in t:
        t = t.replace("</style>", CSS + "</style>", 1)
    t = fix_zebra(t)
    open(path, "w", encoding="utf-8").write(t)
    return "добавлено"


if __name__ == "__main__":
    for p in sys.argv[1:]:
        print(f"{os.path.basename(p):42} {process(p)}")
