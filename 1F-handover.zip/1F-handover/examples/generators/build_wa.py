#!/usr/bin/env python3
"""Build the two Washington city pages (spec v3) into builds/2026-09-19-wa/."""
import html, json, os, re, sys

ROOT = "/workspace"
OUT = os.path.join(ROOT, "builds/2026-09-19-wa")
BASE = os.path.join(ROOT, "builds/Alabama Final/dothan-al-loans-NEW.html")

STATE, ST = "Washington", "WA"
DATE, DATE_ISO, CUTOFF = "September 19, 2026", "2026-09-19", "9:30 am"
DEBT = {2020: 69630, 2021: 75470, 2022: 82300, 2023: 82130, 2024: 83820}
STATE_MHI_2024 = 99309

RCW073 = "https://app.leg.wa.gov/rcw/default.aspx?cite=31.45.073"
RCW084 = "https://app.leg.wa.gov/rcw/default.aspx?cite=31.45.084"
RCW105 = "https://app.leg.wa.gov/rcw/default.aspx?cite=31.45.105"
CHAPTER = "https://app.leg.wa.gov/rcw/default.aspx?cite=31.45&full=true"
DFI = "https://dfi.wa.gov/financial-education/information/payday-loans"

CITIES = [
 dict(city="Seattle", county="King County", fips="033",
      mhi={2020: 102620, 2021: 110351, 2022: 116044, 2023: 120672, 2024: 121984},
      offices=[("701 5th Ave Suite 4200", "98104", "24"), ("1930 6th Ave S #104", "98134", "5:00 PM"),
               ("340 15th Ave E #311", "98112", "24"), ("1916 2nd Ave Suite 312", "98101", "8:00 PM"),
               ("10500 Greenwood Ave N", "98133", "7:00 PM"), ("528 Rainier Ave S", "98144", "8:00 PM"),
               ("116 SW 148th St Ste D-120", "98166", "7:00 PM")],
      p1="Yes. A licensed lender can advance up to $700, or 30% of your gross monthly income if that is lower, for no more than 45 days. Fees are capped by statute, and the state's own example puts a two-week advance at 391% APR.",
      p2="King County income rose in every year since 2020, yet 2024 added the least of any year in the table, well under a fifth of the 2021 rise. A payday advance comes due in one piece within weeks, so size it against the pay now landing in your account, not against a repeat of an earlier year.",
      lbl4="Median household income in King County in 2024, the latest year in the table below",
      growth="County income grew about nineteen percent in five years, against twenty for state debt per person.",
      housing="More than a third of households here",
      faq=[("What happens if I cannot repay on the due date?",
            "Tell the lender before the check is deposited. At your request it must move the loan onto an installment plan at no added charge, running at least 90 days for smaller loans and longer for larger ones. Paying the plan off early costs nothing, and no new payday loan is allowed while it runs."),
           ("Can I change my mind after I sign?",
            "Yes. You have until the close of the next business day at the place the loan was made. Return the principal in cash, or hand back the lender's own check, and the loan is undone. The lender cannot charge you for cancelling and must return the check you left as security."),
           ("How fast could the money reach my account?",
            "If a lender approves you and the application is finalized by 9:30 am local time on a weekday, funds can arrive the same day. Later applications, weekends and bank holidays move funding to the next business day, and same-day deposit is not available to every customer.")]),
 dict(city="Vancouver", county="Clark County", fips="011",
      mhi={2020: 76929, 2021: 83790, 2022: 91149, 2023: 97240, 2024: 99396},
      offices=[("204 SE Park Plaza Dr #105", "98684", "5:00 PM"), ("8902 NE 5th Ave Suite 109", "98665", "5:30 PM"),
               ("8441 NE Vancouver Mall Dr Suite 110", "98662", "8:00 PM"), ("221 NE 104th Ave Ste 202-A", "98664", "5:00 PM"),
               ("16910 NE 79th Way", "98682", "6:30 PM"), ("615A SE Chkalov Dr Ste 8", "98683", "5:30 PM")],
      p1="Yes, and the ceiling moves with your pay: $700 or 30% of gross monthly income, whichever is less, repaid within 45 days. Fees are set by statute, and the state's published example works out to 391% APR over two weeks.",
      p2="Clark County income climbed in every year since 2020 and ended 2024 almost level with the state median. A rising county median still does not decide your loan, because the ceiling is measured against your own gross pay and the balance falls due within weeks, so test the repayment against the month you are in.",
      lbl4="Median household income in Clark County in 2024, its highest point in the table below",
      growth="County income grew about twenty-nine percent in five years, ahead of twenty for state debt per person.",
      housing="Nearly a third of households here",
      faq=[("How many payday loans can I have in a year?",
            "Eight, counted across every licensed lender through the statewide database. A lender also cannot advance you anything while you are in a payment plan, or in default on another loan, until that loan is paid or two years have passed from the day it started."),
           ("What can a lender charge if my check bounces?",
            "One charge of $25 over the life of the loan, whether it comes from a returned check, a missed plan payment, or both. If the lender sues over a dishonored check it may add the cost of collection the check statute allows, but not attorney's fees, interest or damages. Threatening criminal charges to collect is against state law."),
           ("Does the license matter if the lender is online?",
            "Yes, and it is your strongest protection. Anyone making small loans to people in Washington needs a state endorsement, storefront or website alike. A loan made without one cannot be collected here. Lenders owned by tribes sit outside the department's reach, so check before you hand over bank details.")]),
]
def slug(c):
    return c.lower().replace(" ", "-") + "-wa-loans"


def money(n):
    return "${:,}".format(n)


def fix_zebra(h):
    secs = [(m.start(), m.group(1)) for m in re.finditer(r'<section class="([^"]*)"', h)]
    for i in range(len(secs) - 1, -1, -1):
        pos, cls = secs[i]
        if cls == 'hero':
            continue
        want = 'section alt' if i % 2 == 1 else 'section'
        if cls != want:
            te = h.find('>', pos); idm = re.search(r'id="[^"]*"', h[pos:te + 1])
            h = h[:pos] + f'<section class="{want}"' + (f' {idm.group(0)}' if idm else '') + '>' + h[te + 1:]
    return h


def build(c):
    base = open(BASE, encoding="utf-8").read()
    head = base[:base.find("</head>")]
    city, county = c["city"], c["county"]
    h1 = f"Payday Loans in {city}, {STATE}"
    title = f"{h1} | 1F Cash Advance"
    head = re.sub(r"<title>.*?</title>", f"<title>{title}</title>", head)
    assert "<!-- skill-version: v2 -->" in head
    fred_c = f"https://fred.stlouisfed.org/series/MHIWA53{c['fips']}A052NCEN"
    fred_s = "https://fred.stlouisfed.org/series/MHIWA53000A052NCEN"
    dp04 = f"https://fred.stlouisfed.org/series/DP04ACS053{c['fips']}"
    m24 = c["mhi"][2024]
    gap = STATE_MHI_2024 - m24
    gap_txt = f"{money(abs(gap))} {'below' if gap > 0 else 'above'}"
    gap_lbl = f"How far {county} sat {'under' if gap > 0 else 'above'} the {STATE} median in 2024"

    # Hero (global, fixed) — copied from base, city/state swapped
    hs = base.find('<div class="topbar">'); he = base.find("</section>", base.find('<section class="hero">')) + len("</section>")
    hero = base[hs:he]
    hero = hero.replace("Payday Loans in Dothan, Alabama", h1).replace("licensed Alabama lender", f"licensed {STATE} lender")
    hero = hero.replace("Updated: September 3, 2026", f"Updated: {DATE}")
    assert "Dothan" not in hero and "Alabama" not in hero

    offices = "".join(
        f'<div class="office-card">\n<p class="office-addr">{html.escape(st)}<br>{city}, {ST} {z}</p>\n'
        f'<p class="office-hours">' + ("Open 24 hours" if close == "24" else f"Open today 8:00 AM &ndash; {close}") + '</p>\n</div>'
        for st, z, close in c["offices"])

    rows = "\n".join(
        f"<tr><td>{y}</td><td>{money(c['mhi'][y])}</td><td>{money(DEBT[y])}</td><td>{money(round(c['mhi'][y] / 12 * 0.70))}</td></tr>"
        for y in range(2020, 2025))

    others = [x["city"] for x in CITIES if x["city"] != city]
    links = " &middot; ".join(f'<a href="https://1firstcashadvance.org/{slug(o)}/">{o}</a>' for o in others)

    faq_html = "\n".join(
        f'    <details class="faq">\n      <summary>{q}</summary>\n      <div class="a">{a}</div>\n    </details>'
        for q, a in c["faq"])

    body = f"""
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Three steps</p>
    <h2>How to apply from {city} with 1F Cash Advance</h2>
    <div class="steps">
      <div class="step"><div class="n">1</div><h3>Fill out the online form</h3><p>The application is open 24/7 and takes about five minutes.</p></div>
      <div class="step"><div class="n">2</div><h3>Get a decision</h3><p>We check your details and pass them to lenders licensed in {STATE}, usually within the hour during business hours.</p></div>
      <div class="step"><div class="n">3</div><h3>Receive the funds</h3><p>Approved funds go straight to your bank account. Same-day cutoff: {CUTOFF} local time.*</p></div>
    </div>
    <p class="fine">*Same-day deposits are not available to all customers. Applications finalized after the cutoff or on weekends and bank holidays fund on the next business day. Approval is not guaranteed and depends on verification of your income and application details.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">What we offer</p>
    <h2>Loan Products Available in {city}</h2>
    <div class="prod-grid">
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-wallet2.svg" alt="" width="46" height="46" loading="lazy"><h3>Payday Loans</h3>
        <p>A small advance against a personal check you write today. The lender holds the check until the date in your agreement, and you repay the full amount in one payment. It is built for a short gap between paychecks.</p>
        <a href="https://1firstcashadvance.org/payday-loans/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Payday Loans &rarr;</a></div>
      <div class="prod-card"><img class="prod-ic" src="https://1firstcashadvance.org/wp-content/uploads/2019/08/ico-calender.svg" alt="" width="46" height="46" loading="lazy"><h3>Installment Loans</h3>
        <p>A larger loan you pay back in monthly payments, not all at once. It is usually unsecured and has a set end date. If you need a bigger amount or more time, this is often cheaper than a payday loan.</p>
        <a href="https://1firstcashadvance.org/installment-loan/" style="display:inline-block;margin-top:16px;font-weight:600">Explore Installment Loans &rarr;</a></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Before you start</p>
    <h2>What You Need to Qualify</h2>
    <ul class="checks" style="margin-top:16px">
      <li>Government-issued photo ID</li>
      <li>Social Security number</li>
      <li>Active checking account with a routing number</li>
      <li>Recent pay stub or other proof of income</li>
      <li>Proof of your {STATE} address</li>
      <li>Working phone number and email</li>
      <li>Age 18 or older</li>
    </ul>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">How it works</p>
    <h2>How 1F Cash Advance Works</h2>
    <p>1F Cash Advance is a loan connector and financial marketplace, not a direct lender. We do not fund loans, approve applications or set rates. We take one request and match it to lenders licensed in {STATE} and allowed to operate there.</p>
    <ul class="resp-list" style="margin-top:14px">
      <li><strong>You submit one request.</strong> A single online form, free to use, with a soft check that does not affect your credit score.</li>
      <li><strong>We route it to licensed lenders.</strong> Your details go to lenders authorized to operate in {STATE}, not to a single desk.</li>
      <li><strong>The lender decides.</strong> If one makes an offer, that lender (not 1F Cash Advance) approves it, sets the rate and fee within state law, and funds the loan to your bank account.</li>
    </ul>
    <p style="margin-top:14px;margin-bottom:0">Because the lender sets the terms, always read the rate and total cost in the offer before you accept.</p>
  </div>
</section>
<section class="section alt">
  <div class="wrap">
    <p class="eyebrow">Visit us</p>
    <h2>Where to get payday loan {city}</h2>
    <div class="office-grid">
{offices}
</div>
  </div>
</section>
<section class="section">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The short version</p>
    <h2>Can You Get a Payday Loan in {city}?</h2>
    <p>{c['p1']}</p>
    <p style="margin-top:14px">{c['p2']}</p>
  </div>
</section>
<section class="section alt"><div class="wrap" style="max-width:860px">
<p class="eyebrow">Local data</p><h2>Borrowing and Debt in {city}: What the Numbers Show</h2>
<div class="stat-grid">
<div class="stat-card"><div class="num gold">Capped by income</div><div class="lbl">The most you can owe all payday lenders at once is set by statute and by your own monthly pay</div><div class="src">Source: <a href="{RCW073}">RCW 31.45.073, Washington State Legislature</a></div></div>
<div class="stat-card"><div class="num navy">Tiered fee</div><div class="lbl">The charge is a share of principal, and the rate drops on the upper part of a larger loan</div><div class="src">Source: <a href="{RCW073}">RCW 31.45.073, Washington State Legislature</a></div></div>
<div class="stat-card"><div class="num navy">Triple-digit</div><div class="lbl">The rate in the regulator's own two-week example, whatever your income or credit history</div><div class="src">Source: <a href="{DFI}">Washington Department of Financial Institutions</a></div></div>
<div class="stat-card"><div class="num gold">{money(m24)}</div><div class="lbl">{c['lbl4']}</div><div class="src">Source: <a href="{fred_c}">U.S. Census Bureau SAIPE via FRED</a></div></div>
<div class="stat-card"><div class="num navy">{gap_txt}</div><div class="lbl">{gap_lbl}</div><div class="src">Source: <a href="{fred_s}">Census SAIPE for Washington via FRED</a></div></div>
<div class="stat-card"><div class="num navy">Plan on request</div><div class="lbl">A borrower who cannot repay on time can move the loan onto installments at no added charge</div><div class="src">Source: <a href="{RCW084}">RCW 31.45.084, Washington State Legislature</a></div></div></div>
<p class="tbl-cap">{county} median household income and {STATE} household debt, 2020 to 2024</p>
<table class="rate-table" style="margin-top:10px"><tr><th>Year</th><th>Median income</th><th>{STATE} debt per person</th><th>After housing</th></tr>
{rows}</table>
<p class="src-note" style="margin-top:12px">County income comes from <a href="{fred_c}">Census Bureau Small Area Income and Poverty Estimates</a>; the debt column comes from the <a href="https://www.newyorkfed.org/microeconomics/databank.html">New York Fed Consumer Credit Panel</a>. {c['growth']} <a href="{dp04}">{c['housing']}</a> spend thirty percent or more on housing.</p>
<p class="fine">A loan payment has to fit inside the last column, not the income beside it. {STATE} tests the ceiling against your own gross monthly pay as well as a flat cap, so it tracks your earnings and not a county average. The last column is a calculation, not a published figure: monthly county income after the standard housing share. It describes a typical household at the county median, not an approved loan amount.</p>
</div></section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">The legal picture, in brief</p>
    <h2>{STATE} Law at a Glance</h2>
    <p>These are the payday rules for all of {STATE}, including {city}. In plain terms: how much you can get, what it costs, and what happens if you cannot pay on time. The statute is <a href="{CHAPTER}">chapter 31.45 RCW</a>, and the <a href="{DFI}">Department of Financial Institutions</a> publishes the same limits for borrowers.</p>
    <table class="rate-table">
      <tr><th>Item</th><th>{STATE} position</th></tr>
      <tr><td>Governing law</td><td>Small loans under chapter 31.45 RCW, licensed and supervised by the Department of Financial Institutions</td></tr>
      <tr><td>Loan size</td><td>$700 or 30% of gross monthly income, whichever is lower, counting what you owe every lender</td></tr>
      <tr><td>Term</td><td>Due on or after your next payday, and never more than 45 days from the day you sign</td></tr>
      <tr><td>Fees</td><td>15% of the first $500 of principal, and 10% of any part above that</td></tr>
      <tr><td>Loans a year</td><td>No more than eight from all licensed lenders in any twelve-month period</td></tr>
      <tr><td>Payment plan</td><td>Granted on request at no added cost: at least 90 days for a loan of $400 or less, at least 180 days above that</td></tr>
      <tr><td>Default charges</td><td>One charge of $25 over the life of a loan, for a returned check, a missed plan payment, or both</td></tr>
      <tr><td>Unlicensed lenders</td><td>A small loan made without the state endorsement cannot be collected from you</td></tr>
    </table>
    <p class="fine" style="margin-top:12px">Representative example from the regulator: a $500 advance repaid in 14 days at the maximum fee carries an APR of 391%. These are the state's illustrative figures at the current limits, not quoted offers.</p>
  </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Compare first</p>
    <h2>Other Ways to Cover an Emergency in {city}</h2>
    <div class="alt-grid">
      <div class="alt-card"><h3>Credit union Payday Alternative Loans</h3><p>Call a federal credit union and ask if they offer a Payday Alternative Loan (PAL). It is a small loan with a rate cap around 28% APR. You need to be a member. Several credit unions serve the {city} area.</p></div>
      <div class="alt-card"><h3>Bank small-dollar programs</h3><p>Ask your own bank if they make small loans for existing customers. Some call them Balance Assist or Simple Loan. They often decide from your account history, and the cost is far below payday.</p></div>
      <div class="alt-card"><h3>Employer and paycheck advances</h3><p>Some employers and apps let you take a few hundred dollars of pay you already earned. Many charge no interest. Watch for tips and instant transfer fees.</p></div>
      <div class="alt-card"><h3>Utility and assistance programs</h3><p>If the problem is an electric or gas bill, call your {county} community action agency. Ask about LIHEAP and a payment plan. That is assistance, not a loan. Call before a shutoff.</p></div>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <div class="resp">
      <h2>Borrow Carefully</h2>
      <ul class="resp-list">
        <li><strong>Check the license before anything else.</strong> A payday lender in this state needs an endorsement from the regulator, and that holds for online lenders too. Confirm it before you share bank details.</li>
        <li><strong>Price the loan in dollars, not percentages.</strong> Ask for the total cost of credit and the due date in cash, and weigh it against income you are sure will arrive.</li>
        <li><strong>Protect the repayment date.</strong> Line the due date up with your pay schedule and keep the payment inside what remains after fixed bills. If you see a problem coming, talk to the lender before the date, not after it.</li>
        <li><strong>Borrow for one-time gaps only.</strong> If the shortfall repeats, a loan postpones the problem. A budget review or a nonprofit credit counselor does more than any payday loan.</li>
      </ul>
      <p style="margin-bottom:0">To verify a lender or file a complaint, contact the <a href="{DFI}">Washington Department of Financial Institutions</a> or the federal CFPB.</p>
    </div>
  </div>
</section>
<section class="section alt">
  <div class="wrap" style="max-width:860px">
    <p class="eyebrow">Still have questions?</p>
    <h2>{city} Borrowers Ask</h2>

{faq_html}
    </div>
</section>
<section class="section">
  <div class="wrap">
    <p class="eyebrow">Across the state</p>
    <h2>1F Cash Advance in Other {STATE} Cities</h2>
    <p style="max-width:760px">The same {STATE} rules apply statewide. See how they play out where you live:</p>
    <p style="font-size:15px">{links}</p>
  </div>
</section>
"""
    # Authors (global) — copied from base, county swapped
    a_s = base.rfind("<section", 0, base.find("Who wrote this")); a_e = base.find("</section>", a_s) + len("</section>")
    authors = base[a_s:a_e].replace("Houston County", county)
    assert "Dothan" not in authors and "Alabama" not in authors

    url = f"https://1firstcashadvance.org/{slug(city)}/"
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]}
    ld = [
        {"@context": "https://schema.org", "@type": "Organization", "@id": "https://1firstcashadvance.org/#org", "name": "1F Cash Advance", "url": "https://1firstcashadvance.org", "telephone": "+1-720-428-2247", "address": {"@type": "PostalAddress", "streetAddress": "2770 Canyon Blvd", "addressLocality": "Boulder", "addressRegion": "CO", "postalCode": "80302", "addressCountry": "US"}},
        {"@context": "https://schema.org", "@type": "WebPage", "name": title, "url": url, "inLanguage": "en-US", "isPartOf": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://1firstcashadvance.org/"}, {"@type": "ListItem", "position": 2, "name": "Loans by State", "item": "https://1firstcashadvance.org/loans-by-state/"}, {"@type": "ListItem", "position": 3, "name": STATE, "item": "https://1firstcashadvance.org/loans-by-state/washington/"}, {"@type": "ListItem", "position": 4, "name": city}]},
        faq_ld,
        {"@context": "https://schema.org", "@type": "Article", "headline": h1, "author": {"@type": "Person", "name": "Latoria Williams"}, "editor": {"@type": "Person", "name": "Marsha Welch"}, "reviewedBy": {"@type": "Person", "name": "Michael Lefler"}, "datePublished": DATE_ISO, "dateModified": DATE_ISO, "publisher": {"@id": "https://1firstcashadvance.org/#org"}},
        {"@context": "https://schema.org", "@type": "Service", "name": f"Payday loan matching in {city}, {ST}", "provider": {"@id": "https://1firstcashadvance.org/#org"}, "areaServed": {"@type": "City", "name": f"{city}, {STATE}"}, "serviceType": "Loan connector and financial marketplace"},
    ]
    scripts = "\n".join(f'<script type="application/ld+json">{json.dumps(x, ensure_ascii=False, indent=2 if x["@type"] == "FAQPage" else None)}</script>' for x in ld)

    page = head + "</head><body>\n" + hero + body + authors + "\n" + scripts + "\n</body></html>\n"
    page = fix_zebra(page)
    assert "{{" not in page, "placeholder left"
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    for c in CITIES:
        if only and c["city"] not in only:
            continue
        p = os.path.join(OUT, slug(c["city"]) + "-NEW.html")
        open(p, "w", encoding="utf-8").write(build(c))
        print("wrote", p)


if __name__ == "__main__":
    main()
