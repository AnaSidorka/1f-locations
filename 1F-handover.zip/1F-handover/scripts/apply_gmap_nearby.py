#!/usr/bin/env python3
"""
Applies the 2026-11-02 owner rules to a built city page:

1. Replaces the Leaflet map with a keyless Google Maps embed iframe
   (https://maps.google.com/maps?q=<office address>&z=16&output=embed, verified 200).
   The office-card <-> map link is kept: clicking a card (or Enter/Space) switches the
   iframe to that office and moves the .active class; the first card starts active.
2. Adds the nearby-cities line right under the map (no heading):
   "The services are available for the residents of ...".
3. Drops the office location from every rev-meta line, keeping the share.google link.

Usage: python3 scripts/apply_gmap_nearby.py <page.html>   (rewrites in place, idempotent)
"""
import re, sys
from urllib.parse import quote

LEAFLET_CSS = re.compile(r'<link rel="stylesheet" href="https://unpkg\.com/leaflet@[^"]*"[^>]*>\s*')
LEAFLET_JS = re.compile(r'<script src="https://unpkg\.com/leaflet@[^"]*"[^>]*></script>\s*')
INIT_JS = re.compile(r'<script>\s*var \w+MapEl = document\.getElementById.*?</script>\s*', re.S)
MAP_DIV = re.compile(r'<div class="map-frame"><div id="([a-z-]+-map)"[^>]*>.*?</div></div>', re.S)
OFFICE_ADDR = re.compile(r'<p class="office-addr">([^<]*)<br>([^<]*)</p>')
REV_OFFICE = re.compile(r'(<p class="rev-meta">[^<]*(?:<[^>]+>[^<]*)*?)</a> for our [^<]* office</p>')

CSS_EXTRA = (".map-frame iframe{display:block;width:100%;height:360px;border:0}\n"
             ".office-nearby{font-size:14px;color:var(--ink-soft);margin:12px 0 0}")

NEARBY = {
    "irvine": "Tustin, Santa Ana, Costa Mesa, Orange, North Tustin, Corona del Mar, Newport Beach, "
              "Laguna Woods, Lake Forest, Villa Park, Aliso Viejo, Foothill Ranch, Laguna Hills, "
              "Laguna Beach, and Mission Viejo",
    "nlv": "Las Vegas, Winchester, Sunrise Manor, Whitney, Nellis AFB, Paradise, Centennial Hills, "
           "Spring Valley, Summerlin South, and Enterprise",
    "kc": "Mission, Prairie Village, Gladstone, Independence, Raytown, Shawnee, Overland Park, "
          "Liberty, Lenexa, Grandview, Blue Springs, and Kansas City, KS",
    "greenfield": "New Palestine, Cumberland, Fortville, McCordsville, Lawrence, Pendleton, "
                  "Beech Grove, Fishers, Shelbyville, and Indianapolis",
    "tulsa": "Sand Springs, Jenks, Owasso, Sapulpa, Broken Arrow, Glenpool, Catoosa, Bixby, "
             "Collinsville, and Verdigris",
    "hiram": "Powder Springs, Dallas, Austell, Douglasville, Lithia Springs, Mableton, Kennesaw, "
             "Marietta, Acworth, Smyrna, Villa Rica, and Rockmart",
}


def embed_url(street, cityline):
    return "https://maps.google.com/maps?q=" + quote(f"{street}, {cityline}") + "&z=16&output=embed"


def apply(path):
    h = open(path, encoding="utf-8").read()
    if "leaflet" not in h.lower() and " for our " not in h and "office-nearby" in h:
        print(f"skip (already applied): {path}")
        return

    m = MAP_DIV.search(h)
    if not m:
        raise SystemExit(f"map div not found in {path}")
    map_id = m.group(1)
    slug = map_id[: -len("-map")]
    if slug not in NEARBY:
        raise SystemExit(f"no nearby list for map id {map_id}")
    city = h.split(f'id="{map_id}"')[0].rsplit("Payday", 1)[0]
    title_m = re.search(r"<title>([^|]+)\|", h)
    city_name = title_m.group(1).split(" in ")[-1].split(",")[0].strip() if title_m else slug

    addrs = OFFICE_ADDR.findall(h)
    if not addrs:
        raise SystemExit(f"no office addresses in {path}")
    views = [embed_url(s, c) for s, c in addrs]

    iframe = (f'<div class="map-frame"><iframe id="{map_id}" '
              f'title="Map of 1F Cash Advance offices in {city_name}" '
              f'src="{views[0]}" loading="lazy" referrerpolicy="no-referrer-when-downgrade" '
              f'allowfullscreen></iframe></div>\n'
              f'<p class="office-nearby">The services are available for the residents of '
              f'{NEARBY[slug]}.</p>')
    h = MAP_DIV.sub(lambda _: iframe, h, count=1)

    js_views = ",\n    ".join(f'"{v}"' for v in views)
    js = f'''<script>
(function () {{
  var frame = document.getElementById('{map_id}');
  if (!frame) return;
  var sec = frame.closest('section');
  var cards = sec ? sec.querySelectorAll('.office-card') : [];
  var views = [
    {js_views}
  ];
  cards.forEach(function (card, i) {{
    if (!views[i]) return;
    card.classList.add('clickable');
    card.setAttribute('tabindex', '0');
    var activate = function () {{
      cards.forEach(function (c, j) {{ c.classList.toggle('active', i === j); }});
      if (frame.src !== views[i]) frame.src = views[i];
    }};
    card.addEventListener('click', activate);
    card.addEventListener('keydown', function (e) {{
      if (e.key === 'Enter' || e.key === ' ') {{ e.preventDefault(); activate(); }}
    }});
  }});
  if (cards.length) cards[0].classList.add('active');
}})();
</script>
'''
    h = LEAFLET_JS.sub("", h)
    h2 = INIT_JS.sub(js, h, count=1)
    if h2 == h:
        raise SystemExit(f"leaflet init script not replaced in {path}")
    h = LEAFLET_CSS.sub("", h2)

    if ".office-nearby{" not in h:
        h = h.replace(".map-frame{border-radius:10px;overflow:hidden;margin-top:18px;border:1px solid var(--line)}",
                      ".map-frame{border-radius:10px;overflow:hidden;margin-top:18px;border:1px solid var(--line)}\n" + CSS_EXTRA, 1)

    h, nrev = REV_OFFICE.subn(r"\1</a></p>", h)

    open(path, "w", encoding="utf-8").write(h)
    print(f"updated {path}: {len(views)} office views, nearby={slug}, rev-meta fixed: {nrev}")


if __name__ == "__main__":
    for p in sys.argv[1:]:
        apply(p)
