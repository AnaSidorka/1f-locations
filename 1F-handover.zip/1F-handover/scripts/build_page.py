#!/usr/bin/env python3
"""Rebuild a v5 city page from its spec JSON.

Usage:
    python3 scripts/build_page.py specs/<slug>.json <out.html> [--no-validate]

The spec carries every content section as a raw HTML body; the builder
regenerates the fixed skeleton around it: head + shared CSS, topbar, hero
(P0-5), section wrappers with zebra classes, the six JSON-LD blocks
(FAQPage re-serialized from the visible FAQ, P0-9) and the raw <script>
blocks. After writing it runs the 43-rule gate.

Guards: no '{{' placeholders, zebra recomputed (never trust stored
classes), city-links block == cities-99.md registry minus current city.
"""
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CSS_PATH = ROOT / "assets" / "page-shell-v5.css"
REGISTRY_PATH = ROOT / "references" / "cities-99.md"

SECTION_IDS = {"calc": "calc-sec", "links": "links-sec"}

TOPBAR = ('<div class="topbar"><div class="wrap"><span>Licensed loan '
          'connector &middot; NMLS ID 1814281</span> '
          '<a href="tel:+17204282247">(720) 428-2247</a></div></div>')

HERO = """<section class="hero">
  <div class="wrap">
    <div class="hero-grid">
      <div>
        <h1>{h1}</h1>
        <p class="sub">Apply online in minutes, from your phone.</p>
        <ul class="hero-ticks">
          <li>5-minute request, fast lender decision</li>
          <li>Soft credit check to prequalify</li>
          <li>Same-day funding available on weekday approvals</li>
        </ul>
      </div>
      <div class="hero-card">
        <h3>Check your rate</h3>
        <p style="font-size:15px;color:var(--ink-soft)">See what a licensed {state} lender can offer. Prequalifying will not affect your credit score.</p>
        <a class="btn" href="https://1firstcashadvance.org/apply/">Start My Application</a>
        <p class="small" style="margin:12px 0 0">I have read and agree to the <a href="https://1firstcashadvance.org/terms/">Terms</a>, <a href="https://1firstcashadvance.org/rates/">Rates</a>, <a href="https://1firstcashadvance.org/privacy-policy/">Privacy Policy</a> and <a href="https://1firstcashadvance.org/legal-disclaimer/">Disclaimer</a> before submitting a loan request.</p>
      </div>
    </div>
    <div class="hero-foot">
      <details class="trust-badge"><summary>Why Trust Us?</summary><div>1F Cash Advance has been providing emergency loans since 2019. We are licensed and operate under state laws. Over 140,305 consumers have already benefited from our services, both online and in stores.</div></details>
      <details class="trust-badge"><summary>Fact-Checked</summary><div>Each our article is reviewed by leading industry experts and updated regularly. We ensure accuracy through daily audits. Learn more about our <a href="https://1firstcashadvance.org/editorial-policy/">editorial standards</a>.</div></details>
      <span class="byline-mini">Updated: {date} &middot; Written by <a href="https://1firstcashadvance.org/latoria-williams/">Latoria Williams</a> | Edited by <a href="https://1firstcashadvance.org/marsha-welch/">Marsha Welch</a> | Reviewed by <a href="https://1firstcashadvance.org/michael-lefler/">Michael Lefler</a></span>
    </div>
  </div>
</section>"""

ORG_ID = {"@id": "https://1firstcashadvance.org/#org"}


def fail(msg):
    raise SystemExit(f"BUILD FAIL: {msg}")


def jd(obj):
    return json.dumps(obj, ensure_ascii=False)


def jsonld_blocks(spec):
    title = spec["title"]
    h1 = spec["h1"]
    state = spec["state"]
    city = spec["city"]
    state_slug = spec["state_slug"]
    city_slug = spec["city_slug"]

    org = {"@context": "https://schema.org", "@type": "Organization",
           "@id": ORG_ID["@id"], "name": "1F Cash Advance",
           "url": "https://1firstcashadvance.org",
           "telephone": "+1-720-428-2247",
           "address": {"@type": "PostalAddress",
                       "streetAddress": "2770 Canyon Blvd",
                       "addressLocality": "Boulder",
                       "addressRegion": "CO", "postalCode": "80302",
                       "addressCountry": "US"}}

    webpage = {"@context": "https://schema.org", "@type": "WebPage",
               "name": f"{title} | 1F Cash Advance",
               "url": f"https://1firstcashadvance.org/loans-by-state/{state_slug}/{city_slug}/",
               "inLanguage": "en-US", "isPartOf": dict(ORG_ID)}

    crumb = {"@context": "https://schema.org", "@type": "BreadcrumbList",
             "itemListElement": [
                 {"@type": "ListItem", "position": 1, "name": "Home",
                  "item": "https://1firstcashadvance.org/"},
                 {"@type": "ListItem", "position": 2,
                  "name": "Loans by State",
                  "item": "https://1firstcashadvance.org/loans-by-state/"},
                 {"@type": "ListItem", "position": 3, "name": state,
                  "item": f"https://1firstcashadvance.org/loans-by-state/{state_slug}/"},
                 {"@type": "ListItem", "position": 4, "name": city}]}

    entities = []
    for item in spec["faqs"]:
        plain = re.sub(r"<[^>]+>", "", item["a_html"])
        if "a_text" in item and item["a_text"] != plain:
            fail(f"spec a_text drifted from a_html for {item['q']!r}")
        entities.append({
            "@type": "Question", "name": item["q"],
            "acceptedAnswer": {"@type": "Answer", "text": plain}})
    faqpage = {"@context": "https://schema.org", "@type": "FAQPage",
               "mainEntity": entities}

    article = {"@context": "https://schema.org", "@type": "Article",
               "headline": h1,
               "author": {"@type": "Person", "name": "Latoria Williams"},
               "editor": {"@type": "Person", "name": "Marsha Welch"},
               "reviewedBy": {"@type": "Person", "name": "Michael Lefler"},
               "datePublished": spec["published"],
               "dateModified": spec["modified"],
               "publisher": dict(ORG_ID)}

    service = {"@context": "https://schema.org", "@type": "Service",
               "name": spec["service_name"], "provider": dict(ORG_ID),
               "areaServed": {"@type": "City",
                              "name": f"{city}, {state}"},
               "serviceType": "Loan connector and financial marketplace"}

    faq_json = json.dumps(faqpage, indent=2, ensure_ascii=False)
    if spec.get("faq_ld_newlines"):
        faq_block = ('<script type="application/ld+json">\n'
                     + faq_json + '\n</script>')
    else:
        faq_block = ('<script type="application/ld+json">'
                     + faq_json + '</script>')

    return [
        f'<script type="application/ld+json">{jd(org)}</script>',
        f'<script type="application/ld+json">{jd(webpage)}</script>',
        f'<script type="application/ld+json">{jd(crumb)}</script>',
        faq_block,
        f'<script type="application/ld+json">{jd(article)}</script>',
        f'<script type="application/ld+json">{jd(service)}</script>',
    ]


def registry_cities(st):
    """City list for the state from references/cities-99.md."""
    text = REGISTRY_PATH.read_text(encoding="utf-8")
    m = re.search(rf"^## .+?\({re.escape(st)}\) — [^\n]*\n+([^\n#]+)",
                  text, re.M)
    if not m:
        fail(f"state {st} not found in cities-99.md")
    return [c.strip() for c in m.group(1).split(",") if c.strip()]


def guard_city_links(spec):
    body = spec["sections"].get("cities", "")
    actual = re.findall(
        r'<a href="https://1firstcashadvance\.org/loans-by-state/'
        rf'{re.escape(spec["state_slug"])}/[^"]+/">([^<]+)</a>', body)
    expected = [c for c in registry_cities(spec["st"])
                if c.lower() != spec["city"].lower()]
    if sorted(a.lower() for a in actual) != \
            sorted(e.lower() for e in expected):
        fail("CITY LINKS MISMATCH: page has "
             f"{sorted(actual)}, registry minus current is "
             f"{sorted(expected)}")


def build(spec):
    css = CSS_PATH.read_text(encoding="utf-8")
    title = spec["title"]

    head = (
        "<!DOCTYPE html>\n"
        '<!-- skill-version: v2 --><html lang="en"><head>'
        '<meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">\n'
        f"<title>{title} | 1F Cash Advance</title>\n"
        f"<style>\n{css}</style>\n"
        "</head><body>")

    parts = [head, TOPBAR,
             HERO.format(h1=spec["h1"], state=spec["hero_state"],
                         date=spec["date"])]

    seps = spec.get("seps", {})
    zebra_check = {}
    doc = "\n".join(parts)
    for i, (name, body) in enumerate(spec["sections"].items()):
        cls = "section alt" if i % 2 == 0 else "section"
        zebra_check[name] = cls
        idattr = f' id="{SECTION_IDS[name]}"' if name in SECTION_IDS else ""
        doc += seps.get(name, "\n") \
            + f'<section class="{cls}"{idattr}>{body}</section>'

    recorded = spec.get("zebra")
    if recorded and recorded != zebra_check:
        fail(f"zebra drift: {recorded} != {zebra_check}")

    tail = jsonld_blocks(spec) \
        + [f"<script>\n{s}</script>" for s in spec["scripts"]]
    doc += "\n" + "\n".join(tail)

    return doc + "\n</body></html>"


def main():
    if len(sys.argv) < 3:
        fail("usage: build_page.py <spec.json> <out.html> [--no-validate]")
    spec = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    out = Path(sys.argv[2])
    run_gate = "--no-validate" not in sys.argv

    guard_city_links(spec)
    html = build(spec)

    if "{{" in html:
        fail("placeholder '{{' survived the build")

    out.write_text(html, encoding="utf-8")
    print(f"built {out} ({len(html)} chars)")

    if run_gate:
        r = subprocess.run(
            [sys.executable, str(ROOT / "scripts" / "validate.py"),
             str(out), "--city", spec["city"]],
            capture_output=True, text=True)
        print(r.stdout.strip())
        if r.returncode != 0:
            print(r.stderr.strip(), file=sys.stderr)
            fail("gate did not pass")


if __name__ == "__main__":
    main()
