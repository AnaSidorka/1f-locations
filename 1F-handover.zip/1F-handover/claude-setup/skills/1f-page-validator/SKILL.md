---
name: 1f-page-validator
description: "Audit a completed 1F Cash Advance city loan HTML page (1firstcashadvance.org) against the full production spec, the matching state reference, and sibling-page consistency, then report PASS/FAIL and publish readiness. Use to validate, audit, QA, or check readiness of a built 1F city/state page, or a batch before publishing. Trigger on 'проверь страницу 1F', 'валидируй страницу', 'готова ли к публикации', '1F page audit', 'validate 1F page', 'is this page ready to publish', or any request to check a built 1F page against the spec. Reports Critical/Major/Minor/Not-verifiable counts with an issue table (Severity, Block, Rule, Found, Expected, Fix); READY TO PUBLISH requires zero Critical and zero Major. Does not rewrite the page unless explicitly asked. Uses only references/{state-slug}.md for the detected state and never validates one state with another state's reference. Pairs with the 1f-page-builder skill."
---

# 1F Page Validator v4

## Purpose
Audit a completed 1F Cash Advance city loan HTML page against the full production specification, the matching state reference, and sibling-page consistency rules.

The validator does not rewrite the page unless explicitly asked. It reports violations precisely and determines publish readiness.

Louisiana is never a universal fallback. State-dependent checks use only `references/{state-slug}.md` for the detected state.

---

# Output format

Return:
- `RESULT: PASS` or `RESULT: FAIL`
- `READY TO PUBLISH` or `NOT READY TO PUBLISH`
- counts of Critical / Major / Minor / Not verifiable
- issue table: `Severity | Block | Rule | Found | Expected | Fix`
- `Passed checks`
- `Not verifiable` section when evidence is unavailable

`READY TO PUBLISH` requires zero Critical and zero Major issues.

---

# 0. Detection and state reference

1. Detect City / State / ST / page URL from H1/schema/page data.
2. Load `references/{state-slug}.md`.
3. If absent: mark state-dependent checks `NOT VERIFIABLE`, add Critical `STATE LAYER NOT DEFINED`, and set `NOT READY TO PUBLISH`.
4. Never validate one state using another state's reference.

---

# 1. Exact page order

Require this order:
1. topbar
2. Hero
3. How to Apply
4. Loan Products
5. What You Need to Qualify
6. How 1F Cash Advance Works
7. Where to get payday loan {City}
8. Can You Get a Payday Loan in {City}?
9. Borrowing and Debt in {City}
10. {State} Law at a Glance
11. Other Ways to Cover an Emergency in {City}
12. Borrow Carefully
13. {City} Borrowers Ask
14. 1F Cash Advance in Other {State} Cities
15. About the Authors

Any missing/misordered required block = Major; missing state/legal block with factual consequences may be Critical.

After Hero, require strict `section` / `section alt` alternation. Zebra break = Major.

---

# 2. Topbar checks

Require normalized text:
`Licensed loan connector · NMLS ID 1814281`

Fail Major on state-residency/since-2019 claims in topbar unless explicitly approved by current source.
`since 2019` is allowed only inside approved Why Trust Us? copy.

---

# 3. Hero checks

Require exact normalized:
- H1 `Payday Loans in {City}, {State}`
- sub `Apply online in minutes, from your phone.`
- 3 exact bullets in order

Require Hero card elements:
- `Check your rate`
- CTA
- consent links to Terms / Rates / Privacy Policy / Disclaimer

Require hero-foot:
- Why Trust Us?
- Fact-Checked
- Updated date
- Latoria Williams
- Marsha Welch
- Michael Lefler

Fail Major if hero-foot contains regulator copy or `not a direct lender` positioning duplicated from How 1F Works.

---

# 4. How to Apply checks

Require H2 exactly:
`How to Apply from {City}`

Fail Major if H2 contains ZIP or state abbreviation.

Require exact Step 1/2 titles and bodies after placeholders.

Step 3 must match the state reference's funding variant exactly.

## Cutoff states
If reference enables cutoff:
- require exact cutoff value and lowercase am/pm format
- require same-day fine print
- invented/mismatched cutoff = Critical

## No-cutoff / ban-installment states
If reference disables same-day cutoff:
- require one-business-day wording from reference
- prohibit `Same-day cutoff:` in Step 3

### Virginia precedence
If older/global data lists a VA cutoff but Virginia reference declares no-cutoff, the state-specific no-cutoff rule wins. Validator should report any VA cutoff as Critical state-layer drift unless the Virginia reference explicitly changes.

---

# 5. Loan Products checks

Require exactly 2 product cards.

Allowed conceptual slots:
1. Payday Loans / Short-Term Loans as state reference defines
2. Installment Loans

Fail Major on third product card, including PAL/title/auto-title card.

Require:
- no `div.max` chip
- `.prod-ic`
- payday icon wallet2
- installment icon calender
- Explore links
- state-specific copy consistent with reference

Wrong legal/product figure or cross-state wording = Critical.
Generic filler where the reference defines state-specific copy = Major.

---

# 6. What You Need to Qualify checks

Require H2 exact.
No intro paragraph before list.
Require exactly the 7 locked bullets in exact order after `{State}` replacement.
Fail Major on extra hard-inquiry/TransUnion/AI-water notes after the list.

---

# 7. How 1F Works checks

Require exact normalized intro, 3 bullets, and closing after `{State}` replacement.

Require first sentence exactly:
`1F Cash Advance is a loan connector and financial marketplace, not a direct lender.`

Require lender-decides bullet to state that the lender, not 1F Cash Advance, approves, sets rate/fee within state law, and funds the loan.

Positioning 1F as direct lender = Critical.
Locked-copy drift = Major.

---

# 8. Office checks

Require H2 exactly:
`Where to get payday loan {City}`

Require office block immediately after How 1F Works.
No intro paragraph before grid/list.
Fail Major on `Our {City} Offices` or `Prefer to apply in person...`.

For each office require:
- street address
- city/ST/ZIP
- opening 8:00 AM unless explicit source says otherwise
- closing time

Address provenance must be user-provided/approved. If provenance unavailable, mark Not verifiable; obvious malformed ZIP/address = Major and do not silently accept.

No city-office FinancialService schema.

---

# 9. Can You Get checks

Require H2 exact:
`Can You Get a Payday Loan in {City}?`

First word/phrase must be direct answer: `Yes`, `No`, or `Not the old kind` depending state reference.

Paragraph 1 must contain the essential state product/legal mechanics required by the reference without becoming a duplicate of the Law table.
Paragraph 2 must contain one local angle + one helpful borrower action.

Fail Major on:
- `{City}'s angle is...`
- `metro county`
- duplicate law-table narration
- copied sibling paragraph with only city-name swap when sibling comparison is available

Contradiction with state reference = Critical.

---

# 10. Borrowing and Debt checks

Require exactly:
- 3 stat cards
- 1 comparison table
- 1 short neutral source/context line
- clickable primary-source links

Data must be city data when labeled city.
Preferred sources: Census ACS / QuickFacts or another official source.

Fail Major on:
- missing clickable sources
- commute/travel time as core metric without documented financial reason
- meaningless/redundant comparison
- `same geography`
- fake county comparison for independent city
- county data presented as city data
- water after statistics (`The takeaway`, `The honest reading`, etc.)

For independent cities, City vs State or City / Metro / State is acceptable when meaningful.

---

# 11. Law at a Glance checks

Compare against state reference normalized verbatim after permitted placeholders.

Require:
- state intro
- table rows/order
- current representative example when applicable
- required disclaimer/fine print
- source/regulator/state-guide link(s) defined by reference

Fail Major on after-law water or repeated CTA:
- `Want the full law?`
- `Why the law change is the story...`
- `The honest reading...`
- duplicate state-guide pitch

Stale/incorrect legal figures = Critical.

---

# 12. Other Ways checks

Require H2 exactly:
`Other Ways to Cover an Emergency in {City}`

Require exactly 4 cards in this conceptual set:
1. Credit union Payday Alternative Loans
2. Bank small-dollar programs
3. Employer and paycheck advances
4. Utility and assistance programs

Missing Bank card = Major.
Extra license-check/product card = Major.
State wording must follow reference.

---

# 13. Borrow Carefully checks

Require exactly 4 `.resp-list` bullets with these exact lead-ins:
1. `Borrow the minimum, not the maximum.`
2. `Price the loan in dollars, not percentages.`
3. `Protect the repayment date.`
4. `Borrow for one-time gaps only.`

Require final regulator/CFPB line consistent with state reference.

Fail Major if block becomes a second law summary or repeats state figures unnecessarily.
Wrong regulator = Critical.

---

# 14. FAQ checks

Require H2:
`{City} Borrowers Ask`

Require exactly 3 visible FAQ items.
Each answer:
- 2–3 sentences
- <60 words
- useful independently
- not a Law-table duplicate

If sibling pages are available, questions should not be identical clones unless a state/reference rule requires it.

FAQPage JSON-LD must match visible question and answer text exactly after HTML normalization.
Mismatch = Major.

---

# 15. Other State Cities checks

Require H2:
`1F Cash Advance in Other {State} Cities`

Checks:
- no self-link
- only real sibling pages when evidence is available
- URL pattern `/{city-slug}-{st-lower}-loans/`

If navigation/menu is in supplied HTML, city pages should not replace state-hub menu architecture.

---

# 16. Authors checks

Require About the Authors after city-links.
Exactly 3 cards:
- Latoria Williams — Written by · CEO
- Marsha Welch — Edited by
- Michael Lefler — Reviewed by

Require verified profile links when present in canonical template/reference.
Reviewer geography must not mislabel county/parish/city.

---

# 17. Obsolete Store block checks

Fail Major if page contains obsolete blocks such as:
- `There Is No 1F Storefront`
- `Your 1F Cash Advance Store in`
- `Visit Our {City} Store`

Fail Critical/Major as appropriate if Organization/FinancialService schema is reassigned from Boulder HQ to a city office.

---

# 18. Tone checks

Flag Major for alarmist/lecturing phrases including:
- lands hardest
- bites hardest
- hurts most
- makes the due date risky
- no cushion
- little financial slack
- honest reading
- awkward moment

Flag Major for unsupported categorical claims such as:
- most expensive option
- will beat a payday loan every time
- the cheapest ... for most people

Prefer calm conditional language.

---

# 19. Number/topic dedup checks

Count page-wide loan/product/legal monetary amounts and percentages/APRs.

Require:
- each loan-law monetary amount <=2 occurrences
- each loan-law percentage/APR <=2 occurrences
- each major argument/theme explained <=2 times

Canonical locations are usually Can You Get + Law table.
City-statistics figures are separate city-data metrics and should not be conflated with loan-law dedup counts.

Violation = Major unless repetition creates conflicting legal information, then Critical.

Also flag accidental find/replace duplicate phrasing.

---

# 20. Fact verification checks

Never accept invented:
- offices
- statistics
- legal figures
- lender names
- regulators
- cutoff times

Require official/primary source grounding where the page/reference provides source expectations.
Unsupported legal or product figure = Critical.
Unsupported city statistic = Major.
Address provenance unavailable = Not verifiable unless obvious error exists.

Date-sensitive state figures must be current according to the state reference's refresh rule.

---

# 21. Schema / technical checks

Require exactly these 6 JSON-LD types:
1. Organization
2. WebPage
3. BreadcrumbList
4. FAQPage
5. Article
6. Service

Checks:
- exactly one FAQPage
- FAQ visible copy == FAQPage exact text
- no stale sibling city/state/URL
- Organization/FinancialService remains Boulder HQ
- zero unresolved `{{`
- balanced HTML tags
- date format `Month D, YYYY`
- cutoff format lowercase `H:MM am/pm`
- required classes present: `.hero-ticks`, `.trust-badge`, `.hero-foot`, `.byline-mini`, `.prod-ic`, `.resp-list`
- required fonts/styles available in template

Missing schema type = Major.
Wrong legal/business location in schema may be Critical.

---

# 22. Sibling consistency checks

When sibling page(s) in the same state are available, compare:
- block order
- zebra pattern
- state Products
- state Law
- Other Ways
- Borrow Carefully
- Apply funding variant
- Borrowing & Debt structure
- office heading pattern
- schema set

State-locked drift = Major; legal/regulator/cutoff drift = Critical.
City-specific Can You Get / stats / FAQ should not be near-identical clones with only city names replaced.

---

# 23. Severity guide

## Critical
- wrong state law/product rule
- wrong/invented cutoff
- cross-state leakage
- wrong regulator
- 1F positioned as direct lender
- unsupported/incorrect legal figure
- state reference missing while claiming publish-ready
- business/schema location materially wrong

## Major
- required block missing/misordered
- zebra broken
- locked wording drift
- third product card / wrong product structure
- missing sources
- weak stats table
- office heading/intro violation
- Can You Get format violation
- duplicate law CTA/water
- FAQ count/length/schema mismatch
- number dedup violation
- banned tone
- obsolete Store block

## Minor
- punctuation/spacing/format inconsistency that does not alter required locked meaning or compliance

## Not verifiable
- missing source provenance
- sibling comparison unavailable
- external evidence not available

---

# 24. Publish rule

`READY TO PUBLISH` only when:
- 0 Critical
- 0 Major
- matching state reference exists
- all required blocks validate
- factual sources validate
- schema/technical checks validate
- no unresolved placeholders

Otherwise: `NOT READY TO PUBLISH`.

---

# 25. Mandatory validator checklist

Before final result, explicitly check:
- direct Yes/No/Not the old kind in Can You Get
- no `metro county`
- 3 stat cards + 1 table
- city data, not mislabeled county data
- clickable official stats sources
- FAQ exactly 3 and each <60 words, 2–3 sentences
- Borrow Carefully exactly 4 bullets
- Other Ways exactly 4 cards including Bank
- no water after stats/law
- obsolete Store absent
- `not a direct lender` present in How 1F Works
- `Cover an Emergency`
- ZIP absent from Apply H2
- Products exactly 2 cards
- `.max` chips absent
- loan-law dollar figures <=2 occurrences each
- loan-law percentages/APRs <=2 occurrences each
- exactly 6 JSON-LD types
- balanced tags
- offices present and correctly headed
- unsupported figures absent
- sibling state-layer drift absent when comparable